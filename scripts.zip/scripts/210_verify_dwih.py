# -*- coding: utf-8 -*-
"""复核 DWI_H 纯影像模型 LASSO 入选特征数"""
import os, warnings
import numpy as np, pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold
from sksurv.linear_model import CoxnetSurvivalAnalysis
from sksurv.metrics import concordance_index_censored
warnings.filterwarnings('ignore')
BASE=r'<PROJECT_ROOT>'; ALPHAS=np.logspace(-1.5,0,20); SEED=42

clin=pd.read_csv(r'<DATA_ROOT>\分析结果\merged_data_corrected.csv',encoding='utf-8-sig')
clin['Case_No.']=clin['Case_No.'].astype(str)
y=np.array([(bool(e),float(t)) for e,t in zip(clin['DFS'],clin['Time'])],dtype=[('event','bool'),('time','float')])
order=clin['Case_No.']

rad=pd.read_csv(os.path.join(BASE,'data','features','dwi_pyradiomics_k3.csv'))
rad['Case_No.']=rad['Case_No.'].astype(str)
print('Habitat 取值:', rad['Habitat'].unique())
radH=rad[rad.Habitat=='habitat_H'].drop_duplicates('Case_No.').set_index('Case_No.')
feat=[c for c in radH.columns if c not in ('Case_No.','Habitat')]
X=radH[feat].loc[order].reset_index(drop=True).fillna(0).astype(float)
print('DWI_H 特征数:', X.shape[1], '| 病例:', X.shape[0])

Xs=X.values
# 5折CV逐alpha
sc={a:[] for a in ALPHAS}
kf=KFold(5,shuffle=True,random_state=SEED)
for tr,te in kf.split(Xs):
    s=StandardScaler(); Xtr=s.fit_transform(Xs[tr]); Xte=s.transform(Xs[te])
    try:
        c=CoxnetSurvivalAnalysis(l1_ratio=1,alphas=ALPHAS,max_iter=10000).fit(Xtr,y[tr])
        for a in ALPHAS:
            try: sc[a].append(concordance_index_censored(y['event'][te],y['time'][te],c.predict(Xte,alpha=a))[0])
            except: sc[a].append(.5)
    except:
        for a in ALPHAS: sc[a].append(.5)
cm={a:float(np.mean(v)) for a,v in sc.items()}
best=max(cm,key=cm.get)
print(f'CV最优 alpha = {best:.4f}, CV C-index = {cm[best]:.4f}')
# 在全数据上以best alpha拟合，数非零系数
s=StandardScaler(); Xs2=s.fit_transform(Xs)
c=CoxnetSurvivalAnalysis(l1_ratio=1,alphas=[best],max_iter=10000).fit(Xs2,y)
coef=pd.Series(c.coef_.flatten(),index=feat)
sel=coef[coef!=0].sort_values(key=np.abs,ascending=False)
print(f'\n>>> best alpha 下入选特征数 = {len(sel)}')
for k,v in sel.items(): print(f'   {k}: {v:.4f}')
# 各alpha入选数
print('\nalpha → 入选特征数:')
for a in ALPHAS:
    try:
        c2=CoxnetSurvivalAnalysis(l1_ratio=1,alphas=[a],max_iter=10000).fit(Xs2,y)
        nz=int((c2.coef_.flatten()!=0).sum())
        print(f'  alpha={a:.4f} (CV={cm[a]:.4f}): {nz}')
    except Exception as e: print(f'  alpha={a:.4f}: err')
