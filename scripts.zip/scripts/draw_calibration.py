#!/usr/bin/env python3
"""Calibration curves for M0, M2b, M4c at 3yr and 5yr"""
import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from lifelines import CoxPHFitter
from sklearn.calibration import calibration_curve
from sksurv.metrics import brier_score

plt.rcParams.update({'font.family':'Times New Roman','font.size':12,
                     'axes.facecolor':'white','figure.facecolor':'white'})

OUT="<PROJECT_ROOT>/results/figures";DPI=600

clin=pd.read_csv('<DATA_ROOT>/分析结果/merged_data_corrected.csv')
dwi=pd.read_csv('<PROJECT_ROOT>/data/features/dwi_pyradiomics_k3.csv')
dce=pd.read_csv('<PROJECT_ROOT>/data/features/dce_pyradiomics_k3.csv')
feats=[c for c in dwi.columns if c not in ['Case_No.','Habitat']]
def gh(df,hab):return df[df['Habitat']==hab][['Case_No.']+feats].drop_duplicates('Case_No.').set_index('Case_No.')

models_dict={
    'M0 (Clinical)': clin[['NAC','N','ALN','DFS','Time']].copy(),
    'M2b (DWI M+Clinical)': clin[['NAC','N','ALN','DFS','Time']].copy(),
    'M4c (DCE H+Clinical)': pd.concat([
        clin.set_index('Case_No.')[['NAC','N','ALN','Grade','proRT','DFS','Time']],
        gh(dce,'habitat_H')[['original_shape_Sphericity','original_shape_Maximum3DDiameter']]
    ],axis=1).reset_index(),
}

colors={'M0 (Clinical)':'#4472C4','M2b (DWI M+Clinical)':'#ED7D31','M4c (DCE H+Clinical)':'#70AD47'}
markers={'M0 (Clinical)':'o','M2b (DWI M+Clinical)':'s','M4c (DCE H+Clinical)':'D'}

fig,axes=plt.subplots(1,2,figsize=(14,6))

for panel_idx,(time_val,title) in enumerate([(36,'3-Year DFS'),(60,'5-Year DFS')]):
    ax=axes[panel_idx]
    
    for label in ['M0 (Clinical)','M2b (DWI M+Clinical)','M4c (DCE H+Clinical)']:
        df=models_dict[label]
        cph=CoxPHFitter(penalizer=0.01)
        pred_cols=[c for c in df.columns if c not in ['Case_No.','DFS','Time']]
        cph.fit(df[['Time','DFS']+pred_cols],'Time','DFS')
        risk=cph.predict_partial_hazard(df)
        
        # Survival probability at time t
        base_surv=cph.baseline_survival_
        surv_t=base_surv.loc[min(base_surv.index,key=lambda x:abs(x-time_val)),'baseline survival'] if time_val in base_surv.index else base_surv.iloc[(base_surv.index-time_val).abs().argmin()]['baseline survival']
        pred_surv=surv_t**np.exp(risk)
        
        # Observed survival at time t
        event_at_t=((clin['DFS']==1)&(clin['Time']<=time_val)).astype(int)
        
        # Calibration curve
        prob_true,prob_pred=calibration_curve(event_at_t,1-pred_surv,n_bins=10,strategy='quantile')
        
        ax.plot(prob_pred,prob_true,marker=markers[label],color=colors[label],linewidth=2,
                markersize=8,label=label,linestyle='-',markerfacecolor='white',markeredgewidth=1.5)
    
    ax.plot([0,1],[0,1],'k--',linewidth=1,alpha=0.5,label='Perfect calibration')
    ax.set_xlim(0,1);ax.set_ylim(0,1)
    ax.set_xlabel('Predicted probability',fontsize=15)
    ax.set_ylabel('Observed probability',fontsize=15)
    ax.set_title(f'{title} Calibration',fontsize=16,fontweight='bold')
    ax.tick_params(labelsize=13)
    ax.spines['top'].set_visible(False);ax.spines['right'].set_visible(False)
    ax.legend(fontsize=11,loc='lower right',frameon=True,edgecolor='#CCCCCC',facecolor='white')

plt.tight_layout()
for ext in ['png','tiff','jpg']:
    plt.savefig(f'{OUT}/Fig_Calibration_curves.{ext}',dpi=DPI,bbox_inches='tight',facecolor='white')
    print(f'✅ Fig_Calibration_curves.{ext}')
plt.close()
print('Done')
