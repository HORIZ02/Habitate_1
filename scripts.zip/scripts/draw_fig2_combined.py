#!/usr/bin/env python3
"""Fig 2复合图 v2: (a)生境比例拆DWI/DCE两个panel + (b)特征差异2x3"""
import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.gridspec import GridSpec

plt.rcParams.update({'font.family':'Times New Roman','font.size':12,
                     'axes.facecolor':'white','figure.facecolor':'white'})
OUT="<PROJECT_ROOT>/results/figures";DPI=600

CLIN=pd.read_csv('<DATA_ROOT>/分析结果/merged_data_corrected.csv')
DWI_C=pd.read_csv('<PROJECT_ROOT>/data/dwi_cluster_info_k3.csv',encoding='ISO-8859-1')
DCE_C=pd.read_csv('<PROJECT_ROOT>/data/dce_cluster_info_k3.csv',encoding='utf-8-sig')
DWI_F=pd.read_csv('<PROJECT_ROOT>/data/features/dwi_pyradiomics_k3.csv')

# ===== 风险分组(M4c) =====
from sklearn.preprocessing import StandardScaler
from sksurv.linear_model import CoxnetSurvivalAnalysis
DCE_F=pd.read_csv('<PROJECT_ROOT>/data/features/dce_pyradiomics_k3.csv')
feats=[c for c in DCE_F.columns if c not in ['Case_No.','Habitat']]
dce_h=DCE_F[DCE_F['Habitat']=='habitat_H'][['Case_No.']+feats].drop_duplicates('Case_No.').set_index('Case_No.')
clin_vars=['NAC','N','Age','Grade','T','ALN','proRT','ER','PR','Her2','Meno']
X=pd.concat([CLIN[clin_vars+['Case_No.']].set_index('Case_No.'),dce_h],axis=1).select_dtypes(include=[np.number]).dropna()
y=np.array(list(zip(CLIN['DFS'].astype(bool),CLIN['Time'])),dtype=[('event','bool'),('time','float')])
common=X.index.intersection(CLIN['Case_No.'])
X=X.loc[common];y=y[[list(CLIN['Case_No.']).index(cn) for cn in common]]
Xs=StandardScaler().fit_transform(X)
cph=CoxnetSurvivalAnalysis(l1_ratio=1,alphas=[0.022],max_iter=10000).fit(Xs,y)
risk=cph.predict(Xs).flatten()
med=np.median(risk)
risk_map=dict(zip(common,risk))

hab_colors=['#2166AC','#4DAF4A','#E41A1C']
hab_labels=['Habitat L','Habitat M','Habitat H']

# ===== 布局: 上部(a)两panel并排, 下部(b)2x3 =====
fig=plt.figure(figsize=(14,13))
# (a)占上面2行, (b)2x3占下面
ax_dwi=plt.subplot2grid((4,6),(0,0),rowspan=2,colspan=3)
ax_dce=plt.subplot2grid((4,6),(0,3),rowspan=2,colspan=3)

def style_boxplot(bp):
    for pi,patch in enumerate(bp['boxes']):
        patch.set_facecolor(hab_colors[pi]);patch.set_alpha(0.75)
        patch.set_edgecolor('black');patch.set_linewidth(1)
    for w in bp['whiskers']:w.set_color('#333333');w.set_linewidth(0.8)
    for c_ in bp['caps']:c_.set_color('#333333');c_.set_linewidth(0.8)
    for m_ in bp['medians']:m_.set_color('black');m_.set_linewidth(1.2)

def plot_prop_panel(ax, cinfo, title):
    tot=cinfo[['Habitat_L_voxels','Habitat_M_voxels','Habitat_H_voxels']].sum(axis=1)
    m=pd.DataFrame({'Case_No.':cinfo['Case_No.'],
                     'pL':cinfo['Habitat_L_voxels']/tot,
                     'pM':cinfo['Habitat_M_voxels']/tot,
                     'pH':cinfo['Habitat_H_voxels']/tot})
    m['group']=m['Case_No.'].map(lambda c: 'High' if risk_map.get(c,0)>med else 'Low')
    
    positions=[]
    for gi,grp in enumerate(['Low','High']):
        sub=m[m['group']==grp]
        for hi,h in enumerate(['pL','pM','pH']):
            pos=gi*3+hi+1
            positions.append(pos)
            bp=ax.boxplot(sub[h].values*100,positions=[pos],widths=0.55,
                          patch_artist=True,showfliers=False)
            # 直接按生境索引着色(修正: 不用style_boxplot, 它用enumerate固定pi=0)
            bp['boxes'][0].set_facecolor(hab_colors[hi]);bp['boxes'][0].set_alpha(0.75)
            bp['boxes'][0].set_edgecolor('black');bp['boxes'][0].set_linewidth(1)
            for w in bp['whiskers']:w.set_color('#333333');w.set_linewidth(0.8)
            for c_ in bp['caps']:c_.set_color('#333333');c_.set_linewidth(0.8)
            for m_ in bp['medians']:m_.set_color('black');m_.set_linewidth(1.2)
    
    ax.set_xticks([2,5])
    ax.set_xticklabels(['Low risk','High risk'],fontsize=12)
    ax.set_title(title,fontsize=13,fontweight='bold')
    ax.tick_params(labelsize=11)
    ax.spines['top'].set_visible(False);ax.spines['right'].set_visible(False)
    ax.set_ylim(0,100)

# ---- Panel (a): 两个panel ----
ax_dwi.text(-0.06,1.02,'(a)',transform=ax_dwi.transAxes,fontsize=15,fontweight='bold',va='bottom',ha='right')
plot_prop_panel(ax_dwi, DWI_C, 'DWI')
plot_prop_panel(ax_dce, DCE_C, 'DCE-MRI')
ax_dwi.set_ylabel('Habitat volume proportion (%)',fontsize=13)

# ---- Panel (b): 特征差异 2x3 ----
top_feats=['original_shape_MinorAxisLength','original_shape_MajorAxisLength',
           'original_firstorder_Mean','original_firstorder_Skewness',
           'original_firstorder_Kurtosis','original_glcm_Contrast']
feats_avail=[f for f in top_feats if f in DWI_F.columns]

for ai,f in enumerate(feats_avail[:6]):
    sub_ax=plt.subplot2grid((4,6),(2+ai//3, (ai%3)*2),colspan=2)
    data=[]
    for hab in ['habitat_L','habitat_M','habitat_H']:
        vals=DWI_F[DWI_F['Habitat']==hab][f].dropna()
        data.append(vals)
    bp=sub_ax.boxplot(data,patch_artist=True,showfliers=False)
    style_boxplot(bp)
    sub_ax.set_xticklabels(['L','M','H'],fontsize=10)
    short=f.replace('original_shape_','').replace('original_firstorder_','').replace('original_glcm_','')
    sub_ax.set_title(short,fontsize=11,fontweight='bold')
    sub_ax.tick_params(labelsize=10)
    sub_ax.spines['top'].set_visible(False);sub_ax.spines['right'].set_visible(False)
    sub_ax.grid(axis='y',alpha=0.15)
    # 左列加y轴标签
    if ai%3==0:
        sub_ax.set_ylabel('Feature value',fontsize=12)
        if ai==0:
            sub_ax.text(-0.06,1.02,'(b)',transform=sub_ax.transAxes,fontsize=15,fontweight='bold',va='bottom',ha='right')

# (b)标签已放到第一个子图左上角

# 图例(竖排, 放在(a)右侧)
fig.legend(handles=[mpatches.Patch(color=c,label=l) for c,l in zip(hab_colors,hab_labels)],
           loc='center right',ncol=1,fontsize=11,frameon=True,edgecolor='#CCCCCC',
           bbox_to_anchor=(0.995,0.95))

plt.tight_layout()
plt.savefig(f'{OUT}/Fig2_habitat_combined.png',dpi=DPI,bbox_inches='tight',facecolor='white')
plt.savefig(f'{OUT}/Fig2_habitat_combined.tiff',dpi=DPI,bbox_inches='tight',facecolor='white')
plt.close()
print('✅ Fig 2 复合图 v2 已生成')
