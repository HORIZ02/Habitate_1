#!/usr/bin/env python3
"""
乳腺癌多模态生境聚类
基于DCE+DWI的voxel-wise特征 → PCA降维 → GMM+BIC定K → K-means聚类 → 各habitat mask

输入: data/file_mapping.csv
输出: data/habitat_masks/{Case_No.}/habitat_K.nii.gz (K=1,2,...)
      data/habitat_cluster_info.csv (每例聚类信息)
"""
import pandas as pd
import numpy as np
import nibabel as nib
import os, sys
from scipy import ndimage
from sklearn.decomposition import PCA
from sklearn.mixture import GaussianMixture
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import tempfile
import warnings
warnings.filterwarnings('ignore')

# ========== 配置 ==========
MAPPING_FILE = "<PROJECT_ROOT>/data/file_mapping.csv"
MRI_ROOT = "<PROJECT_ROOT>/使用数据/MRI数据"
OUTPUT_DIR = "<PROJECT_ROOT>/data"
MASK_DIR = os.path.join(OUTPUT_DIR, "dwi_habitat_masks")
os.makedirs(MASK_DIR, exist_ok=True)

# 聚类参数
K_MIN = 2
K_MAX = 5  # 最多尝试5个簇
RANDOM_STATE = 42

# ========== 加载映射表 ==========
df = pd.read_csv(MAPPING_FILE)
print(f"待处理: {len(df)} 例")

# ========== 辅助函数 ==========
def load_nifti(rel_path):
    """加载nii.gz，返回(数组, nibabel_image)"""
    full_path = os.path.join(MRI_ROOT, rel_path)
    if not os.path.exists(full_path):
        return None, None
    try:
        nii = nib.load(full_path)
        arr = np.asanyarray(nii.dataobj)
        return arr, nii
    except Exception as e:
        print(f"    加载失败: {e}")
        return None, None

def extract_voxel_features(dwi_arr, mask_arr):
    """
    从ROI区域内提取voxel-wise特征
    返回: (feature_matrix, roi_indices)
        feature_matrix: (N_voxels, n_features)
        roi_indices: (N_voxels, 3) 在3D空间中的坐标
    """
    from scipy import ndimage
    roi_mask = (mask_arr > 0)
    
    features = []
    indices = []
    
    # 预计算局部纹理特征
    # 局部熵（反映组织异质性）
    local_entropy = ndimage.generic_filter(dwi_arr, lambda x: -np.sum((x/np.sum(x+1e-10))*np.log(x/np.sum(x+1e-10)+1e-10)), 
                                           size=3, mode='constant', cval=0)
    # 局部方差（反映边缘信息）
    local_var = ndimage.uniform_filter(dwi_arr**2, size=3) - ndimage.uniform_filter(dwi_arr, size=3)**2
    
    for z in range(mask_arr.shape[0]):
        for y in range(mask_arr.shape[1]):
            for x in range(mask_arr.shape[2]):
                if roi_mask[z, y, x]:
                    features.append([
                        dwi_arr[z, y, x],        # DWI原始信号
                        local_entropy[z, y, x],   # 局部熵
                        local_var[z, y, x],       # 局部方差
                    ])
                    indices.append([z, y, x])
    
    return np.array(features), np.array(indices)

def determine_optimal_k(features, k_min=2, k_max=5):
    """GMM + BIC 确定最优聚类数"""
    bic_scores = []
    models = []
    
    for k in range(k_min, k_max + 1):
        gmm = GaussianMixture(n_components=k, covariance_type='full', 
                              random_state=RANDOM_STATE, n_init=5)
        gmm.fit(features)
        bic_scores.append(gmm.bic(features))
        models.append(gmm)
    
    best_idx = np.argmin(bic_scores)
    return k_min + best_idx, bic_scores

def apply_kmeans(features_pca, n_clusters):
    """K-means聚类"""
    kmeans = KMeans(n_clusters=n_clusters, random_state=RANDOM_STATE, n_init=10)
    labels = kmeans.fit_predict(features_pca)
    return labels, kmeans

def save_habitat_masks(labels, indices, nii_img, case_no, output_dir, n_clusters):
    """
    将聚类结果保存为各个habitat的mask
    使用nibabel保存（保留原始affine信息）
    """
    case_dir = os.path.join(output_dir, case_no)
    os.makedirs(case_dir, exist_ok=True)
    
    shape = nii_img.shape  # nibabel: (x, y, z) or (z, y, x)?
    if len(shape) == 3:
        shape_3d = shape
    else:
        shape_3d = shape[:3]
    
    # 创建全零数组（与原始图像同shape）
    full_mask = np.zeros(shape_3d, dtype=np.int32)
    
    # 填充聚类标签
    for i, (z, y, x) in enumerate(indices):
        full_mask[z, y, x] = labels[i] + 1  # 标签从1开始
    
    # 保存总体聚类mask
    mask_nii = nib.Nifti1Image(full_mask, nii_img.affine, nii_img.header)
    nib.save(mask_nii, os.path.join(case_dir, "habitat_all.nii.gz"))
    
    # 分别保存每个habitat的mask
    for k in range(n_clusters):
        single_mask = (full_mask == (k + 1)).astype(np.int32)
        single_nii = nib.Nifti1Image(single_mask, nii_img.affine, nii_img.header)
        nib.save(single_nii, os.path.join(case_dir, f"habitat_{k+1}.nii.gz"))
    
    return os.path.join(case_dir, "habitat_all.nii.gz")

def plot_bic_curve(bic_scores, k_min, case_no, output_dir):
    """绘制BIC曲线（可选）"""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    
    ks = range(k_min, k_min + len(bic_scores))
    plt.figure(figsize=(6, 4))
    plt.plot(ks, bic_scores, 'bo-')
    plt.xlabel('Number of clusters (K)')
    plt.ylabel('BIC score')
    plt.title(f'GMM BIC - {case_no}')
    plt.grid(alpha=0.3)
    best_k = k_min + np.argmin(bic_scores)
    plt.axvline(x=best_k, color='r', linestyle='--', alpha=0.5, label=f'Best K={best_k}')
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, case_no, "bic_curve.png"), dpi=150)
    plt.close()

# ========== 主流程 ==========
results = []
# 从已有结果恢复
completed = set()
for d in os.listdir(MASK_DIR):
    case_dir = os.path.join(MASK_DIR, d)
    if os.path.isdir(case_dir) and os.path.exists(os.path.join(case_dir, "habitat_all.nii.gz")):
        completed.add(d)

# 加载已有的结果记录
partial_file = os.path.join(OUTPUT_DIR, "habitat_cluster_info_partial.csv")
if os.path.exists(partial_file):
    existing = pd.read_csv(partial_file)
    results = existing.to_dict('records')
    print(f"已加载 {len(results)} 条历史记录")

if completed:
    print(f"已有 {len(completed)} 例完成，将跳过")

for idx, row in df.iterrows():
    case_no = row['Case_No.']
    name = row['Name']
    
    if case_no in completed:
        print(f"[{idx+1}/{len(df)}] {case_no} {name} ⏭ 跳过（已有结果）")
        continue
    
    print(f"\n[{idx+1}/{len(df)}] {case_no} {name}")
    
    # 1. 加载DWI图像
    dwi_path = row['DWI_path']
    dwi_arr, dwi_img = load_nifti(dwi_path)
    if dwi_arr is None:
        print(f"  ⚠ DWI文件缺失: {dwi_path}")
        continue
    
    # DWI mask
    center = dwi_path.split('/')[0]
    dwi_basename = os.path.basename(dwi_path)
    mask_dir = f"{center}/DWI/masks"
    
    mask_file = None
    full_mp = os.path.join(MRI_ROOT, mask_dir)
    if os.path.isdir(full_mp):
        for f in os.listdir(full_mp):
            if f.endswith('.nii.gz'):
                f_stem = f.replace('.nii.gz', '').upper().replace('LABEL', '').replace('label', '')
                # 有些mask有DWI后缀而图像没有，反之亦然
                f_clean = f_stem.replace('DWI', '')
                dwi_stem = dwi_basename.replace('.nii.gz', '').upper()
                dwi_clean = dwi_stem.replace('DWI', '')
                if f_stem == dwi_stem or f_clean == dwi_stem or f_stem == dwi_clean or f_clean == dwi_clean:
                    mask_file = f
                    break
    
    if mask_file is None:
        print(f"  ⚠ Mask未找到: {mask_dir}/ 匹配 {dwi_basename}")
        continue
    
    mask_arr, mask_img = load_nifti(f"{mask_dir}/{mask_file}")
    if mask_arr is None:
        print(f"  ⚠ Mask加载失败: {mask_dir}/{mask_file}")
        continue
    print(f"  Mask: {mask_dir}/{mask_file}")
    
    # 3. 提取voxel-wise特征（仅DWI原始信号+局部纹理）
    features, indices = extract_voxel_features(dwi_arr, mask_arr)
    if len(features) < 30:
        print(f"  ⚠ ROI体素太少: {len(features)}")
        continue
    
    print(f"  ROI体素数: {len(features)}, 特征维度: {features.shape[1]}")
    
    # 4. 处理NaN/Inf
    features = np.nan_to_num(features, nan=0.0, posinf=0.0, neginf=0.0)
    
    # 5. Z-score标准化
    scaler = StandardScaler()
    features_scaled = scaler.fit_transform(features)
    
    # 6. PCA降维（保留95%方差）
    pca = PCA(n_components=0.95, random_state=RANDOM_STATE)
    features_pca = pca.fit_transform(features_scaled)
    print(f"  PCA降维: {features.shape[1]}→{features_pca.shape[1]} 维, 解释方差={pca.explained_variance_ratio_.sum():.3f}")
    
    # 7. GMM+BIC确定最优K
    best_k, bic_scores = determine_optimal_k(features_pca, K_MIN, K_MAX)
    print(f"  最优K={best_k} (BIC: {[f'{b:.0f}' for b in bic_scores]})")
    
    # 8. K-means聚类
    labels, kmeans_model = apply_kmeans(features_pca, best_k)
    
    cluster_counts = np.bincount(labels)
    print(f"  各habitat体素数: {cluster_counts}")
    
    # 9. 保存habitat masks
    ref_img = dwi_img if dwi_img is not None else mask_img
    mask_path = save_habitat_masks(labels, indices, ref_img, case_no, MASK_DIR, best_k)
    
    # 10. 尝试绘制BIC曲线
    try:
        plot_bic_curve(bic_scores, K_MIN, case_no, MASK_DIR)
    except Exception as e:
        pass
    
    # 记录结果
    results.append({
        'Case_No.': case_no,
        'Name': name,
        'N_voxels': len(features),
        'N_features': features.shape[1],
        'PCA_dims': features_pca.shape[1],
        'Best_K': best_k,
        'BIC_scores': str([f'{b:.0f}' for b in bic_scores]),
        'Cluster_sizes': str(cluster_counts.tolist()),
        'Habitat_dir': os.path.join('habitat_masks', case_no),
    })
    
    # 每50例保存中间结果
    if (idx + 1) % 50 == 0:
        pd.DataFrame(results).to_csv(
            os.path.join(OUTPUT_DIR, "habitat_cluster_info_partial.csv"), 
            index=False, encoding='utf-8-sig')
        print(f"  [中间保存: {len(results)}例]")

# ========== 保存结果 ==========
df_results = pd.DataFrame(results)
df_results.to_csv(os.path.join(OUTPUT_DIR, "habitat_cluster_info.csv"), 
                  index=False, encoding='utf-8-sig')

print(f"\n{'='*60}")
print(f"完成! 成功处理 {len(results)}/{len(df)} 例")
print(f"结果: {os.path.join(OUTPUT_DIR, 'habitat_cluster_info.csv')}")
print(f"Masks: {MASK_DIR}/")

# 统计K值分布
print(f"\nK值分布:")
k_dist = df_results['Best_K'].value_counts().sort_index()
for k, v in k_dist.items():
    print(f"  K={k}: {v}例 ({v/len(df_results)*100:.1f}%)")
