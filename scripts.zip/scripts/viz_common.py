#!/usr/bin/env python3
"""统一数据加载模块 - 供所有可视化脚本使用"""
import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
from sklearn.preprocessing import StandardScaler
from sksurv.linear_model import CoxnetSurvivalAnalysis
from lifelines import CoxPHFitter

CLIN_PATH = '<DATA_ROOT>/分析结果/merged_data_corrected.csv'
DWI_PATH = '<PROJECT_ROOT>/data/features/dwi_pyradiomics_k3.csv'
DCE_PATH = '<PROJECT_ROOT>/data/features/dce_pyradiomics_k3.csv'
MODEL_PATH = '<PROJECT_ROOT>/results/models/model_comparison_all.csv'
DWI_CLUSTER = '<PROJECT_ROOT>/data/dwi_cluster_info_k3.csv'
DCE_CLUSTER = '<PROJECT_ROOT>/data/dce_cluster_info_k3.csv'

CLIN_VARS = ['NAC','N','Age','Grade','T','ALN','proRT','ER','PR','Her2','Meno']
M4C_VARS = ['NAC','N','Age','Grade','T','ALN','proRT','ER','PR','Her2','Meno',
            'original_shape_Sphericity','original_shape_Maximum3DDiameter']

def load_clinical():
    return pd.read_csv(CLIN_PATH)

def load_feature_df(seq, habitat='habitat_H'):
    """加载某个序列某生境的特征"""
    path = DCE_PATH if seq=='DCE' else DWI_PATH
    df = pd.read_csv(path)
    feats = [c for c in df.columns if c not in ['Case_No.','Habitat']]
    out = df[df['Habitat']==habitat][['Case_No.']+feats].drop_duplicates('Case_No.')
    return out

def build_m4c_df():
    """构建M4c模型完整数据框(临床+DCE_H 2特征)"""
    clin = load_clinical()
    dce_h = load_feature_df('DCE','habitat_H')
    df = clin.merge(dce_h, on='Case_No.', how='inner')
    df = df.dropna(subset=M4C_VARS+['DFS','Time'])
    return df

def build_survival_y(df):
    """构建sksurv格式的y"""
    return np.array(list(zip(df['DFS'].astype(bool), df['Time'])),
                    dtype=[('event','bool'),('time','float')])

def fit_m4c_lasso(df, alpha=0.022):
    """拟合M4c LASSO-Cox，返回risk scores和模型"""
    X = df[M4C_VARS].values
    y = build_survival_y(df)
    s = StandardScaler()
    Xs = s.fit_transform(X)
    cph = CoxnetSurvivalAnalysis(l1_ratio=1, alphas=[alpha], max_iter=10000).fit(Xs, y)
    risk = cph.predict(Xs).flatten()
    return cph, s, risk

def fit_m4c_cox(df, penalizer=0.01):
    """拟合M4c标准Cox(lifelines)，返回模型"""
    cph = CoxPHFitter(penalizer=penalizer)
    cph.fit(df[['Time','DFS']+M4C_VARS], 'Time', 'DFS')
    return cph
