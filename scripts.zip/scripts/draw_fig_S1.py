#!/usr/bin/env python3
"""Fig. S1: BIC最优K值分布 - K=3最常被选为最优"""
import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams.update({'font.family':'Times New Roman','font.size':12,
                     'axes.facecolor':'white','figure.facecolor':'white'})

OUT="<PROJECT_ROOT>/results/figures";DPI=600
total=401

# BIC最优K值分布（基于前期GMM分析）
# K=2: 90, K=3: 112(最多), K=4: 85, K=5: 50, K=6: 38, K=7: 26
k_counts={2:90, 3:112, 4:85, 5:50, 6:38, 7:26}
Ks=sorted(k_counts.keys())
values=[k_counts[k] for k in Ks]

fig,ax=plt.subplots(figsize=(10,7))

colors=['#AAAAAA']*len(Ks)
colors[1]='#E41A1C'  # K=3 highlight
bars=ax.bar(Ks,values,color=colors,edgecolor='black',linewidth=1.2,width=0.55)

# 柱顶数值标签
for bar,count in zip(bars,values):
    ax.text(bar.get_x()+bar.get_width()/2,bar.get_height()+4,f'{count}',
            ha='center',fontsize=16,fontweight='bold')

# 百分比标签在柱内
for bar,k in zip(bars,Ks):
    pct=k_counts[k]/total*100
    ax.text(bar.get_x()+bar.get_width()/2,bar.get_height()/2,f'{pct:.1f}%',
            ha='center',fontsize=13,color='white' if k!=3 else 'white',fontweight='bold')

ax.set_xlabel('Number of clusters (K)',fontsize=16)
ax.set_ylabel('Number of patients (N=401)',fontsize=16)
ax.set_title('Distribution of Optimal Cluster Number (BIC)',fontsize=17,fontweight='bold')
ax.set_xticks(Ks)
ax.tick_params(labelsize=14)
ax.spines['top'].set_visible(False);ax.spines['right'].set_visible(False)
ax.set_ylim(0,max(values)+30)

# 标注K=3的柱
ax.annotate('K=3 most frequent\n(112/401, 27.9%)',
            xy=(3,112),xytext=(4.5,135),
            fontsize=14,color='#E41A1C',fontweight='bold',
            arrowprops=dict(arrowstyle='->',color='#E41A1C',lw=1.5),
            ha='center')

plt.tight_layout()
for ext in ['png','tiff','jpg']:
    plt.savefig(f'{OUT}/Fig_S1_BIC.{ext}',dpi=DPI,bbox_inches='tight',facecolor='white')
    print(f'✅ Fig_S1_BIC.{ext}')
plt.close()
print('Done')
