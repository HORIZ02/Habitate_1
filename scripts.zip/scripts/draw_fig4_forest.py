# -*- coding: utf-8 -*-
"""R1-2: 重绘 Fig4 森林图 — HR 同尺度、log 轴、HR=1 参考线、标注与Table4一致"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter, NullFormatter

plt.rcParams['font.family']='serif'
plt.rcParams['font.serif']=['Times New Roman']
plt.rcParams['axes.linewidth']=0.9
plt.rcParams['axes.spines.top']=False
plt.rcParams['axes.spines.right']=False

# Table 4 (M4c 7-var standard Cox)
rows = [
    ("NAC",                      2.705, 1.484, 4.930, 0.001),
    ("N stage",                  1.474, 1.003, 2.165, 0.048),
    ("Grade",                    1.527, 0.945, 2.468, 0.084),
    ("ALN",                      1.699, 0.712, 4.056, 0.232),
    ("Postoperative RT",         1.720, 0.978, 3.024, 0.060),
    ("Sphericity (DCE_H)",       0.067, 0.009, 0.518, 0.0096),
    ("Maximum3DDiameter (DCE_H)",0.997, 0.981, 1.014, 0.748),
]
RED='#C00000'; BLACK='#000000'

labels=[r[0] for r in rows]
hr=np.array([r[1] for r in rows]); lo=np.array([r[2] for r in rows]); hi=np.array([r[3] for r in rows])
pv=np.array([r[4] for r in rows])
colors=[RED if p<0.05 else BLACK for p in pv]

fig,ax=plt.subplots(figsize=(9.5,5.6))
y=np.arange(len(rows))[::-1]
ax.set_xscale('log')
ax.axvline(1.0,color='#888888',lw=1.0,ls='--',zorder=1)
for yi,yv,l,h,c in zip(y,hr,lo,hi,colors):
    ax.plot([l,h],[yi,yi],color=c,lw=2.0,solid_capstyle='butt',zorder=3)
    ax.plot(yv,yi,'s',color=c,markersize=8,zorder=4)
ax.set_yticks(y); ax.set_yticklabels(labels,fontsize=12)
ax.set_ylim(-0.7,len(rows)-0.3)
ax.set_xlim(0.006,7.0)
ax.set_xlabel('Hazard ratio (log scale)',fontsize=13)
ax.set_title('Multivariable Cox regression for the M4c model',fontsize=14,pad=10)
sf=ScalarFormatter(); sf.set_scientific(False)
ax.xaxis.set_major_formatter(sf)
ax.xaxis.set_minor_formatter(NullFormatter())
ax.set_xticks([0.01,0.05,0.1,0.5,1,2,5])
ax.set_xticklabels(['0.01','0.05','0.1','0.5','1','2','5'],fontsize=11)
ax.tick_params(axis='y',length=0)

# 右侧数值标注（与Table4一致）
xmax=ax.get_xlim()[1]
for yi,(lab,h,l,hh,p) in zip(y,rows):
    if p<0.001: ptxt='<0.001'
    elif p<0.01: ptxt=f'{p:.4f}'
    else: ptxt=f'{p:.3f}'
    txt=f'{h:.3f} ({l:.3f}\u2013{hh:.3f})  P={ptxt}'
    ax.text(0.99,yi,txt,transform=ax.get_yaxis_transform(),ha='left',va='center',
            fontsize=10,color=(RED if p<0.05 else BLACK))
ax.text(0.99,len(rows)-0.35,'HR (95% CI)   P',transform=ax.get_yaxis_transform(),ha='left',va='center',
        fontsize=10,fontstyle='italic',color='#333333')
plt.subplots_adjust(right=0.60,left=0.26,top=0.90,bottom=0.13)
fig.text(0.26,0.02,'Red = P < 0.05; black = non-significant. HR and 95% CI shown on the same (HR) scale; dashed line at HR = 1.',
         fontsize=9,style='italic',color='#000000')
for ext,dpi in [('png',600),('tiff',300)]:
    fig.savefig(rf'<PROJECT_ROOT>\results\figures\Fig4_forest_corrected.{ext}',dpi=dpi,bbox_inches='tight')
print('✅ Fig4_forest_corrected 已生成 (png 600dpi + tiff 300dpi)')
