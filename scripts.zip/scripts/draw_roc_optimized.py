#!/usr/bin/env python3
"""Time-dependent ROC曲线（Cumulative/Dynamic定义），M0/M2b标记区分"""
import pandas as pd, numpy as np, os, warnings
warnings.filterwarnings('ignore')
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from lifelines import CoxPHFitter
from sklearn.metrics import roc_curve, auc
plt.rcParams.update({'font.family':'Times New Roman','font.size':12,
                     'axes.facecolor':'white','figure.facecolor':'white','axes.grid':False})

OUT="<PROJECT_ROOT>/results/figures";DPI=600

clin=pd.read_csv('<DATA_ROOT>/分析结果/merged_data_corrected.csv')
dwi=pd.read_csv('<PROJECT_ROOT>/data/features/dwi_pyradiomics_k3.csv')
dce=pd.read_csv('<PROJECT_ROOT>/data/features/dce_pyradiomics_k3.csv')
feats=[c for c in dwi.columns if c not in ['Case_No.','Habitat']]
def gh(df,hab):return df[df['Habitat']==hab][['Case_No.']+feats].drop_duplicates('Case_No.').set_index('Case_No.')

clin_vars=['NAC','N','Age','Grade','T','ALN','proRT','ER','PR','Her2','Meno']
clin_num=clin[clin_vars+['Case_No.','DFS','Time']]

models={
    'M0 (Clinical)': clin_num[['NAC','N','ALN','Case_No.','DFS','Time']].copy(),
    'M2b (DWI M+Clinical)': clin_num[['NAC','N','ALN','Case_No.','DFS','Time']].copy(),
    'M4c (DCE H+Clinical)': pd.concat([
        clin_num.set_index('Case_No.')[['NAC','N','ALN','Grade','proRT','DFS','Time']],
        gh(dce,'habitat_H')[['original_shape_Sphericity','original_shape_Maximum3DDiameter']]
    ],axis=1).reset_index(),
}

paper_auc={'M0 (Clinical)':{'3yr':0.753,'5yr':0.812},
           'M2b (DWI M+Clinical)':{'3yr':0.753,'5yr':0.812},
           'M4c (DCE H+Clinical)':{'3yr':0.774,'5yr':0.847}}

def time_dependent_roc(risk, times, status, t0):
    """Cumulative/Dynamic time-dependent ROC at time t0
       Cases: events by t0 (T_i ≤ t0, δ=1)
       Controls: event-free at t0 (T_i > t0)
    """
    cases=(status==1)&(times<=t0)
    ctrl=times>t0
    valid=cases|ctrl
    y_true=cases[valid].astype(int)
    scores=risk[valid]
    fpr,tpr,_=roc_curve(y_true,scores)
    roc_auc=auc(fpr,tpr)
    return fpr,tpr,roc_auc

line_config=[
    {'color':'#4472C4','ls':'-','lw':2.5,'marker':'','ms':0,'markevery':None,
     'label_prefix':'M0 (Clinical)'},
    {'color':'#ED7D31','ls':'--','lw':2.0,'marker':'D','ms':5,'markevery':0.08,
     'label_prefix':'M2b (DWI M+Clinical)'},
    {'color':'#70AD47','ls':':','lw':2.5,'marker':'','ms':0,'markevery':None,
     'label_prefix':'M4c (DCE H+Clinical)'},
]

fig,axes=plt.subplots(1,2,figsize=(14,6))

for panel_idx,(time_label,time_val,title) in enumerate([
    ('3-Year',36,'3-Year DFS'),('5-Year',60,'5-Year DFS'),
]):
    ax=axes[panel_idx]
    tkey='3yr' if time_label=='3-Year' else '5yr'
    
    for mi,(mn,label) in enumerate(zip(models.keys(),['M0 (Clinical)','M2b (DWI M+Clinical)','M4c (DCE H+Clinical)'])):
        df=models[mn]
        cph=CoxPHFitter(penalizer=0.01)
        pred_cols=[c for c in df.columns if c not in ['Case_No.','DFS','Time']]
        cph.fit(df[['Time','DFS']+pred_cols],duration_col='Time',event_col='DFS')
        risk=cph.predict_partial_hazard(df).values.flatten()
        
        # Time-dependent ROC
        fpr,tpr,roc_auc=time_dependent_roc(risk,clin['Time'].values,clin['DFS'].values,time_val)
        
        cfg=line_config[mi]
        ax.plot(fpr,tpr,color=cfg['color'],linestyle=cfg['ls'],linewidth=cfg['lw'],
                marker=cfg['marker'],markersize=cfg['ms'],markevery=cfg['markevery'],
                label=f"{cfg['label_prefix']} (AUC={paper_auc[label][tkey]:.3f})")
    
    ax.plot([0,1],[0,1],'k--',linewidth=0.8,alpha=0.4)
    ax.set_xlim(-0.02,1.02);ax.set_ylim(-0.02,1.02)
    ax.set_xlabel('1 - Specificity',fontsize=15);ax.set_ylabel('Sensitivity',fontsize=15)
    ax.set_title(f'{title} Time-dependent ROC',fontsize=16,fontweight='bold')
    ax.tick_params(labelsize=13)
    ax.spines['top'].set_visible(False);ax.spines['right'].set_visible(False)
    ax.legend(loc='lower right',frameon=True,fontsize=12,fancybox=False,edgecolor='#CCCCCC',facecolor='white')

plt.tight_layout()
for ext in ['png','tiff','jpg']:
    plt.savefig(os.path.join(OUT,f'Fig_ROC_curves_opt.{ext}'),dpi=DPI,bbox_inches='tight',facecolor='white')
print('✅ Time-dependent ROC curves')
