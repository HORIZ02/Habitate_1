# -*- coding: utf-8 -*-
"""
23b_spatial_incremental_modeling.py  —  第3b步：空间特征增量价值检验

特征池（缺失率>20%的一律排除，即剔除 DWI fractal_dim×3）：
  P1 = 新空间特征中 max|ρ|(vs 856 radiomics) < 0.80 的「新颖池」
  P2 = 全部空间特征（对照池）

模型（统一 LASSO-Cox，l1_ratio=1）：
  M0      : 临床11变量
  M4c     : DCE_H纹理(107) + 临床(11)      ← 原论文参照系
  M4c+P1  : + 新颖池                        ← 核心问题
  M4c+P2  : + 全部空间特征
  临床+P1 : 临床 + 新颖池
  P1_only : 仅新颖池

双口径评估（务必区分，勿混用）：
  ① C_index_CV  —— 复现原项目 run_lasso_cv：20个alpha里选CV最优 → 与原表 0.7092 可比，
                   但含 alpha 选择偏倚（乐观）
  ② C_index_OOF —— 嵌套CV（外层5折 / 内层5折选alpha）→ 干净的无偏 OOF 估计
                   + Bootstrap 1000次患者重采样 95%CI
                   + 相对 M4c 的配对 Bootstrap ΔC-index 与双侧 p

输入：data/features/habitat_spatial_features_k3.csv
      data/features/dce_pyradiomics_k3.csv
      <DATA_ROOT>/分析结果/merged_data_corrected.csv
      results/models/spatial_redundancy_summary_k3.csv   (P1 名单来源)
输出：results/models/model_comparison_spatial_k3.csv
      results/models/model_comparison_spatial_k3.md
"""
import os, warnings, time
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold
from sksurv.linear_model import CoxnetSurvivalAnalysis
from sksurv.metrics import concordance_index_censored, cumulative_dynamic_auc

warnings.filterwarnings('ignore')

BASE = r'<PROJECT_ROOT>'
OUT = os.path.join(BASE, 'results', 'models')
os.makedirs(OUT, exist_ok=True)

CLIN_VARS = ['NAC', 'N', 'Age', 'Grade', 'T', 'ALN', 'proRT', 'ER', 'PR', 'Her2', 'Meno']
ALPHAS = np.logspace(-1.5, 0, 20)
MAX_MISSING = 0.20
N_BOOT = 1000
SEED = 42


def make_surv(df):
    return np.array([(bool(e), float(t)) for e, t in zip(df['DFS'], df['Time'])],
                    dtype=[('event', 'bool'), ('time', 'float')])


def run_lasso_cv(X, y, alphas=ALPHAS):
    """复现原项目口径：20 alpha 取 CV 最优；返回 (best_c, best_alpha, selected_series)"""
    Xs = X.values
    kf = KFold(5, shuffle=True, random_state=SEED)
    cv = {a: [] for a in alphas}
    for tr, te in kf.split(Xs):
        s = StandardScaler()
        Xtr = s.fit_transform(Xs[tr]); Xte = s.transform(Xs[te])
        try:
            cph = CoxnetSurvivalAnalysis(l1_ratio=1, alphas=alphas, max_iter=10000).fit(Xtr, y[tr])
            for a in alphas:
                try:
                    p = cph.predict(Xte, alpha=a)
                    cv[a].append(concordance_index_censored(y['event'][te], y['time'][te], p)[0])
                except Exception:
                    cv[a].append(0.5)
        except Exception:
            for a in alphas:
                cv[a].append(0.5)
    cm = {a: float(np.mean(v)) for a, v in cv.items()}
    ba = max(cm, key=cm.get)
    if all(v <= 0.5 for v in cm.values()):
        return 0.5, 0.1, pd.Series(dtype=float)
    s = StandardScaler(); Xf = s.fit_transform(Xs)
    cph = CoxnetSurvivalAnalysis(l1_ratio=1, alphas=[ba], max_iter=10000).fit(Xf, y)
    coef = cph.coef_.flatten()
    return cm[ba], ba, pd.Series(coef, index=X.columns)[coef != 0].sort_values(key=np.abs, ascending=False)


def nested_oof(X, y, alphas=ALPHAS, seed=SEED):
    """嵌套CV：外层5折留出，内层5折选alpha → 干净 OOF 风险分"""
    Xs = X.values
    n = len(Xs)
    oof = np.full(n, np.nan)
    outer = KFold(5, shuffle=True, random_state=seed)
    for tr, te in outer.split(Xs):
        s = StandardScaler()
        Xtr = s.fit_transform(Xs[tr]); Xte = s.transform(Xs[te])
        inner = KFold(5, shuffle=True, random_state=seed + 1)
        sc = {a: [] for a in alphas}
        for itr, ite in inner.split(Xtr):
            si = StandardScaler()
            Xi = si.fit_transform(Xtr[itr]); Xv = si.transform(Xtr[ite])
            try:
                c = CoxnetSurvivalAnalysis(l1_ratio=1, alphas=alphas, max_iter=10000).fit(Xi, y[tr][itr])
                for a in alphas:
                    try:
                        p = c.predict(Xv, alpha=a)
                        sc[a].append(concordance_index_censored(y[tr]['event'][ite],
                                                               y[tr]['time'][ite], p)[0])
                    except Exception:
                        sc[a].append(0.5)
            except Exception:
                for a in alphas:
                    sc[a].append(0.5)
        ba = max({a: float(np.mean(v)) for a, v in sc.items()}, key=lambda a: np.mean(sc[a]))
        try:
            c = CoxnetSurvivalAnalysis(l1_ratio=1, alphas=[ba], max_iter=10000).fit(Xtr, y[tr])
            oof[te] = c.predict(Xte).flatten()
        except Exception:
            oof[te] = 0.0
    return oof


def boot_ci(ev, tm, risk, n_boot=N_BOOT, seed=SEED):
    rng = np.random.default_rng(seed)
    n = len(risk)
    cs = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, n)
        if ev[idx].sum() < 3:
            continue
        try:
            cs.append(concordance_index_censored(ev[idx], tm[idx], risk[idx])[0])
        except Exception:
            pass
    cs = np.array(cs)
    return (float(np.percentile(cs, 2.5)), float(np.percentile(cs, 97.5))) if len(cs) else (np.nan, np.nan)


def paired_boot(ev, tm, r1, r2, n_boot=N_BOOT, seed=SEED):
    """ΔC = C(r1) - C(r2)，患者配对重采样"""
    rng = np.random.default_rng(seed + 7)
    n = len(r1)
    ds = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, n)
        if ev[idx].sum() < 3:
            continue
        try:
            a = concordance_index_censored(ev[idx], tm[idx], r1[idx])[0]
            b = concordance_index_censored(ev[idx], tm[idx], r2[idx])[0]
            ds.append(a - b)
        except Exception:
            pass
    ds = np.array(ds)
    if not len(ds):
        return np.nan, np.nan, np.nan, np.nan
    p = 2 * min((ds > 0).mean(), (ds < 0).mean())
    return float(np.percentile(ds, 2.5)), float(np.percentile(ds, 97.5)), float(ds.mean()), float(min(p, 1.0))


def main():
    t0 = time.time()
    # ---------- 数据 ----------
    clin = pd.read_csv(r'<DATA_ROOT>\分析结果\merged_data_corrected.csv', encoding='utf-8-sig')
    clin['Case_No.'] = clin['Case_No.'].astype(str)
    y = make_surv(clin)
    ev, tm = y['event'].astype(bool), y['time'].astype(float)

    # DCE_H 纹理（M4c 基础）
    rad = pd.read_csv(os.path.join(BASE, 'data', 'features', 'dce_pyradiomics_k3.csv'))
    rad['Case_No.'] = rad['Case_No.'].astype(str)
    rf = [c for c in rad.columns if c not in ('Case_No.', 'Habitat')]
    radH = rad[rad.Habitat == 'habitat_H'].drop_duplicates('Case_No.').set_index('Case_No.')[rf]

    # 空间特征 → 宽表
    sp = pd.read_csv(os.path.join(BASE, 'data', 'features', 'habitat_spatial_features_k3.csv'))
    sp['Case_No.'] = sp['Case_No.'].astype(str)
    a = sp[sp.modality == 'DWI'].set_index('Case_No.')[[c for c in sp.columns if c.startswith('dwi_')]]
    b = sp[sp.modality == 'DCE'].set_index('Case_No.')[[c for c in sp.columns if c.startswith('dce_')]]
    spw = pd.concat([a, b], axis=1)

    # 缺失率>20% 排除
    miss = spw.isna().mean()
    dropped = sorted(miss[miss > MAX_MISSING].index)
    spw = spw[miss[miss <= MAX_MISSING].index]

    # P1 = 新颖池
    red = pd.read_csv(os.path.join(OUT, 'spatial_redundancy_summary_k3.csv'))
    novel = set(red[red.max_abs_r < 0.80].feature)
    P1 = [c for c in spw.columns if c in novel]
    P2 = list(spw.columns)
    print(f'缺失>20% 排除 {len(dropped)}: {dropped}')
    print(f'P1 新颖池 {len(P1)}  |  P2 对照池 {len(P2)}')

    order = clin['Case_No.']
    S = spw.loc[order].reset_index(drop=True)
    R = radH.loc[order].reset_index(drop=True)
    C = clin[CLIN_VARS].reset_index(drop=True)

    models = [
        ('M0_临床',      '临床11变量',                pd.concat([C], axis=1)),
        ('M4c_原论文',   'DCE_H纹理+临床',            pd.concat([C, R.add_prefix('DCEH_')], axis=1)),
        ('M4c+P1',       'DCE_H纹理+临床+新颖空间池',  pd.concat([C, R.add_prefix('DCEH_'), S[P1]], axis=1)),
        ('M4c+P2',       'DCE_H纹理+临床+全部空间池',  pd.concat([C, R.add_prefix('DCEH_'), S[P2]], axis=1)),
        ('临床+P1',      '临床+新颖空间池',            pd.concat([C, S[P1]], axis=1)),
        ('P1_only',      '仅新颖空间池',               pd.concat([S[P1]], axis=1)),
    ]

    rows, oofs = [], {}
    for name, desc, X in models:
        X = X.fillna(0).astype(float)
        t1 = time.time()
        c_cv, alpha, sel = run_lasso_cv(X, y)
        oof = nested_oof(X, y)
        c_oof = concordance_index_censored(ev, tm, oof)[0]
        lo, hi = boot_ci(ev, tm, oof)
        try:
            auc3 = float(cumulative_dynamic_auc(y, y, oof, times=[36])[0][0])
            auc5 = float(cumulative_dynamic_auc(y, y, oof, times=[60])[0][0])
        except Exception:
            auc3 = auc5 = np.nan
        oofs[name] = oof
        rows.append(dict(Model=name, Desc=desc, Features_in=X.shape[1],
                         Features_selected=len(sel),
                         C_index_CV=round(c_cv, 4), alpha=round(float(alpha), 4),
                         C_index_OOF=round(c_oof, 4), OOF_CI_low=round(lo, 4), OOF_CI_high=round(hi, 4),
                         AUC_3yr_OOF=round(auc3, 4) if auc3 == auc3 else np.nan,
                         AUC_5yr_OOF=round(auc5, 4) if auc5 == auc5 else np.nan,
                         selected_top=','.join(sel.index[:6].tolist())))
        print(f'  [{name}] in={X.shape[1]} sel={len(sel)}  C_CV={c_cv:.4f}  '
              f'C_OOF={c_oof:.4f} [{lo:.3f},{hi:.3f}]  ({time.time()-t1:.0f}s)', flush=True)

    df = pd.DataFrame(rows)

    # 相对 M4c 的配对 Bootstrap
    ref = 'M4c_原论文'
    for c1, c2 in [('OOF_CI_low', 'OOF_CI_high')]:
        pass
    dl, dh, dm, dp = [], [], [], []
    for name in df.Model:
        if name == ref:
            dl.append(np.nan); dh.append(np.nan); dm.append(np.nan); dp.append(np.nan); continue
        lo, hi, m, p = paired_boot(ev, tm, oofs[name], oofs[ref])
        dl.append(round(lo, 4)); dh.append(round(hi, 4)); dm.append(round(m, 4)); dp.append(round(p, 4))
    df['dC_vs_M4c'] = dm
    df['dC_CI_low'] = dl
    df['dC_CI_high'] = dh
    df['dC_p'] = dp

    df.to_csv(os.path.join(OUT, 'model_comparison_spatial_k3.csv'), index=False)

    # ---------- 报告 ----------
    L = ['# 空间特征增量价值检验（3b）\n']
    L.append(f'> 队列 401 例 / 事件 55 (13.7%) | LASSO-Cox (l1_ratio=1) | 排除缺失>20%特征 {len(dropped)} 个')
    L.append(f'> P1 新颖池 = max|ρ|<0.80（{len(P1)} 个）｜ P2 对照池 = 全部（{len(P2)} 个）\n')
    L.append('## 主表\n')
    L.append('| 模型 | 输入特征 | LASSO选中 | C-index(CV,原口径) | **C-index(OOF)** | **OOF 95%CI** | AUC3yr | AUC5yr |')
    L.append('|---|---|---|---|---|---|---|---|')
    for _, r in df.iterrows():
        L.append(f"| {r.Model} | {r.Features_in} | {r.Features_selected} | {r.C_index_CV:.4f} | "
                 f"**{r.C_index_OOF:.4f}** | {r.OOF_CI_low:.3f}–{r.OOF_CI_high:.3f} | "
                 f"{r.AUC_3yr_OOF if pd.notna(r.AUC_3yr_OOF) else 'NA'} | "
                 f"{r.AUC_5yr_OOF if pd.notna(r.AUC_5yr_OOF) else 'NA'} |")
    L.append('')
    L.append('## 相对 M4c 的配对 Bootstrap ΔC-index\n')
    L.append('| 模型 | ΔC vs M4c | 95%CI | 双侧 p | 结论 |')
    L.append('|---|---|---|---|---|')
    for _, r in df.iterrows():
        if r.Model == ref:
            L.append(f"| {r.Model} | — | — | — | 参照系 |"); continue
        concl = ('显著提升' if (pd.notna(r.dC_p) and r.dC_p < 0.05 and r.dC_vs_M4c > 0) else
                 '显著下降' if (pd.notna(r.dC_p) and r.dC_p < 0.05 and r.dC_vs_M4c < 0) else '无显著差异')
        L.append(f"| {r.Model} | {r.dC_vs_M4c:+.4f} | {r.dC_CI_low:+.3f}–{r.dC_CI_high:+.3f} | "
                 f"{r.dC_p:.4f} | {concl} |")
    L.append('')
    L.append('## LASSO 入选的 top 特征（全样本拟合，仅作参考）\n')
    for _, r in df.iterrows():
        L.append(f"- **{r.Model}** ({r.Features_selected} 个): {r.selected_top}")
    L.append('')
    L.append('## 口径说明\n')
    L.append('- `C_index_CV`：复现原项目口径（20个alpha中选CV最优），**含alpha选择偏倚，偏乐观**，')
    L.append('  用于与原 `model_comparison_all.csv`（M4c=0.7092）对标。')
    L.append('- `C_index_OOF`：嵌套CV（外层5折留出/内层5折选alpha）的合并OOF估计，**无偏**，为主结论依据。')
    L.append('- Bootstrap 95%CI：1000次患者级重采样（OOF风险分）。')
    L.append('- ΔC：配对Bootstrap（同一重采样下算两模型C-index之差），双侧p。')
    with open(os.path.join(OUT, 'model_comparison_spatial_k3.md'), 'w', encoding='utf-8') as fh:
        fh.write('\n'.join(L))

    print('\n=== 结果 ===')
    print(df[['Model', 'Features_in', 'Features_selected', 'C_index_CV',
              'C_index_OOF', 'OOF_CI_low', 'OOF_CI_high', 'dC_vs_M4c', 'dC_p']].to_string(index=False))
    print(f'\n-> {OUT}  ({time.time()-t0:.0f}s)')


if __name__ == '__main__':
    main()
