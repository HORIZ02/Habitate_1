# -*- coding: utf-8 -*-
"""
21_spatial_features_k3.py  —  HER2-low 生境空间结构特征提取（K=3）

适配自前列腺项目(E:\liangyixin)已验证脚本 21_spatial_features_multik.py，
特征数学完全一致，仅改：
  ① mask 读取：子目录结构  data/{mod}_habitat_masks_k3/{Case}/habitat_{L}.nii.gz
  ② 病例列表：扫描 mask 子目录名
  ③ 模态：DWI / DCE（tag = dwi / dce）
  ④ 标签：K=3 → ['L','M','H']

每例每模态 42 个特征：
  单生境形态 11 × 3 = 33
  生境两两交互 3 × 3 = 9   (LM / LH / MH 的 interface, interface_norm, centroid_dist)
DWI + DCE = 84 特征/例

关键约定（与前列腺一致，勿改）：
  - 多生境统一 bbox 裁剪（基于 L|M|H 并集，±2 padding）
  - 表面积 marching_cubes（体素面计数会系统性低估 → 球度 >1）
  - 距离 distance_transform_edt(sampling=spacing) → 物理量纲 mm
  - 界面 binary_dilation(A) & B
  - 径向量除以等效半径 R_eq 消除肿瘤大小影响

输出：data/features/habitat_spatial_features_k3.csv
支持断点续跑（读已有 CSV，跳过 (Case, modality)）+ 每模态增量写盘
"""
import os, sys, time, warnings, itertools
import numpy as np
import pandas as pd
import nibabel as nib
from scipy import ndimage
from skimage import measure
from skimage.measure import euler_number

warnings.filterwarnings('ignore')

BASE_DIR = r'<PROJECT_ROOT>'
MODS     = ['dwi', 'dce']          # 目录名小写 = 特征名前缀
LABELS   = ['L', 'M', 'H']         # K=3
STRUCT26 = np.ones((3, 3, 3), dtype=bool)

OUT_CSV  = os.path.join(BASE_DIR, 'data', 'features', 'habitat_spatial_features_k3.csv')
LOG_TXT  = os.path.join(BASE_DIR, 'data', 'features', 'spatial_features_k3_log.txt')

SINGLE_FEATS = ['n_voxels', 'n_components', 'largest_frac', 'euler', 'surface', 'sphericity',
                'fractal_dim', 'centroid_dist', 'radial_mean', 'radial_sd', 'edge_dist_mean']


def log(msg):
    line = f'[{time.strftime("%Y-%m-%d %H:%M:%S")}] {msg}'
    print(line, flush=True)
    with open(LOG_TXT, 'a', encoding='utf-8') as f:
        f.write(line + '\n')


def surface_area(mask, spacing):
    if not mask.any():
        return 0.0
    try:
        padded = np.pad(mask.astype(np.float32), 1)
        v, f, _, _ = measure.marching_cubes(padded, level=0.5, spacing=spacing)
        return float(measure.mesh_surface_area(v, f))
    except Exception:
        return np.nan


def fractal_dim(mask):
    if not mask.any():
        return np.nan
    coords = np.argwhere(mask)
    mn, mx = coords.min(0), coords.max(0) + 1
    crop = mask[mn[0]:mx[0], mn[1]:mx[1], mn[2]:mx[2]]
    counts, sizes = [], []
    for box in [2, 4, 8, 16]:
        if any(s < box for s in crop.shape):
            continue
        d = [crop.shape[i] // box * box for i in range(3)]
        if min(d) == 0:
            continue
        sub = crop[:d[0], :d[1], :d[2]]
        counts.append(sub.reshape(d[0] // box, box, d[1] // box, box, d[2] // box, box)
                         .max(axis=(1, 3, 5)).sum())
        sizes.append(box)
    if len(counts) < 2:
        return np.nan
    return float(np.polyfit(np.log(1.0 / np.array(sizes, float)),
                            np.log(np.array(counts, float)), 1)[0])


def process_case(case, mod):
    """返回特征 dict，或 None（缺文件/空肿瘤）"""
    mdir = os.path.join(BASE_DIR, 'data', f'{mod}_habitat_masks_k3', case)

    masks, spacing = {}, None
    for L in LABELS:
        fp = os.path.join(mdir, f'habitat_{L}.nii.gz')
        if not os.path.exists(fp):
            return None, f'缺 habitat_{L}.nii.gz'
        im = nib.load(fp)
        masks[L] = im.get_fdata() > 0.5
        if spacing is None:
            spacing = tuple(float(s) for s in im.header.get_zooms()[:3])

    tumor = np.zeros_like(masks[LABELS[0]], dtype=bool)
    for L in LABELS:
        tumor |= masks[L]
    nv_t = int(tumor.sum())
    if nv_t == 0:
        return None, '空肿瘤'

    # ---- 统一 bbox 裁剪（关键：必须基于 L|M|H 并集）----
    cs = np.argwhere(tumor)
    mn = np.clip(cs.min(0) - 2, 0, None).astype(int)
    mx = (cs.max(0) + 3).astype(int)
    sl = tuple(slice(int(mn[i]), int(mx[i])) for i in range(3))
    M = {L: masks[L][sl] for L in LABELS}
    Tc = np.zeros_like(M[LABELS[0]], dtype=bool)
    for L in LABELS:
        Tc |= M[L]

    vox_vol = spacing[0] * spacing[1] * spacing[2]
    R_eq = (3 * nv_t * vox_vol / (4 * np.pi)) ** (1 / 3)
    tcent = (np.argwhere(Tc) * np.array(spacing)).mean(axis=0)
    boundary = Tc & ~ndimage.binary_erosion(Tc, structure=STRUCT26)
    dist_map = ndimage.distance_transform_edt(~boundary, sampling=spacing) if boundary.any() else None

    rec = {'Case_No.': case, 'modality': mod.upper()}
    surf = {}

    # ---- 单生境形态（11 × 3）----
    for L in LABELS:
        msk = M[L]
        nv = int(msk.sum())
        if nv == 0:
            for kk in SINGLE_FEATS:
                rec[f'{mod}_{L}_{kk}'] = 0 if kk in ('n_voxels', 'n_components', 'euler') else np.nan
            surf[L] = 0.0
            continue
        lab, ncomp = ndimage.label(msk, structure=STRUCT26)
        sizes = ndimage.sum(msk, lab, range(1, ncomp + 1))
        eul = float(euler_number(msk, connectivity=3))
        sa = surface_area(msk, spacing)
        surf[L] = sa if sa == sa else 0.0
        Rh = (3 * nv * vox_vol / (4 * np.pi)) ** (1 / 3)
        sph = (4 * np.pi * Rh ** 2) / sa if (sa and sa > 0) else np.nan
        fd = fractal_dim(msk)
        hc = (np.argwhere(msk) * np.array(spacing)).mean(axis=0)
        cdist = float(np.linalg.norm(hc - tcent) / R_eq) if R_eq > 0 else np.nan
        d = np.linalg.norm((np.argwhere(msk) * np.array(spacing)) - tcent, axis=1)
        rmean = float(d.mean() / R_eq) if R_eq > 0 else np.nan
        rsd = float(d.std(ddof=1) / R_eq) if (len(d) > 1 and R_eq > 0) else np.nan
        edm = float(dist_map[msk].mean()) if dist_map is not None else np.nan
        rec.update({
            f'{mod}_{L}_n_voxels': nv,
            f'{mod}_{L}_n_components': int(ncomp),
            f'{mod}_{L}_largest_frac': round(float(sizes.max()) / nv, 4),
            f'{mod}_{L}_euler': eul,
            f'{mod}_{L}_surface': round(sa, 3) if sa == sa else np.nan,
            f'{mod}_{L}_sphericity': round(sph, 4) if sph == sph else np.nan,
            f'{mod}_{L}_fractal_dim': round(fd, 4) if fd == fd else np.nan,
            f'{mod}_{L}_centroid_dist': round(cdist, 4) if cdist == cdist else np.nan,
            f'{mod}_{L}_radial_mean': round(rmean, 4) if rmean == rmean else np.nan,
            f'{mod}_{L}_radial_sd': round(rsd, 4) if rsd == rsd else np.nan,
            f'{mod}_{L}_edge_dist_mean': round(edm, 4) if edm == edm else np.nan,
        })

    # ---- 生境两两交互（3 × 3）----
    sp2 = sorted(spacing)
    for A, B in itertools.combinations(LABELS, 2):
        A_dil = ndimage.binary_dilation(M[A], structure=STRUCT26)
        iface = int(np.sum(A_dil & M[B])) * sp2[0] * sp2[1]
        avg_s = (surf.get(A, 0) + surf.get(B, 0)) / 2
        rec[f'{mod}_{A}_{B}_interface'] = round(iface, 3)
        rec[f'{mod}_{A}_{B}_interface_norm'] = round(iface / avg_s, 4) if avg_s > 0 else np.nan
        if M[A].any() and M[B].any():
            ca = (np.argwhere(M[A]) * np.array(spacing)).mean(axis=0)
            cb = (np.argwhere(M[B]) * np.array(spacing)).mean(axis=0)
            rec[f'{mod}_{A}_{B}_centroid_dist'] = (
                round(float(np.linalg.norm(ca - cb) / R_eq), 4) if R_eq > 0 else np.nan)
        else:
            rec[f'{mod}_{A}_{B}_centroid_dist'] = np.nan

    return rec, None


def main():
    t0 = time.time()
    os.makedirs(os.path.dirname(OUT_CSV), exist_ok=True)

    # 病例列表 = DWI mask 子目录名（与 DCE 求交集）
    d_dwi = os.path.join(BASE_DIR, 'data', 'dwi_habitat_masks_k3')
    d_dce = os.path.join(BASE_DIR, 'data', 'dce_habitat_masks_k3')
    s_dwi = {x for x in os.listdir(d_dwi) if os.path.isdir(os.path.join(d_dwi, x))}
    s_dce = {x for x in os.listdir(d_dce) if os.path.isdir(os.path.join(d_dce, x))}
    cases = sorted(s_dwi & s_dce)
    log('=' * 66)
    log(f'K=3 生境空间结构特征提取 | DWI+DCE')
    log(f'  病例: DWI {len(s_dwi)} / DCE {len(s_dce)} / 交集 {len(cases)}')
    if s_dwi ^ s_dce:
        log(f'  ⚠ 两侧不一致: 仅DWI {sorted(s_dwi - s_dce)[:5]} | 仅DCE {sorted(s_dce - s_dwi)[:5]}')
    log(f'  LABELS={LABELS}  每例每模态 {11*3 + 3*3} 特征')
    log(f'  输出: {OUT_CSV}')

    # ---- 断点续跑 ----
    rows, done = [], set()
    if os.path.exists(OUT_CSV):
        try:
            prev = pd.read_csv(OUT_CSV)
            if len(prev):
                rows = prev.to_dict('records')
                done = set(zip(prev['Case_No.'].astype(str), prev['modality'].astype(str)))
                log(f'  续跑: 已有 {len(prev)} 行 ({len(done)} 个 Case×模态)')
        except Exception as e:
            log(f'  ⚠ 读取已有 CSV 失败，从零开始: {e}')

    n_ok = n_skip = n_fail = 0
    for i, case in enumerate(cases):
        for mod in MODS:
            if (case, mod.upper()) in done:
                n_skip += 1
                continue
            try:
                rec, why = process_case(case, mod)
            except Exception as e:
                n_fail += 1
                log(f'  ✗ [{case}/{mod.upper()}] 异常: {type(e).__name__}: {e}')
                continue
            if rec is None:
                n_fail += 1
                log(f'  ✗ [{case}/{mod.upper()}] 跳过: {why}')
                continue
            rows.append(rec)
            n_ok += 1
            # 每模态增量写盘（可随时中断）
            pd.DataFrame(rows).to_csv(OUT_CSV, index=False)
        if (i + 1) % 25 == 0 or (i + 1) == len(cases):
            el = time.time() - t0
            eta = el / max(i + 1, 1) * (len(cases) - i - 1)
            log(f'  进度 {i+1}/{len(cases)} | 新增 {n_ok} 跳过 {n_skip} 失败 {n_fail} '
                f'| 已用 {el/60:.1f}min | 预计剩余 {eta/60:.1f}min')

    df = pd.DataFrame(rows)
    df.to_csv(OUT_CSV, index=False)
    log('=' * 66)
    log(f'完成: {len(df)} 行 -> {OUT_CSV}')
    log(f'  新增 {n_ok} / 跳过 {n_skip} / 失败 {n_fail}')
    if len(df):
        log(f'  列数 {df.shape[1]}（含 Case_No./modality）| 病例数 {df["Case_No."].nunique()}')
        log(f'  模态分布: {df["modality"].value_counts().to_dict()}')
    log(f'  总耗时 {(time.time()-t0)/60:.1f} min')


if __name__ == '__main__':
    main()
