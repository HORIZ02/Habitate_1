#!/usr/bin/env python3
"""Fig. S2: 信号强度分布箱线图 - DWI和DCE三生境(L/M/H)"""
import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats as st
from scipy.stats import mannwhitneyu

plt.rcParams.update({'font.family':'Times New Roman','font.size':12,
                     'axes.facecolor':'white','figure.facecolor':'white'})

OUT="<PROJECT_ROOT>/results/figures";DPI=600

data={}
for mod in ['dwi','dce']:
    df=pd.read_csv(f"<PROJECT_ROOT>/data/{mod}_cluster_info_k3.csv",encoding='ISO-8859-1')
    data[mod]={h:df[f'Habitat_{h}_signal'].dropna().values for h in ['L','M','H']}

fig,axes=plt.subplots(1,2,figsize=(12,6))

for idx,(mod,label) in enumerate([('dwi','DWI'),('dce','DCE')]):
    ax=axes[idx]
    vals=[data[mod]['L'],data[mod]['M'],data[mod]['H']]
    
    # Filter outliers per group
    vals_clean=[]
    for v in vals:
        q1,q3=np.percentile(v,[5,95])
        vals_clean.append(v[(v>=q1)&(v<=q3)])
    
    bp=ax.boxplot(vals_clean,positions=[1,2,3],widths=0.5,patch_artist=True,
                  showfliers=True,flierprops=dict(marker='o',markersize=3,alpha=0.15,
                                                   markerfacecolor='#666666',markeredgecolor='none'))
    
    colors=['#2166AC','#4DAF4A','#E41A1C']
    for patch,c in zip(bp['boxes'],colors):
        patch.set_facecolor(c);patch.set_alpha(0.7);patch.set_edgecolor('black');patch.set_linewidth(1.2)
    for w in bp['whiskers']:w.set_color('#333333');w.set_linewidth(1.2)
    for c in bp['caps']:c.set_color('#333333');c.set_linewidth(1.2)
    for m in bp['medians']:m.set_color('black');m.set_linewidth(1.5)
    
    ax.set_xticks([1,2,3])
    ax.set_xticklabels(['Habitat L','Habitat M','Habitat H'],fontsize=14)
    ax.set_ylabel('Mean Signal Intensity',fontsize=15)
    ax.set_title(label,fontsize=16,fontweight='bold')
    ax.tick_params(labelsize=13)
    ax.spines['top'].set_visible(False);ax.spines['right'].set_visible(False)
    
    # P-values
    for i,(h1,h2) in enumerate([('L','M'),('M','H')]):
        v1,v2=data[mod][h1],data[mod][h2]
        if len(v1)>10 and len(v2)>10:
            _,p=mannwhitneyu(v1,v2,alternative='two-sided')
            if p<0.001: pt='***'
            elif p<0.01: pt='**'
            elif p<0.05: pt='*'
            else: pt=f'P={p:.3f}'
            ymax=max(np.percentile(v1,95),np.percentile(v2,95))
            ax.plot([i+1,i+2],[ymax*1.05,ymax*1.05],color='#333333',lw=1)
            ax.text(i+1.5,ymax*1.08,pt,ha='center',fontsize=12,fontweight='bold')

plt.tight_layout()
for ext in ['png','tiff','jpg']:
    plt.savefig(f'{OUT}/Fig_S2_Signal.{ext}',dpi=DPI,bbox_inches='tight',facecolor='white')
    print(f'Fig_S2_Signal.{ext}')
plt.close()
print('Done')
