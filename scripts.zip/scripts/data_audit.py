#!/usr/bin/env python3
"""完整数据一致性核对：正文 vs 表格 vs CSV"""
import pandas as pd, docx, re, numpy as np

DOC='<PROJECT_ROOT>/文章撰写/投稿版论文_V2.docx'
CSV='<PROJECT_ROOT>/results/models/model_comparison_all.csv'

doc=docx.Document(DOC)
mdf=pd.read_csv(CSV)
issues=[]

def check(cond, msg):
    if cond: issues.append(msg)

# ============ 1. 模型对比表 vs CSV ============
print('=== 1. 表格 vs CSV核对 ===')
tables=doc.tables

# Table 2 (纯影像) - index 1
t2=tables[1]
print('Table 2 纯影像模型:')
for ri in range(1,len(t2.rows)):
    cells=[c.text.strip() for c in t2.rows[ri].cells]
    model=cells[0]
    row=mdf[mdf['Model']==model]
    if len(row)>0:
        r=row.iloc[0]
        # C-index比较
        c_tab=cells[1]; c_csv=f"{r['C_index_CV']:.4f}"
        match='✅' if c_tab==c_csv else f'❌ 表{c_tab} vs CSV{c_csv}'
        print(f'  {model}: C-index {match}')

# Table 3 (联合模型) - index 2
print('Table 3 联合模型:')
t3=tables[2]
for ri in range(1,len(t3.rows)):
    cells=[c.text.strip() for c in t3.rows[ri].cells]
    model=cells[0]
    row=mdf[mdf['Model']==model]
    if len(row)>0:
        r=row.iloc[0]
        c_tab=cells[1]; c_csv=f"{r['C_index_CV']:.4f}"
        match='✅' if c_tab==c_csv else f'❌ 表{c_tab} vs CSV{c_csv}'
        print(f'  {model}: C-index {match}')

# Table 4 (多因素Cox) - index 3
print('Table 4 多因素Cox:')
t4=tables[3]
for ri in range(1,len(t4.rows)):
    cells=[c.text.strip() for c in t4.rows[ri].cells]
    print(f'  {cells[0]}: HR={cells[1]}, CI={cells[2]}, P={cells[3]}')

print()
print('=== 2. 正文 vs CSV核对 ===')
# 提取正文关键模型数据
full_text=' '.join([p.text for p in doc.paragraphs])
# M4c
m4c=mdf[mdf['Model']=='M4c'].iloc[0]
print(f"M4c 基准: C-index={m4c['C_index_CV']:.4f}, AUC3={m4c['AUC_3yr']:.4f}, AUC5={m4c['AUC_5yr']:.4f}, Brier={m4c['Brier']:.4f}")
# 检查正文是否一致
for pat in ['0.774','0.847','0.709']:
    found=pat in full_text
    print(f'  正文含{pat}: {found}')

print()
print('=== 3. 关键数值核对 ===')
# 样本量
print(f'  正文含401: {"401" in full_text}')
# 事件数
for pat in ['55 DFS events','55 (13.7','55 (13.7%)']:
    if pat.lower() in full_text.lower():
        print(f'  正文: {pat}')
# 纯影像模型数量描述
if 'eight pure imaging' in full_text.lower():
    print('  ❌ 正文仍写"eight pure imaging models"(应seven)')
elif 'seven pure imaging' in full_text.lower():
    print('  ✅ 正文写"seven pure imaging models"')

print()
print(f'发现 {len(issues)} 个问题:')
for i in issues: print(f'  - {i}')
