#!/usr/bin/env python3
"""重建Table 4为M4c 7变量标准Cox结果, 修复eight→seven, Table3 M5→M6"""
import docx
from docx.shared import Pt
from docx.oxml.ns import qn
from docx.oxml import parse_xml

DOC_PATH='<PROJECT_ROOT>/文章撰写/投稿版论文_V2.docx'
doc=docx.Document(DOC_PATH)

# ===== 1. 修复"eight pure imaging models" → "seven" =====
for p in doc.paragraphs:
    for run in p.runs:
        if 'eight pure imaging models' in run.text:
            run.text=run.text.replace('eight pure imaging models','seven pure imaging models')
            print('eight -> seven')

# ===== 2. 修复Table 3: Row12 M5 → M6 =====
t3=doc.tables[2]
cell=t3.rows[12].cells[0]
for p in cell.paragraphs:
    for run in p.runs:
        if run.text.strip()=='M5':
            run.text='M6'
            print('Table3 Row12: M5 -> M6')

# ===== 3. 重建Table 4 (7变量标准Cox) =====
m4c7_data=[
    ('NAC','2.705','1.484-4.930','0.001'),
    ('N','1.474','1.003-2.165','0.048'),
    ('Grade','1.527','0.945-2.468','0.084'),
    ('ALN','1.699','0.712-4.056','0.232'),
    ('proRT','1.720','0.978-3.024','0.060'),
    ('Sphericity*','0.067','0.009-0.518','0.0096'),
    ('Maximum3DDiameter','0.997','0.981-1.014','0.748'),
]

t4=doc.tables[3]
tbl=t4._tbl
# 删除数据行(保留表头)
for ri in range(len(t4.rows)-1,0,-1):
    tbl.remove(t4.rows[ri]._tr)

def set_cell_text(cell, text):
    for p in cell.paragraphs:
        for r in list(p.runs):
            r._element.getparent().remove(r._element)
    p=cell.paragraphs[0]
    run=p.add_run(text)
    run.font.name='Times New Roman';run.font.size=Pt(9)

for data in m4c7_data:
    row=t4.add_row()
    for ci,val in enumerate(data):
        set_cell_text(row.cells[ci], val)

# 应用三线表格式
for row in t4.rows:
    for cell in row.cells:
        tc=cell._tc;tcPr=tc.get_or_add_tcPr()
        for b in tcPr.findall(qn('w:tcBorders')): tcPr.remove(b)
for c in t4.rows[0].cells:
    tc=c._tc;tcPr=tc.get_or_add_tcPr()
    tcPr.append(parse_xml('<w:tcBorders xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:top w:val="single" w:sz="12" w:space="0" w:color="000000"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="000000"/></w:tcBorders>'))
for i in range(1,len(t4.rows)):
    for c in t4.rows[i].cells:
        tc=c._tc;tcPr=tc.get_or_add_tcPr()
        tcPr.append(parse_xml('<w:tcBorders xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:bottom w:val="single" w:sz="2" w:space="0" w:color="000000"/></w:tcBorders>'))
for c in t4.rows[-1].cells:
    tc=c._tc;tcPr=tc.get_or_add_tcPr()
    tcPr.append(parse_xml('<w:tcBorders xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:bottom w:val="single" w:sz="12" w:space="0" w:color="000000"/></w:tcBorders>'))

doc.save(DOC_PATH)
print('Table 4 重建完成')
print(f'Table4 行数: {len(doc.tables[3].rows)}')
