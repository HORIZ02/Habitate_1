#!/usr/bin/env python3
"""将论文中的表格改为三线表格式 + 添加表注"""
import os
from docx import Document
from docx.shared import Pt, Cm, Inches, RGBColor, Emu
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml

SRC="<PROJECT_ROOT>/文章撰写/论文投稿版_v2.docx"
OUT_DIR="<PROJECT_ROOT>/文章撰写"

TABLE_FOOTNOTES={
    'Table1_Baseline':{
        'title':'Table 1. Baseline Patient Characteristics',
        'footnote':'Abbreviations: NAC, neoadjuvant chemotherapy; ALN, axillary lymph node; proRT, postoperative radiotherapy; ER, estrogen receptor; PR, progesterone receptor; DFS, disease-free survival. Data are presented as n (%) or mean ± SD.'
    },
    'Table2_Pure_Imaging':{
        'title':'Table 2. Performance of Pure Imaging Models',
        'footnote':'Abbreviations: WT, whole tumor; L, low-signal habitat; M, medium-signal habitat; H, high-signal habitat; CV, cross-validation; AUC, area under the curve. P-values from log-rank test.'
    },
    'Table3_Combined_Models':{
        'title':'Table 3. Performance of Combined Imaging+Clinical Models',
        'footnote':'Abbreviations: M0, clinical baseline (11 variables); M1, DWI WT+clinical; M2a–c, DWI L/M/H+clinical; M3, DWI all+clinical; M4a–c, DCE L/M/H+clinical; M5, DCE all+clinical; M6, DWI all+DCE all+clinical; M7, all DWI+DCE habitats+clinical. P-values from log-rank test.'
    },
    'Table4_Multivariable_Cox':{
        'title':'Table 4. Multivariable Cox Regression Analysis of M4c Selected Features',
        'footnote':'Abbreviations: HR, hazard ratio; CI, confidence interval; NAC, neoadjuvant chemotherapy; ALN, axillary lymph node; proRT, postoperative radiotherapy. *P<0.05, **P<0.01, ***P<0.001.'
    }
}

def set_cell_border(cell, **kwargs):
    """Set cell border. Usage: set_cell_border(cell, top={"sz":12,"val":"single","color":"000000"})"""
    tc=cell._tc
    tcPr=tc.get_or_add_tcPr()
    tcBorders=parse_xml(f'<w:tcBorders {nsdecls("w")}></w:tcBorders>')
    for edge, attrs in kwargs.items():
        el=parse_xml(
            f'<w:{edge} {nsdecls("w")} w:val="{attrs.get("val","single")}" '
            f'w:sz="{attrs.get("sz",4)}" w:space="0" '
            f'w:color="{attrs.get("color","000000")}"/>'
        )
        tcBorders.append(el)
    tcPr.append(tcBorders)

def apply_three_line(table):
    """Apply three-line table format to a docx table"""
    nrows=len(table.rows)
    ncols=len(table.columns)
    
    for ri,row in enumerate(table.rows):
        for ci,cell in enumerate(row.cells):
            if ri==0:
                # Top border of header (thick)
                set_cell_border(cell, 
                    top={"sz":12,"val":"single","color":"000000"},
                    bottom={"sz":6,"val":"single","color":"000000"},
                    left={"sz":0,"val":"nil","color":"FFFFFF"},
                    right={"sz":0,"val":"nil","color":"FFFFFF"})
            elif ri==nrows-1:
                # Bottom border of last row (thick)
                set_cell_border(cell,
                    top={"sz":0,"val":"nil","color":"FFFFFF"},
                    bottom={"sz":12,"val":"single","color":"000000"},
                    left={"sz":0,"val":"nil","color":"FFFFFF"},
                    right={"sz":0,"val":"nil","color":"FFFFFF"})
            else:
                # No borders
                set_cell_border(cell,
                    top={"sz":0,"val":"nil","color":"FFFFFF"},
                    bottom={"sz":0,"val":"nil","color":"FFFFFF"},
                    left={"sz":0,"val":"nil","color":"FFFFFF"},
                    right={"sz":0,"val":"nil","color":"FFFFFF"})

def add_table_note(doc, text):
    """Add a table footnote below the table"""
    p=doc.add_paragraph()
    p.paragraph_format.space_before=Pt(4)
    run=p.add_run(text)
    run.font.size=Pt(8)
    run.font.italic=True
    run.font.name='Times New Roman'

# ===== 1. 处理主文档中的表格 =====
doc=Document(SRC)

# Table 1 (index 0): Baseline → make three-line
for tbl_idx in range(len(doc.tables)):
    apply_three_line(doc.tables[tbl_idx])

# Add table notes after each table
# Find where tables are and add notes
table_count=0
for i,p in enumerate(doc.paragraphs):
    if p.text.startswith('Table ') and not p.text.startswith('Table 1'):
        # This is a table title paragraph - the table is just before or after
        # Actually, tables were inserted during build_paper, let me find them
        pass

# Add footnotes - reposition after each table
# Tables are at the end before Figure Legends
# Let me add footnotes by finding the Tables section
new_paras=[]
inserted_notes=set()
table_titles=['Table 1.','Table 2.','Table 3.','Table 4.']
current_tbl_idx=-1

# Save and re-read approach: add notes to standalone files instead
doc.save(SRC)
print('✅ 主文档表格已改为三线表')

# ===== 2. 处理独立表格文件（含表注） =====
for fname, info in TABLE_FOOTNOTES.items():
    fp=os.path.join(OUT_DIR, f'{fname}.docx')
    if not os.path.exists(fp):
        print(f'  ⚠️ {fname}.docx 不存在')
        continue
    
    tbl_doc=Document(fp)
    
    if len(tbl_doc.tables)>0:
        apply_three_line(tbl_doc.tables[0])
    
    # Add footnote
    add_table_note(tbl_doc, info['footnote'])
    
    tbl_doc.save(fp)
    print(f'  ✅ {fname}.docx (三线表+表注)')

print('\n✅ 所有表格已优化为三线表格式')
