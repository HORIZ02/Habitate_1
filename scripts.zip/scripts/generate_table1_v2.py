#!/usr/bin/env python3
"""重新生成Table 1：含风险分组统计+P值"""
import pandas as pd, numpy as np, os, warnings
warnings.filterwarnings('ignore')
from scipy.stats import chi2_contingency, ttest_ind
from sklearn.preprocessing import StandardScaler
from sksurv.linear_model import CoxnetSurvivalAnalysis
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml, OxmlElement

OUT="<PROJECT_ROOT>/文章撰写"
FIG_DIR="<PROJECT_ROOT>/results/figures"

# ===== 1. 计算风险分组 =====
clin=pd.read_csv('<DATA_ROOT>/分析结果/merged_data_corrected.csv')
dwi=pd.read_csv('<PROJECT_ROOT>/data/features/dwi_pyradiomics_k3.csv')
dce=pd.read_csv('<PROJECT_ROOT>/data/features/dce_pyradiomics_k3.csv')
feats=[c for c in dwi.columns if c not in ['Case_No.','Habitat']]
def gh(df,h):return df[df['Habitat']==h][['Case_No.']+feats].drop_duplicates('Case_No.').set_index('Case_No.')
dce_h=gh(dce,'habitat_H')
X=pd.concat([clin[['NAC','N','Age','Grade','T','ALN','proRT','ER','PR','Her2','Meno']],dce_h.loc[clin['Case_No.']].reset_index(drop=True)],axis=1)
s=StandardScaler();Xs=s.fit_transform(X)
y=np.array([(bool(e),t) for e,t in zip(clin['DFS'],clin['Time'])],dtype=[('event','bool'),('time','float')])
cph=CoxnetSurvivalAnalysis(l1_ratio=1,alphas=[0.1],max_iter=10000).fit(Xs,y)
risk=cph.predict(Xs).flatten()
med=np.median(risk)

clin['Group']=['Low Risk' if r<=med else 'High Risk' for r in risk]
n_low=(risk<=med).sum()
n_high=(risk>med).sum()
total=len(clin)

# ===== 2. 构建表格 =====
cat_vars=['NAC','Meno','Grade','T','N','ALN','proRT','ER','PR','DFS_event']
cat_labels={
    'NAC':['No','Yes'],'Meno':['Pre-menopausal','Post-menopausal'],
    'Grade':['Grade 1','Grade 2','Grade 3'],
    'T':['T1','T2','T3–T4'],'N':['N0','N1','N2–N3'],
    'ALN':['Negative','Positive'],'proRT':['No','Yes'],
    'ER':['Negative','Positive'],'PR':['Negative','Positive'],
    'DFS_event':['No','Yes'],
}
cont_vars=['Age']

def count_group(var,cats,df,group_col='Group'):
    """Count and percentage for each category"""
    results=[]
    for c in cats:
        if var=='T':
            if '–' in c:m=int(c[1])
            else:m=int(c[-1])
            n_tot=len(df[df['T']==m])
            n_l=len(df[(df['T']==m)&(df[group_col]=='Low Risk')])
            n_h=len(df[(df['T']==m)&(df[group_col]=='High Risk')])
        elif var=='N':
            if '–' in c:m=int(c[1])
            else:m=int(c[-1])
            n_tot=len(df[df['N']==m])
            n_l=len(df[(df['N']==m)&(df[group_col]=='Low Risk')])
            n_h=len(df[(df['N']==m)&(df[group_col]=='High Risk')])
        elif var=='DFS_event':
            v=1 if c=='Yes' else 0
            n_tot=len(df[df['DFS']==v])
            n_l=len(df[(df['DFS']==v)&(df[group_col]=='Low Risk')])
            n_h=len(df[(df['DFS']==v)&(df[group_col]=='High Risk')])
        elif var=='Grade':
            g=int(c[-1])
            n_tot=len(df[df['Grade']==g])
            n_l=len(df[(df['Grade']==g)&(df[group_col]=='Low Risk')])
            n_h=len(df[(df['Grade']==g)&(df[group_col]=='High Risk')])
        else:
            v={'No':0,'Yes':1,'Negative':0,'Positive':1,'Pre-menopausal':0,'Post-menopausal':1}[c]
            n_tot=len(df[df[var]==v])
            n_l=len(df[(df[var]==v)&(df[group_col]=='Low Risk')])
            n_h=len(df[(df[var]==v)&(df[group_col]=='High Risk')])
        results.append((f'{n_tot} ({n_tot/total*100:.1f})',f'{n_l} ({n_l/n_low*100:.1f})',f'{n_h} ({n_h/n_high*100:.1f})'))
    return results

def calc_p(var,df):
    if var=='Age':
        low=df[df['Group']=='Low Risk']['Age']
        high=df[df['Group']=='High Risk']['Age']
        _,p=ttest_ind(low,high)
    else:
        ct=pd.crosstab(df[var],df['Group'])
        _,p,_,_=chi2_contingency(ct)
    return f'{p:.4f}' if p>=0.001 else '<0.001'

# ===== 3. 生成Word文档 =====
doc=Document()
style=doc.styles['Normal'];style.font.name='Times New Roman';style.font.size=Pt(9)

p=doc.add_paragraph()
p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('Table 1. Baseline Patient Characteristics')
r.bold=True;r.font.size=Pt(11)

headers=['Characteristic','Category','Total (N='+str(total)+')','Low Risk (n='+str(n_low)+')','High Risk (n='+str(n_high)+')','P value']
table=doc.add_table(rows=1,cols=6)
table.alignment=WD_TABLE_ALIGNMENT.CENTER
for ci,h in enumerate(headers):
    table.rows[0].cells[ci].text=h

# Categorical variables
var_order=['NAC','Meno','Grade','T','N','ALN','proRT','ER','PR']
for var in var_order:
    cats=cat_labels[var]
    p_val=calc_p(var,clin)
    # Variable name row
    row=table.add_row().cells
    row[0].text=var.replace('_',' ')
    for ci in range(1,6):row[ci].text=''
    
    counts=count_group(var,cats,clin)
    for ci,c in enumerate(cats):
        tot_s,low_s,high_s=counts[ci]
        row=table.add_row().cells
        row[0].text=''
        row[1].text=f'  {c}'
        row[2].text=tot_s
        row[3].text=low_s
        row[4].text=high_s
        row[5].text=p_val if ci==0 else ''

# Continuous: Age
row=table.add_row().cells
row[0].text='Age'
for ci in range(1,6):row[ci].text=''
row=table.add_row().cells
row[0].text='';row[1].text='  Mean ± SD'
low_age=clin[clin['Group']=='Low Risk']['Age']
high_age=clin[clin['Group']=='High Risk']['Age']
age_mean=clin['Age'].mean();age_std=clin['Age'].std()
low_mean=low_age.mean();low_std=low_age.std()
high_mean=high_age.mean();high_std=high_age.std()
row[2].text=f'{age_mean:.1f} ± {age_std:.1f}'
row[3].text=f'{low_mean:.1f} ± {low_std:.1f}'
row[4].text=f'{high_mean:.1f} ± {high_std:.1f}'
row[5].text=calc_p('Age',clin)

# DFS events
row=table.add_row().cells
row[0].text='DFS event'
for ci in range(1,6):row[ci].text=''
for v,label in [(0,'No'),(1,'Yes')]:
    n_tot=len(clin[clin['DFS']==v])
    n_l=len(clin[(clin['DFS']==v)&(clin['Group']=='Low Risk')])
    n_h=len(clin[(clin['DFS']==v)&(clin['Group']=='High Risk')])
    row=table.add_row().cells
    row[0].text='';row[1].text=f'  {label}'
    row[2].text=f'{n_tot} ({n_tot/total*100:.1f})'
    row[3].text=f'{n_l} ({n_l/n_low*100:.1f})'
    row[4].text=f'{n_h} ({n_h/n_high*100:.1f})'
    row[5].text=calc_p('DFS',clin) if v==1 else ''

# Footnote
p=doc.add_paragraph()
p.paragraph_format.space_before=Pt(4)
r=p.add_run(
'Note: Data are presented as n (%) for categorical variables and mean ± SD for continuous variables. '
'P-values were calculated using the χ² test (or Fisher\'s exact test when expected cell counts <5) for categorical variables, '
'and the independent two-sample t-test for Age. '
'Risk groups were defined by the median M4c model risk score. '
'Abbreviations: NAC, neoadjuvant chemotherapy (0=no, 1=yes); ALN, axillary lymph node metastasis (0=negative, 1=positive); '
'proRT, postoperative radiotherapy; ER, estrogen receptor; PR, progesterone receptor; DFS, disease-free survival; '
'SD, standard deviation. '
'Statistically significant P-values (P<0.05) are indicated in bold.'
)
r.font.size=Pt(8);r.font.italic=True;r.font.name='Times New Roman'

# ===== 4. 三线表格式 =====
def set_cell_border(cell,**kwargs):
    tc=cell._tc;tcPr=tc.get_or_add_tcPr()
    tcBorders=parse_xml('<w:tcBorders %s></w:tcBorders>' % nsdecls('w'))
    for edge,attrs in kwargs.items():
        val=attrs.get('val','single')
        sz=attrs.get('sz',4)
        color=attrs.get('color','000000')
        el=parse_xml('<w:%s %s w:val="%s" w:sz="%s" w:space="0" w:color="%s"/>' % (edge,nsdecls('w'),val,sz,color))
        tcBorders.append(el)
    tcPr.append(tcBorders)

nrows=len(table.rows);ncols=len(table.columns)
for ri,row in enumerate(table.rows):
    for ci,cell in enumerate(row.cells):
        if ri==0:
            set_cell_border(cell,top={"sz":12,"val":"single","color":"000000"},bottom={"sz":6,"val":"single","color":"000000"},
                           left={"sz":0,"val":"nil","color":"FFFFFF"},right={"sz":0,"val":"nil","color":"FFFFFF"})
        elif ri==nrows-1:
            set_cell_border(cell,top={"sz":0,"val":"nil","color":"FFFFFF"},bottom={"sz":12,"val":"single","color":"000000"},
                           left={"sz":0,"val":"nil","color":"FFFFFF"},right={"sz":0,"val":"nil","color":"FFFFFF"})
        else:
            set_cell_border(cell,top={"sz":0,"val":"nil","color":"FFFFFF"},bottom={"sz":0,"val":"nil","color":"FFFFFF"},
                           left={"sz":0,"val":"nil","color":"FFFFFF"},right={"sz":0,"val":"nil","color":"FFFFFF"})

# Save
fp=os.path.join(OUT,'Table1_Baseline.docx')
doc.save(fp)
print(f'✅ Table 1 (含分组统计+P值): {fp}')
print(f'   行数: {nrows}, 列数: {ncols}')
