"""Create Table S1 as three-line table (三线表)"""
from docx import Document
from docx.shared import Pt, Cm, Emu
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml

doc = Document()
style = doc.styles['Normal']
style.font.name = 'Times New Roman'
style.font.size = Pt(10.5)

# Title
p = doc.add_paragraph()
run = p.add_run('Supplementary Table S1. Complete list of 107 radiomics features extracted from each habitat mask.')
run.bold = True
run.font.size = Pt(10.5)
run.font.name = 'Times New Roman'

p2 = doc.add_paragraph()
run2 = p2.add_run('Features were extracted using PyRadiomics 3.1.0 from habitat_L, habitat_M, habitat_H, and whole tumor masks for both DWI and DCE-MRI sequences. Image preprocessing: normalization with scale of 100 and bin width of 25.')
run2.font.size = Pt(9)
run2.font.name = 'Times New Roman'
run2.italic = True

# Categories with exact PyRadiomics 3.1.0 feature names
categories = [
    ('Shape (14)', ['MeshVolume', 'VoxelVolume', 'SurfaceArea', 'SurfaceAreaToVolumeRatio',
        'Sphericity', 'Compactness1', 'Compactness2', 'SphericalDisproportion',
        'Maximum3DDiameter', 'Maximum2DDiameterSlice', 'Maximum2DDiameterColumn',
        'Maximum2DDiameterRow', 'MajorAxisLength', 'MinorAxisLength']),
    ('First-order Statistics (18)', ['Energy', 'TotalEnergy', 'Entropy', 'Minimum', 'Maximum', 'Mean',
        'Median', 'Range', 'Std', 'Variance', 'Skewness', 'Kurtosis',
        'Uniformity', 'RootMeanSquared', 'RobustMeanAbsoluteDeviation',
        'MeanAbsoluteDeviation', 'InterquartileRange', '10thPercentile']),
    ('GLCM (24)', ['Autocorrelation', 'ClusterProminence', 'ClusterShade', 'ClusterTendency',
        'Contrast', 'Correlation', 'DifferenceAverage', 'DifferenceEntropy',
        'DifferenceVariance', 'Id', 'Idm', 'Idn', 'Idmn',
        'InverseVariance', 'InformalMeasureOfCorrelation1',
        'InformalMeasureOfCorrelation2', 'JointAverage', 'JointEnergy',
        'JointEntropy', 'MCC', 'MaximumProbability', 'SumAverage',
        'SumEntropy', 'SumSquares']),
    ('GLRLM (16)', ['GrayLevelNonUniformity', 'GrayLevelNonUniformityNormalized',
        'GrayLevelVariance', 'HighGrayLevelRunEmphasis',
        'LongRunEmphasis', 'LongRunHighGrayLevelEmphasis',
        'LongRunLowGrayLevelEmphasis', 'LowGrayLevelRunEmphasis',
        'RunEntropy', 'RunLengthNonUniformity',
        'RunLengthNonUniformityNormalized', 'RunPercentage',
        'RunVariance', 'ShortRunEmphasis',
        'ShortRunHighGrayLevelEmphasis', 'ShortRunLowGrayLevelEmphasis']),
    ('GLSZM (16)', ['GrayLevelNonUniformity', 'GrayLevelNonUniformityNormalized',
        'GrayLevelVariance', 'HighGrayLevelZoneEmphasis',
        'LargeAreaEmphasis', 'LargeAreaHighGrayLevelEmphasis',
        'LargeAreaLowGrayLevelEmphasis', 'LowGrayLevelZoneEmphasis',
        'SizeZoneNonUniformity', 'SizeZoneNonUniformityNormalized',
        'SmallAreaEmphasis', 'SmallAreaHighGrayLevelEmphasis',
        'SmallAreaLowGrayLevelEmphasis', 'ZoneEntropy',
        'ZonePercentage', 'ZoneVariance']),
    ('GLDM (14)', ['DependenceEntropy', 'DependenceNonUniformity',
        'DependenceNonUniformityNormalized', 'DependenceVariance',
        'GrayLevelNonUniformity', 'GrayLevelVariance',
        'HighGrayLevelEmphasis', 'LargeDependenceEmphasis',
        'LargeDependenceHighGrayLevelEmphasis',
        'LargeDependenceLowGrayLevelEmphasis',
        'LowGrayLevelEmphasis', 'SmallDependenceEmphasis',
        'SmallDependenceHighGrayLevelEmphasis',
        'SmallDependenceLowGrayLevelEmphasis']),
    ('NGTDM (5)', ['Busyness', 'Coarseness', 'Complexity', 'Contrast', 'Strength']),
]

# Build table: 2 columns (Category, Features)
n_rows = sum(len(f) for _, f in categories) + 1 + len(categories)  # header + category rows + feature rows
# Actually simplify: one row per category with features in second column
n_rows = 1 + len(categories) + 1  # header + categories + total

table = doc.add_table(rows=n_rows, cols=3)
table.alignment = WD_TABLE_ALIGNMENT.CENTER

# Remove all borders first, then add three-line format
def set_cell_border(cell, **kwargs):
    """Set cell border"""
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = parse_xml(f'<w:tcBorders {nsdecls("w")}>'
                          f'<w:top w:val="{kwargs.get("top", "none")}" w:sz="{kwargs.get("top_sz", "0")}" w:space="0" w:color="{kwargs.get("color", "000000")}"/>'
                          f'<w:left w:val="{kwargs.get("left", "none")}" w:sz="0" w:space="0" w:color="{kwargs.get("color", "000000")}"/>'
                          f'<w:bottom w:val="{kwargs.get("bottom", "none")}" w:sz="{kwargs.get("bottom_sz", "0")}" w:space="0" w:color="{kwargs.get("color", "000000")}"/>'
                          f'<w:right w:val="{kwargs.get("right", "none")}" w:sz="0" w:space="0" w:color="{kwargs.get("color", "000000")}"/>'
                          f'</w:tcBorders>')
    tcPr.append(tcBorders)

def apply_three_line(table):
    """Apply three-line table format"""
    # Remove all cell borders first
    for row in table.rows:
        for cell in row.cells:
            tc = cell._tc
            tcPr = tc.get_or_add_tcPr()
            # Remove existing borders
            for borders in tcPr.findall(qn('w:tcBorders')):
                tcPr.remove(borders)
    
    # Thick top line on first row
    for cell in table.rows[0].cells:
        set_cell_border(cell, top='single', top_sz='12', bottom='single', bottom_sz='4')
    
    # Thin bottom line on header row (already done above)
    
    # Single bottom line on every row (will be overridden by thick bottom on last)
    for i in range(1, len(table.rows)):
        for cell in table.rows[i].cells:
            set_cell_border(cell, bottom='single', bottom_sz='2')
    
    # Thick bottom line on last row
    for cell in table.rows[-1].cells:
        set_cell_border(cell, bottom='single', bottom_sz='12')

# Set text in cells
def set_cell_text(cell, text, bold=False, size=Pt(9)):
    cell.text = ''
    p = cell.paragraphs[0]
    run = p.add_run(text)
    run.font.name = 'Times New Roman'
    run.font.size = size
    run.bold = bold

# Header
set_cell_text(table.rows[0].cells[0], 'Category', bold=True, size=Pt(10))
set_cell_text(table.rows[0].cells[1], 'Feature names', bold=True, size=Pt(10))
set_cell_text(table.rows[0].cells[2], 'Count', bold=True, size=Pt(10))

# Fill category rows
for i, (cat_name, features) in enumerate(categories):
    row = table.rows[1 + i]
    set_cell_text(row.cells[0], cat_name, bold=True, size=Pt(9.5))
    set_cell_text(row.cells[1], ', '.join(features), size=Pt(8))
    set_cell_text(row.cells[2], str(len(features)), size=Pt(9.5))

# Total row
total_row = table.rows[-1]
set_cell_text(total_row.cells[0], 'Total', bold=True, size=Pt(10))
set_cell_text(total_row.cells[1], '107 three-dimensional radiomics features', size=Pt(9.5))
set_cell_text(total_row.cells[2], '107', bold=True, size=Pt(10))

# Set column widths
for row in table.rows:
    row.cells[0].width = Cm(4)
    row.cells[1].width = Cm(12)
    row.cells[2].width = Cm(1.5)

apply_three_line(table)

# Footnote
p3 = doc.add_paragraph()
run3 = p3.add_run('Abbreviations: GLCM, Gray Level Co-occurrence Matrix; GLRLM, Gray Level Run Length Matrix; GLSZM, Gray Level Size Zone Matrix; GLDM, Gray Level Dependence Matrix; NGTDM, Neighboring Gray Tone Difference Matrix.')
run3.font.size = Pt(8)
run3.font.name = 'Times New Roman'
run3.italic = True

doc.save('<PROJECT_ROOT>/文章撰写/Supp_TableS1_Features.docx')
print('✅ Three-line table saved')
