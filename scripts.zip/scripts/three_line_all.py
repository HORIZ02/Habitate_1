#!/usr/bin/env python3
"""统一所有表格为三线表格式"""
from docx import Document
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml
import os

TBL_DIR="<PROJECT_ROOT>/文章撰写"
SRC=os.path.join(TBL_DIR,"论文投稿版_v2.docx")

def set_cell_border(cell,top=None,bottom=None,left=None,right=None):
    tc=cell._tc
    tcPr=tc.get_or_add_tcPr()
    # Remove existing borders
    for old in tcPr.findall(qn('w:tcBorders')):
        tcPr.remove(old)
    tcBorders=parse_xml('<w:tcBorders %s></w:tcBorders>' % nsdecls('w'))
    for edge,attrs in [('top',top),('bottom',bottom),('start',left),('end',right)]:
        if attrs:
            el=parse_xml('<w:%s %s w:val="%s" w:sz="%s" w:space="0" w:color="%s"/>' % 
                        (edge,nsdecls('w'),attrs['val'],attrs['sz'],attrs['color']))
            tcBorders.append(el)
    tcPr.append(tcBorders)

def apply_three_line(table):
    # Remove table style to prevent conflicting borders
    tbl_pr=table._tbl.find(qn('w:tblPr'))
    if tbl_pr is not None:
        for style_elem in tbl_pr.findall(qn('w:tblStyle')):
            tbl_pr.remove(style_elem)
    
    nrows=len(table.rows)
    ncols=len(table.columns)
    for ri,row in enumerate(table.rows):
        for ci,cell in enumerate(row.cells):
            tc=cell._tc
            tcPr=tc.get_or_add_tcPr()
            # Remove existing borders
            for old in tcPr.findall(qn('w:tcBorders')):
                tcPr.remove(old)
            
            # Create NEW borders - only three lines
            tcBorders=parse_xml('<w:tcBorders %s></w:tcBorders>' % nsdecls('w'))
            
            # Top line (only for header row)
            if ri==0:
                el=parse_xml('<w:top %s w:val="single" w:sz="12" w:space="0" w:color="000000"/>' % nsdecls('w'))
                tcBorders.append(el)
            else:
                el=parse_xml('<w:top %s w:val="none" w:sz="0" w:space="0" w:color="auto"/>' % nsdecls('w'))
                tcBorders.append(el)
            
            # Bottom line (for header row thin, for last row thick)
            if ri==0:
                el=parse_xml('<w:bottom %s w:val="single" w:sz="6" w:space="0" w:color="000000"/>' % nsdecls('w'))
            elif ri==nrows-1:
                el=parse_xml('<w:bottom %s w:val="single" w:sz="12" w:space="0" w:color="000000"/>' % nsdecls('w'))
            else:
                el=parse_xml('<w:bottom %s w:val="none" w:sz="0" w:space="0" w:color="auto"/>' % nsdecls('w'))
            tcBorders.append(el)
            
            # No left/right borders
            for side in ['start','end']:
                el=parse_xml('<w:%s %s w:val="none" w:sz="0" w:space="0" w:color="auto"/>' % (side,nsdecls('w')))
                tcBorders.append(el)
            
            # No insideH/insideV
            for side in ['insideH','insideV']:
                el=parse_xml('<w:%s %s w:val="none" w:sz="0" w:space="0" w:color="auto"/>' % (side,nsdecls('w')))
                tcBorders.append(el)
            
            tcPr.append(tcBorders)

# 1. Standalone tables
for fname in ['Table1_Baseline.docx','Table2_Pure_Imaging.docx','Table3_Combined_Models.docx','Table4_Multivariable_Cox.docx']:
    fp=os.path.join(TBL_DIR,fname)
    doc=Document(fp)
    for tbl in doc.tables:
        apply_three_line(tbl)
    doc.save(fp)
    print(f'  ✅ {fname}')

# 2. Main document
doc=Document(SRC)
for tbl in doc.tables:
    apply_three_line(tbl)
doc.save(SRC)
print(f'  ✅ 论文投稿版_v2.docx')
print('所有表格已统一为三线表')
