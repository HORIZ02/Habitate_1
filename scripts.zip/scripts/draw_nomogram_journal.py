#!/usr/bin/env python3
"""顶刊风格Nomogram - 基于M4c Cox模型，正确点值计算"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from viz_common import *

plt.rcParams.update({'font.family':'Times New Roman','font.size':12,
                     'axes.facecolor':'white','figure.facecolor':'white',
                     'text.color':'black','axes.edgecolor':'black'})
OUT="<PROJECT_ROOT>/results/figures";DPI=600

def draw_journal_nomogram():
    df = build_m4c_df()
    cph = fit_m4c_cox(df)
    coefs = cph.params_
    
    # 特征定义
    features = [
        ('NAC', 'NAC', 'clinical'),
        ('N', 'N stage', 'clinical'),
        ('Age', 'Age', 'clinical'),
        ('Grade', 'Grade', 'clinical'),
        ('T', 'T stage', 'clinical'),
        ('ALN', 'ALN', 'clinical'),
        ('proRT', 'Postop RT', 'clinical'),
        ('ER', 'ER status', 'clinical'),
        ('PR', 'PR status', 'clinical'),
        ('Her2', 'HER2 status', 'clinical'),
        ('Meno', 'Menopause', 'clinical'),
        ('original_shape_Sphericity', 'Sphericity', 'radiomics'),
        ('original_shape_Maximum3DDiameter', 'Max 3D Diameter', 'radiomics'),
    ]
    
    n_vars = len(features)
    
    # 计算每变量的范围和effect
    ranges = {}
    for feat, label, cat in features:
        vals = df[feat].values
        lo, hi = np.percentile(vals, [1, 99])
        ranges[feat] = (lo, hi, hi - lo)
    
    # max_effect 归一化: 每个变量 ≤ 100 pts
    coef_vals = np.array([coefs[f] for f, _, _ in features])
    max_effect = max(abs(coefs[f]) * ranges[f][2] for f, _, _ in features)
    # 每个变量在(lo,hi)的点数
    var_points = {}
    for feat, label, cat in features:
        lo, hi, rng = ranges[feat]
        var_points[feat] = abs(coefs[feat]) * rng / max_effect * 100
    
    tp_max = sum(var_points.values())
    print(f'Total Points max: {tp_max:.1f}')
    
    # 实际患者范围
    tp_patient = []
    for _, row in df.iterrows():
        tp = 0
        for feat, label, cat in features:
            lo, hi, rng = ranges[feat]
            v = row[feat]
            # 点值: β>0时值越大点越多; β<0时值越小点越多
            frac = (v - lo) / rng
            if coefs[feat] < 0:
                frac = 1 - frac
            tp += frac * var_points[feat]
        tp_patient.append(tp)
    tp_patient = np.array(tp_patient)
    print(f'Patient TP range: {tp_patient.min():.0f} - {tp_patient.max():.0f}')
    
    # 生存概率计算: survival = S0(t)^exp(LP)
    # LP = (TP / tp_max) * max(|coef|) * sign(sum(coefs))
    lp_max = max(abs(c) for c in coef_vals)
    sign_sum = 1 if coef_vals.sum() > 0 else -1
    
    # 从Cox模型获取基线生存
    base_surv = cph.baseline_survival_
    def S0(t):
        idx = np.abs(np.array(base_surv.index) - t).argmin()
        return base_surv.iloc[idx]['baseline survival']
    S0_3, S0_5 = S0(36), S0(60)
    print(f'S0(36)={S0_3:.3f}, S0(60)={S0_5:.3f}')
    
    def survival_at_tp(tp, t):
        LP = (tp / tp_max) * lp_max * sign_sum
        return S0(t) ** np.exp(LP)
    
    # ===== 绘图 =====
    n_vars = len(features)
    # 行间距加大避免重叠
    ROW_H = 1.7
    fig, ax = plt.subplots(figsize=(22, 6 + n_vars*ROW_H + 8))
    ax.set_xlim(0, 100)
    ax.set_ylim(-12, n_vars*ROW_H + 6)
    ax.axis('off')
    
    # 标题
    ax.text(50, n_vars*ROW_H + 4.2, 'Nomogram for 3- and 5-Year Disease-Free Survival',
            ha='center', fontsize=24, fontweight='bold', color='black')
    
    # Points轴
    ax.text(96, n_vars*ROW_H + 2.8, 'Points', ha='center', fontsize=17, fontweight='bold', color='black')
    for p in range(0, 101, 20):
        ax.text(p, n_vars*ROW_H + 2.8, str(p), ha='center', fontsize=13, color='black')
    ax.plot([0, 100], [n_vars*ROW_H + 2.3, n_vars*ROW_H + 2.3], color='black', lw=2.2)
    for p in range(0, 101, 10):
        ax.plot([p, p], [n_vars*ROW_H + 2.3, n_vars*ROW_H + 2.6], color='black', lw=1.2)
    
    # 变量行
    for i, (feat, label, cat) in enumerate(features):
        y_pos = n_vars*ROW_H - i*ROW_H - ROW_H*0.7
        lo, hi, rng = ranges[feat]
        
        # 特征名(左对齐，大字体)
        ax.text(1, y_pos, label, ha='left', va='center', fontsize=15, color='black',
                fontweight='bold' if 'DCE' in cat.upper() or cat=='radiomics' else 'normal')
        
        # 右侧数值标签：hi在上方、lo在下方，与横线错开
        if cat == 'clinical' and lo == int(lo):
            lo_s, hi_s = str(int(lo)), str(int(hi))
        else:
            lo_s, hi_s = f'{lo:.2f}', f'{hi:.2f}'
        ax.text(95, y_pos + 0.55, hi_s, ha='right', fontsize=13, color='black')
        ax.text(95, y_pos - 0.55, lo_s, ha='right', fontsize=13, color='black')
        
        # 横线（加粗，从18到82，避开两侧文字）
        ax.plot([18, 82], [y_pos, y_pos], color='black', lw=1.8)
        
        # 刻度（在横线上，大刻度）
        for pt_val in [0, 25, 50, 75, 100]:
            x_t = 18 + pt_val/100 * 64
            ax.plot([x_t, x_t], [y_pos - 0.15, y_pos + 0.15], color='black', lw=1.2)
    
    # Total Points轴
    y_tp = -1.8
    ax.text(50, y_tp + 0.6, 'Total Points', ha='center', fontsize=17, fontweight='bold', color='black')
    ax.plot([18, 82], [y_tp, y_tp], color='black', lw=2.2)
    tp_ticks = np.linspace(0, tp_max, 6)
    for t in tp_ticks:
        x_t = 18 + t/tp_max * 64
        ax.text(x_t, y_tp - 0.5, f'{t:.0f}', ha='center', fontsize=13, color='black')
        ax.plot([x_t, x_t], [y_tp - 0.15, y_tp + 0.15], color='black', lw=1.2)
    
    # 生存概率轴
    for t_idx, (t_label, t_val, S0_t) in enumerate([('3-Year DFS', 36, S0_3), ('5-Year DFS', 60, S0_5)]):
        y_surv = -4.5 - t_idx * 2.5
        ax.text(50, y_surv + 1.0, t_label, ha='center', fontsize=18, fontweight='bold', color='black')
        
        probs = [0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1]
        prob_positions = []
        for p in probs:
            lo_tp, hi_tp = 0, tp_max
            for _ in range(40):
                mid = (lo_tp + hi_tp)/2
                s_mid = survival_at_tp(mid, t_val)
                if s_mid > p: lo_tp = mid
                else: hi_tp = mid
            tp_for_p = (lo_tp + hi_tp)/2
            x_p = 18 + tp_for_p/tp_max * 64
            prob_positions.append(x_p)
            ax.text(x_p, y_surv + 0.4, f'{p}', ha='center', fontsize=13, color='black')
        
        ax.plot([18, 82], [y_surv, y_surv], color='black', lw=2.2)
        for x_p in prob_positions:
            ax.plot([x_p, x_p], [y_surv - 0.15, y_surv + 0.15], color='black', lw=1.0, ls=':')
    
    plt.tight_layout()
    plt.savefig(f'{OUT}/Fig_Nomogram_M4c.png', dpi=DPI, bbox_inches='tight', facecolor='white')
    plt.savefig(f'{OUT}/Fig_Nomogram_M4c.tiff', dpi=DPI, bbox_inches='tight', facecolor='white')
    plt.close()
    print('✅ Journal-style Nomogram')

draw_journal_nomogram()
