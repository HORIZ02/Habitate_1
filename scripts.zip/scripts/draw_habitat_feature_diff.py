#!/usr/bin/env python3
"""重新生成 Fig_Habitat_feature_diff 为 2行×3列"""
import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams.update({'font.family':'Times New Roman','font.size':12,
                     'axes.facecolor':'white','figure.facecolor':'white'})
OUT="<PROJECT_ROOT>/results/figures";DPI=600

dwi_all=pd.read_csv("<PROJECT_ROOT>/data/features/dwi_pyradiomics_k3.csv")
dce_all=pd.read_csv("<PROJECT_ROOT>/data/features/dce_pyradiomics_k3.csv")

top_feats=['original_shape_MinorAxisLength','original_shape_MajorAxisLength',
           'original_firstorder_Mean','original_firstorder_Skewness',
           'original_firstorder_Kurtosis','original_glcm_Contrast']
feats_avail=[f for f in top_feats if f in dwi_all.columns]
print(f'可用特征: {len(feats_avail)}')

# 2行×3列
fig,axes=plt.subplots(2,3,figsize=(15,10))
colors=['#2166AC','#4DAF4A','#E41A1C']
labels=['Habitat L','Habitat M','Habitat H']

for ai,f in enumerate(feats_avail[:6]):
    ax=axes[ai//3][ai%3]
    data=[]
    for hab in ['habitat_L','habitat_M','habitat_H']:
        vals=dwi_all[dwi_all['Habitat']==hab][f].dropna()
        data.append(vals)
    bp=ax.boxplot(data,patch_artist=True,showfliers=False)
    for pi,patch in enumerate(bp['boxes']):
        patch.set_facecolor(colors[pi]);patch.set_alpha(0.7)
        patch.set_edgecolor('black');patch.set_linewidth(1.2)
    for w in bp['whiskers']:w.set_color('#333333');w.set_linewidth(1)
    for c in bp['caps']:c.set_color('#333333');c.set_linewidth(1)
    for m in bp['medians']:m.set_color('black');m.set_linewidth(1.5)
    ax.set_xticklabels(labels,fontsize=11)
    # 简化特征名
    short=f.replace('original_shape_','').replace('original_firstorder_','').replace('original_glcm_','')
    ax.set_title(short,fontsize=14,fontweight='bold')
    ax.tick_params(labelsize=11)
    ax.spines['top'].set_visible(False);ax.spines['right'].set_visible(False)
    ax.grid(axis='y',alpha=0.2)

# 隐藏多余的子图
for ai in range(len(feats_avail),6):
    axes[ai//3][ai%3].axis('off')

plt.tight_layout()
plt.savefig(f'{OUT}/Fig_Habitat_feature_diff.png',dpi=DPI,bbox_inches='tight',facecolor='white')
plt.savefig(f'{OUT}/Fig_Habitat_feature_diff.tiff',dpi=DPI,bbox_inches='tight',facecolor='white')
plt.close()
print('✅ Fig_Habitat_feature_diff (2×3)')
