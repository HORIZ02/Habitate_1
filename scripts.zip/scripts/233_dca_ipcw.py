# -*- coding: utf-8 -*-
"""IPCW加权版 DCA (Vickers time-to-event)：Fig S7 重绘，36月，M0 vs M4c"""
import os, warnings
import numpy as np, pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold
from sksurv.linear_model import CoxnetSurvivalAnalysis
from sksurv.metrics import concordance_index_censored
from lifelines import KaplanMeierFitter
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rcParams, font_manager
warnings.filterwarnings('ignore')
for f in ['Times New Roman','Times','Nimbus Roman']:
    try: font_manager.findfont(f,fallback_to_default=False); rcParams['font.family']=f; break
    except: pass
rcParams['font.size']=12

BASE=r'<PROJECT_ROOT>'
ALPHAS=np.logspace(-1.5,0,20); CLIN=['NAC','N','Age','Grade','T','ALN','proRT','ER','PR','Her2','Meno']; SEED=42
def surv(df): return np.array([(bool(e),float(t)) for e,t in zip(df['DFS'],df['Time'])],dtype=[('event','bool'),('time','float')])
def fit_alpha(Xtr,ytr):
    s=StandardScaler(); Xs=s.fit_transform(Xtr); sc={a:[] for a in ALPHAS}
    for tr,te in KFold(5,shuffle=True,random_state=SEED).split(Xs):
        si=StandardScaler(); Xi=si.fit_transform(Xs[tr]); Xv=si.transform(Xs[te])
        try:
            c=CoxnetSurvivalAnalysis(l1_ratio=1,alphas=ALPHAS,max_iter=10000).fit(Xi,ytr[tr])
            for a in ALPHAS:
                try: sc[a].append(concordance_index_censored(ytr['event'][te],ytr['time'][te],c.predict(Xv,alpha=a))[0])
                except: sc[a].append(.5)
        except:
            for a in ALPHAS: sc[a].append(.5)
    return max(sc,key=lambda a:np.mean(sc[a]))
def oof_surv(X,y,times):
    Xv=X.values; n=len(Xv); S=np.full((n,len(times)),np.nan)
    for tr,te in KFold(5,shuffle=True,random_state=SEED).split(Xv):
        s=StandardScaler(); Xtr=s.fit_transform(Xv[tr]); Xte=s.transform(Xv[te])
        a=fit_alpha(Xv[tr],y[tr])
        c=CoxnetSurvivalAnalysis(l1_ratio=1,alphas=[a],max_iter=10000,fit_baseline_model=True).fit(Xtr,y[tr])
        sf=c.predict_survival_function(Xte)
        S[te]=np.array([[float(fn(t)) for t in times] for fn in sf])
    return S

clin=pd.read_csv(r'<DATA_ROOT>\分析结果\merged_data_corrected.csv',encoding='utf-8-sig')
clin['Case_No.']=clin['Case_No.'].astype(str); order=clin['Case_No.']
y=surv(clin); ev=y['event'].astype(bool); tm=y['time'].astype(float)
C=clin[CLIN].reset_index(drop=True); M0=C.fillna(0).astype(float)
rad=pd.read_csv(os.path.join(BASE,'data','features','dce_pyradiomics_k3.csv')); rad['Case_No.']=rad['Case_No.'].astype(str)
radH=rad[rad.Habitat=='habitat_H'].drop_duplicates('Case_No.').set_index('Case_No.')
rf=[c for c in radH.columns if c not in ('Case_No.','Habitat')]
M4c=pd.concat([C,radH[rf].loc[order].reset_index(drop=True).add_prefix('DCEH_')],axis=1).fillna(0).astype(float)

HOR=36
S0=oof_surv(M0,y,[HOR]); S4=oof_surv(M4c,y,[HOR])
p0=1-S0[:,0]; p4=1-S4[:,0]
n=len(tm)

# ---- IPCW 权重：删失生存 G(t)=P(未删失到t)，用KM估计删失分布 ----
cens=~ev
km=KaplanMeierFitter().fit(tm, event_observed=cens)
G_t=np.clip(km.predict(tm).values,1e-6,None)          # G at each patient's time
G_h=max(float(km.predict(HOR)),1e-6)                   # G(horizon)
event_by=ev & (tm<=HOR)                                # 36月内发生事件
at_risk=tm>HOR                                         # 36月时仍在观察（含以后事件/删失）
w_event=np.where(event_by, 1.0/G_t, 0.0)               # 事件者权重
w_risk =np.where(at_risk,  1.0/G_h, 0.0)               # 36月无事件者权重
prev_ipcw=w_event.sum()/n
print(f'IPCW prevalence(36m)={prev_ipcw:.3f}  G_h={G_h:.3f}  删除排除:{(~ev & (tm<=HOR)).sum()}')

def nb(pred, th):
    treat=pred>=th
    tp=w_event[treat].sum(); fp=w_risk[treat].sum()
    return (tp - fp*th/(1-th))/n
def nb_all(th):
    return (w_event.sum() - w_risk.sum()*th/(1-th))/n

ths=np.arange(0.02,0.61,0.01)
nb0=np.array([nb(p0,th) for th in ths]); nb4=np.array([nb(p4,th) for th in ths])
nbal=np.array([nb_all(th) for th in ths])
for th in [0.10,0.15,0.20,0.30]:
    i=np.argmin(np.abs(ths-th)); print(f'NB@th={th}: M4c={nb4[i]:.3f}  M0={nb0[i]:.3f}  All={nbal[i]:.3f}')

# ---- 绘图 ----
fig,ax=plt.subplots(figsize=(7,5.6))
ax.plot(ths,nb4,color='#c0392b',lw=2.2,label='M4c (DCE_H habitat + clinical)')
ax.plot(ths,nb0,color='#2c3e50',lw=2.0,ls='--',label='M0 (clinical)')
ax.plot(ths,nbal,color='#7f8c8d',lw=1.6,ls=':',label='Treat all')
ax.axhline(0,color='#000000',lw=1.3,label='Treat none')
ax.set_xlim(0.02,0.60); ylo=min(-0.03,float(nbal.min())-0.01); yhi=max(float(nb4.max()),prev_ipcw)+0.03
ax.set_ylim(ylo,yhi)
ax.set_xlabel('Threshold probability',fontsize=13); ax.set_ylabel('Net benefit',fontsize=13)
ax.set_title('Decision curve analysis (IPCW) at 36 months',fontsize=14)
for sp in ['top','right']: ax.spines[sp].set_visible(False)
ax.tick_params(labelsize=11); ax.legend(frameon=False,fontsize=10,loc='upper right')
plt.tight_layout()
out=os.path.join(BASE,'results','figures','FigS7_DCA')
fig.savefig(out+'.png',dpi=600,bbox_inches='tight',facecolor='white')
fig.savefig(out+'.tiff',dpi=600,bbox_inches='tight',facecolor='white')
fig.savefig(out+'.pdf',bbox_inches='tight',facecolor='white')
import json
json.dump({'prevalence':round(float(prev_ipcw),4),'M0_010_020_030':[round(float(nb(p0,0.1)),3),round(float(nb(p0,0.2)),3),round(float(nb(p0,0.3)),3)],'M4c_010_020_030':[round(float(nb(p4,0.1)),3),round(float(nb(p4,0.2)),3),round(float(nb(p4,0.3)),3)]},open(os.path.join(BASE,'results','models','dca_ipcw.json'),'w'),indent=1)
print('saved FigS7_DCA(IPCW) + dca_ipcw.json')
