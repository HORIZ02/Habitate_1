# -*- coding: utf-8 -*-
"""
40_final_4center_consolidated.py — 4中心（401例/55事件）结果总表

把所有散落分析统一重算为一份一致、可复现的总报告。
输出：results/models/FINAL_4center_results.md + 配套 CSV
"""
import importlib.util, os, time
import numpy as np
import pandas as pd
from scipy.stats import spearmanr, chi2
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold
from sksurv.linear_model import CoxPHSurvivalAnalysis, CoxnetSurvivalAnalysis
from sksurv.metrics import concordance_index_censored, cumulative_dynamic_auc

spec = importlib.util.spec_from_file_location('m23b', r'<PROJECT_ROOT>\scripts\23b_spatial_incremental_modeling.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
BASE, OUT, CL = m.BASE, m.OUT, m.CLIN_VARS
MAX_MISSING, ALPHAS = m.MAX_MISSING, m.ALPHAS
SEED = 42
SEEDS20 = [42] + list(range(19))   # 20 种子：42(主结果) + 0–18
TIMES = [36, 60]
T0 = time.time()
L = []
def P(s=''):
    print(s); L.append(s)

# ---------------- 1. 队列 ----------------
a = pd.read_csv(r'<DATA_ROOT>\分析结果\merged_data_corrected.csv', encoding='utf-8-sig')
a['Case_No.'] = a['Case_No.'].astype(str)
y = m.make_surv(a); ev, tm = y['event'].astype(bool), y['time'].astype(float)
order = a['Case_No.']
CEN = sorted(a.Center.unique())

P('# HER2-low 生境组学 — 4 中心结果总表')
P(f'\n> 队列 401 例 / {ev.sum()} 事件（{ev.sum()/len(a)*100:.1f}%）/ 中位随访 {np.median(tm):.0f} 月'
  f'（IQR {np.percentile(tm,25):.0f}–{np.percentile(tm,75):.0f}）')
P(f'> 生成 {time.strftime("%Y-%m-%d %H:%M")}；脚本 scripts/40_final_4center_consolidated.py\n')

P('## 1. 队列与基线\n')
rows = []
for name, sub in [('**总体**', a)] + [(k, a[a.Center == k]) for k in CEN]:
    rows.append(dict(组=name, n=len(sub), 事件=int(sub.DFS.sum()),
                     事件率=f'{sub.DFS.mean()*100:.1f}%',
                     随访中位=f'{sub.Time.median():.0f}',
                     Age=f'{sub.Age.mean():.1f}±{sub.Age.std(ddof=1):.1f}',
                     NAC=f'{sub.NAC.mean()*100:.1f}%', N阳性=f'{(sub["N"]>=1).mean()*100:.1f}%',
                     ALN阳性=f'{sub.ALN.mean()*100:.1f}%',
                     Grade3=f'{(sub.Grade>=3).mean()*100:.1f}%',
                     ER阳性=f'{sub.ER.mean()*100:.1f}%', PR阳性=f'{sub.PR.mean()*100:.1f}%',
                     **{'HER2 2+': f'{(sub.Her2==2).mean()*100:.1f}%'},
                     proRT=f'{sub.proRT.mean()*100:.1f}%'))
# ★ 语义守卫（防"序数当比例"复发）：N 是 TNM 分期 0-3，ALN 是 0/1
_np = (a['N'] >= 1).mean() * 100
_al = a.ALN.mean() * 100
assert abs(_np - _al) < 5, (
    f'N阳性({_np:.1f}%) 与 ALN阳性({_al:.1f}%) 应接近 —— 口径可能写错（把分期序数当比例？）')
assert a['N'].min() >= 0 and a['N'].max() <= 3, 'N 应为 TNM N 分期 0-3'
assert set(a.ALN.dropna().unique()) <= {0, 1}, 'ALN 应为二元 0/1'

bt = pd.DataFrame(rows)
P(bt.to_markdown(index=False))
P(f'\n> 注：Her2 取值为 {{1,2}}（IHC 1+ / 2+），上表按 2+ 占比报告')
bt.to_csv(os.path.join(OUT, 'FINAL_T1_baseline_4center.csv'), index=False, encoding='utf-8-sig')

# ---------------- 2. 特征 ----------------
_rad = pd.read_csv(os.path.join(BASE, 'data', 'features', 'dce_pyradiomics_k3.csv'))
_rad['Case_No.'] = _rad['Case_No.'].astype(str)
RF = [c for c in _rad.columns if c not in ('Case_No.', 'Habitat')]
radH = _rad[_rad.Habitat == 'habitat_H'].drop_duplicates('Case_No.').set_index('Case_No.').loc[order, RF].reset_index(drop=True)

sp = pd.read_csv(os.path.join(BASE, 'data', 'features', 'habitat_spatial_features_k3.csv'))
sp['Case_No.'] = sp['Case_No.'].astype(str)
dw = sp[sp.modality == 'DWI'].set_index('Case_No.')
dc = sp[sp.modality == 'DCE'].set_index('Case_No.')
spw_all = pd.concat([dw[[c for c in sp.columns if c.startswith('dwi_')]].loc[order].reset_index(drop=True),
                     dc[[c for c in sp.columns if c.startswith('dce_')]].loc[order].reset_index(drop=True)], axis=1)
ms = spw_all.isna().mean()
DROP = list(ms[ms > MAX_MISSING].index)
spw = spw_all.drop(columns=DROP)

P('\n## 2. 特征清单\n')
P(f'| 类别 | 数量 | 说明 |')
P(f'|---|---|---|')
P(f'| PyRadiomics（DWI+DCE × 4区域 × 107） | 856 | 形状14/一阶18/GLCM24/GLDM14/GLRLM16/GLSZM16/NGTDM5 |')
P(f'| DCE_H 组学（M4c 用） | 107 | 上述之一区域 |')
P(f'| 生境空间结构特征（DWI+DCE） | 84 → **{spw.shape[1]}** | 剔除缺失>20%：{DROP} |')
P(f'| └ A 形态（体积/表面积/球度/分形维） | 24 → 24 | 9/12 与形状特征冗余 |')
P(f'| └ B 拓扑碎片化（n_components/largest_frac/euler） | 18 | 空间特征 |')
P(f'| └ C 空间分布（centroid_dist/radial/edge_dist） | 24 | 空间特征 |')
P(f'| └ D 生境间关系（interface/生境间质心距） | 18 | 空间特征 |')

# ---------------- 3. 单变量 ----------------
def univariate(df):
    out = []
    for col in df.columns:
        x = df[col].values.astype(float); ok = np.isfinite(x)
        if ok.sum() < 30 or np.std(x[ok], ddof=1) == 0: continue
        z = (x[ok] - x[ok].mean()) / x[ok].std(ddof=1)
        try:
            b = float(CoxPHSurvivalAnalysis(alpha=1e-8).fit(z.reshape(-1, 1), y[ok]).coef_[0])
        except Exception:
            continue
        def nll(bb):
            eta = bb * z; e = np.exp(np.clip(eta, -50, 50))
            o_ = np.argsort(tm[ok]); e2 = e[o_]; ev2 = ev[ok][o_]
            return -(np.sum(eta[ev[ok]]) - np.sum(np.log(np.cumsum(e2)[ev2])))
        h = 1e-4; H = (nll(b + h) - 2 * nll(b) + nll(b - h)) / h**2
        se = np.sqrt(1 / H) if H > 0 else np.nan
        p = chi2.sf((b / se) ** 2, 1) if np.isfinite(se) and se > 0 else np.nan
        out.append(dict(feature=col, n=int(ok.sum()), HR=np.exp(b),
                        lo=np.exp(b - 1.96*se), hi=np.exp(b + 1.96*se), P=p,
                        C_index=concordance_index_censored(ev[ok], tm[ok], z)[0]))
    r = pd.DataFrame(out).sort_values('P').reset_index(drop=True)
    if len(r):
        q = r.P.values * len(r) / np.arange(1, len(r) + 1)
        r['FDR'] = np.minimum(np.minimum.accumulate(q[::-1])[::-1], 1.0)
    return r

# ★ 2026-09-14 修正：本脚本原自实现的 Wald 口径已废弃——同口径下 P<0.05 为 15、
#   FDR<0.05 为 6，与权威 lifelines 口径（19 / 4）冲突。现统一改读权威文件，
#   并停止输出 FINAL_univariate_spatial_4center.csv（该文件已删除）。
#   权威口径定义见 scripts/22_univariate_spatial_cox_k3.py（lifelines CoxPHFitter，按 1 SD，BH-FDR）。
_uf = os.path.join(OUT, 'FINAL_univariate_lifelines_4center.csv')
u = pd.read_csv(_uf) if os.path.exists(_uf) else univariate(spw)
P('\n## 3. 单变量 Cox（生境空间结构特征；权威口径 = lifelines，按 1 SD，BH-FDR）\n')
P(f'- P<0.05: **{(u.P<0.05).sum()}** / {len(u)}；FDR<0.05: **{(u.FDR<0.05).sum()}** 个\n')
P(u.sort_values('P').head(14).round(4).to_markdown(index=False))

# ---------------- 4. 冗余 ----------------
P('\n## 4. 空间特征 vs 传统组学 冗余（Spearman，n=401）\n')
allr = _rad[_rad['Case_No.'].isin(order)]
# 修正：双模态 × 4 区域（原 f'{h[:2]}_' 使 habitat_L/M/H 撞名被 H 覆盖，且漏 DWI）
_REG = {'Whole_tumor': 'WT', 'habitat_L': 'L', 'habitat_M': 'M', 'habitat_H': 'H'}
_cs, _cn = [], []
for _mod, _fn in [('dwi', 'dwi_pyradiomics_k3.csv'), ('dce', 'dce_pyradiomics_k3.csv')]:
    _r = pd.read_csv(os.path.join(BASE, 'data', 'features', _fn))
    _r['Case_No.'] = _r['Case_No.'].astype(str)
    _RFm = [c for c in _r.columns if c not in ('Case_No.', 'Habitat')]
    for _h, _t in _REG.items():
        _sb = _r[(_r.Habitat == _h) & (_r['Case_No.'].isin(order))].drop_duplicates('Case_No.').set_index('Case_No.').loc[order, _RFm]
        _cs.append(_sb.values); _cn += [f'{_mod}_{_t}_{c}' for c in _RFm]
W = pd.DataFrame(np.hstack(_cs), columns=_cn)
mx, pt = {}, {}
for x_ in spw_all.columns:
    xa = spw_all[x_].values
    okx = np.isfinite(xa)
    if okx.sum() < 30 or np.nanstd(xa) == 0: continue
    best, bv = None, 0
    for j, y_ in enumerate(W.columns):
        yb = W.iloc[:, j].values
        mm = okx & np.isfinite(yb)
        if mm.sum() < 30: continue
        rr = abs(spearmanr(xa[mm], yb[mm])[0])
        if rr > bv: best, bv = y_, rr
    mx[x_], pt[x_] = bv, best
red = pd.DataFrame({'feature': list(mx), 'max_abs_r': list(mx.values()), 'partner': [pt[k] for k in mx]})
red['verdict'] = np.where(red.max_abs_r >= 0.90, '高度冗余', np.where(red.max_abs_r >= 0.80, '中等', '新增信息'))
P(f"- 高度冗余(|ρ|≥0.90): **{(red.max_abs_r>=0.90).sum()}**；中等(0.80–0.90): **{((red.max_abs_r>=0.80)&(red.max_abs_r<0.90)).sum()}**；"
  f"新增(<0.80): **{(red.max_abs_r<0.80).sum()}**\n")
KEY = ['dce_H_sphericity', 'dce_M_sphericity', 'dwi_H_n_voxels', 'dwi_M_n_components',
       'dce_L_surface', 'dce_H_surface', 'dce_H_euler', 'dwi_M_largest_frac',
       'dce_L_centroid_dist', 'dce_M_H_centroid_dist', 'dwi_H_n_voxels']
P(red.set_index('feature').reindex([k for k in KEY if k in red.feature.values]).round(3).to_markdown())
red.to_csv(os.path.join(OUT, 'FINAL_redundancy_4center.csv'), index=False, encoding='utf-8-sig')

NOVEL = set(red[red.max_abs_r < 0.80].feature)
P1 = [c for c in spw.columns if c in NOVEL]; P2 = list(spw.columns)
DCE_P1 = [c for c in P1 if c.startswith('dce_')]

# ---------------- 5. 建模总表 ----------------
C11 = a[CL].reset_index(drop=True)
C3 = a[['NAC', 'N', 'ALN']].reset_index(drop=True)
SPH = dc.loc[order, 'dce_H_sphericity'].reset_index(drop=True).astype(float)
S_DCE_P1 = spw[[c for c in DCE_P1 if c in spw.columns]]

SETS = {
    'M0 临床11': pd.concat([C11], axis=1),
    'M4c 原论文 (DCE_H 107 + 临床11)': pd.concat([C11, radH.add_prefix('DCEH_')], axis=1),
    f'M4c + P1 (新颖空间{len(P1)})': pd.concat([C11, radH.add_prefix('DCEH_'), spw[P1]], axis=1),
    f'M4c + P2 (全部空间{len(P2)})': pd.concat([C11, radH.add_prefix('DCEH_'), spw[P2]], axis=1),
    'M4c + DCE空间(新颖)': pd.concat([C11, radH.add_prefix('DCEH_'), S_DCE_P1], axis=1),
    '临床 + P2': pd.concat([C11, spw[P2]], axis=1),
    '临床 + DCE空间(新颖)': pd.concat([C11, S_DCE_P1], axis=1),
    'P2_only (纯空间特征)': pd.concat([spw[P2]], axis=1),
    '临床3 + 球度 (4变量)': pd.concat([C3, SPH.rename('sph')], axis=1),
}
P('\n## 5. 模型效能对比（主表）\n')
P('> C_CV = 原项目口径（20 alpha 网格选优，含选择乐观性）｜C_OOF = 嵌套5折CV（无偏）')
P('> ΔC 与 p = 相对 M4c 的配对 Bootstrap（1000×）\n')
res, oofs = [], {}
for name, X in SETS.items():
    X = X.fillna(0).astype(float)
    if name.startswith('临床3'):
        oof = np.full(len(X), np.nan)
        for tr, te in KFold(5, shuffle=True, random_state=SEED).split(X.values):
            s = StandardScaler()
            oof[te] = CoxPHSurvivalAnalysis(alpha=0.1).fit(s.fit_transform(X.values[tr]), y[tr]).predict(s.transform(X.values[te]))
        c_cv = np.nan
    else:
        c_cv, ba, sel = m.run_lasso_cv(X, y)
        oof = m.nested_oof(X, y)
    cc = concordance_index_censored(ev, tm, oof)[0]
    lo, hi = m.boot_ci(ev, tm, oof)
    oofs[name] = oof
    res.append(dict(Model=name, n_feat=X.shape[1], EPV=round(ev.sum()/X.shape[1], 2),
                    C_CV=round(float(c_cv), 4) if np.isfinite(c_cv) else None,
                    C_OOF=round(float(cc), 4), CI=f'[{lo:.3f},{hi:.3f}]'))
ref = 'M4c 原论文 (DCE_H 107 + 临床11)'
for i, rr in enumerate(res):
    if rr['Model'] == ref: continue
    dlo, dhi, d, p = m.paired_boot(ev, tm, oofs[rr['Model']], oofs[ref])
    res[i].update(dC=round(d, 4), p=round(p, 4))
mt = pd.DataFrame(res)
P(mt.to_markdown(index=False))
mt.to_csv(os.path.join(OUT, 'FINAL_model_table_4center.csv'), index=False, encoding='utf-8-sig')

# ---------------- 6. 多种子稳定性 ----------------
P('\n## 6. 多种子稳定性（20 seeds：42, 0–18 × 5折）\n')
P(f'{"模型":32s} {"C均值":>8} {"SD":>7} {"min":>7} {"max":>7}')
st = []
for name, X in SETS.items():
    X = X.fillna(0).astype(float); cs = []
    for sd in SEEDS20:
        if name.startswith('临床3'):
            o = np.full(len(X), np.nan)
            for tr, te in KFold(5, shuffle=True, random_state=sd).split(X.values):
                s = StandardScaler()
                o[te] = CoxPHSurvivalAnalysis(alpha=0.1).fit(s.fit_transform(X.values[tr]), y[tr]).predict(s.transform(X.values[te]))
        else:
            o = m.nested_oof(X, y, seed=sd)
        cs.append(concordance_index_censored(ev, tm, o)[0])
    st.append(dict(Model=name, mean=float(np.mean(cs)), sd=float(np.std(cs, ddof=1)),
                   min=float(np.min(cs)), max=float(np.max(cs))))
    P(f'{name:32s} {np.mean(cs):8.4f} {np.std(cs,ddof=1):7.4f} {np.min(cs):7.4f} {np.max(cs):7.4f}')
dfs = pd.DataFrame(st); dfs.to_csv(os.path.join(OUT, 'FINAL_stability_4center.csv'), index=False, encoding='utf-8-sig')
P('\n**与 M4c 对比（多种子均值 ± 合并SD，z 值）**\n')
b = dfs[dfs.Model == ref].iloc[0]
P('| 模型 | Δ均值 | 合并SD | z | 判定 |')
P('|---|---|---|---|---|')
for _, rr in dfs.iterrows():
    if rr.Model == ref: continue
    dm = rr['mean'] - b['mean']; z = dm / max(np.hypot(rr.sd, b.sd), 1e-9)
    tag = '优于' if z > 1 else ('持平' if abs(z) <= 1 else '差')
    P(f'| {rr.Model} | {dm:+.4f} | {np.hypot(rr.sd,b.sd):.4f} | {z:+.2f} | {tag} |')

# ---------------- 7. AUC ----------------
P('\n## 7. time-dependent AUC（20 seeds：42, 0–18，嵌套OOF）\n')
P('| 模型 | AUC@36m | AUC@60m |')
P('|---|---|---|')
auc_rows = []
for name, X in SETS.items():
    X = X.fillna(0).astype(float).values
    r36, r60 = [], []
    for sd in SEEDS20:
        p36, p60 = [], []
        for tr, te in KFold(5, shuffle=True, random_state=sd).split(X):
            s = StandardScaler(); A = s.fit_transform(X[tr]); B = s.transform(X[te])
            try:
                if name.startswith('临床3'):
                    pr = CoxPHSurvivalAnalysis(alpha=0.1).fit(A, y[tr]).predict(B)
                else:
                    _, ba, _ = m.run_lasso_cv(pd.DataFrame(X[tr]), y[tr])
                    pr = np.asarray(CoxnetSurvivalAnalysis(l1_ratio=1, alphas=[ba], max_iter=20000).fit(A, y[tr]).predict(B)).ravel()
                au, _ = cumulative_dynamic_auc(y[tr], y[te], pr, TIMES)
                p36.append(au[0]); p60.append(au[1])
            except Exception:
                pass
        if p36: r36.append(np.mean(p36)); r60.append(np.mean(p60))
    a36, a60 = np.array(r36), np.array(r60)
    P(f'| {name} | {a36.mean():.4f} ± {a36.std(ddof=1):.4f} | {a60.mean():.4f} ± {a60.std(ddof=1):.4f} |')
    auc_rows.append(dict(Model=name, AUC36=round(float(a36.mean()), 4), AUC36_SD=round(float(a36.std(ddof=1)), 4),
                         AUC60=round(float(a60.mean()), 4), AUC60_SD=round(float(a60.std(ddof=1)), 4)))
pd.DataFrame(auc_rows).to_csv(os.path.join(OUT, 'FINAL_auc_4center.csv'), index=False, encoding='utf-8-sig')

# ---------------- 8. 中心效应 ----------------
P('\n## 8. 中心效应诊断（4 中心）\n')
Xcl = C11.fillna(C11.median()).astype(float).values
ctr = a.Center.values
P('**8.1 中心内 C-index（各中心内部5折，20种子 42/0–18 均值）**\n')
P('| 中心 | n | 事件 | 事件率 | 中心内 C |')
P('|---|---|---|---|---|')
for k in CEN:
    i = np.where(ctr == k)[0]
    if ev[i].sum() < 5:
        P(f'| {k} | {len(i)} | {ev[i].sum()} | {a.DFS.values[i].mean()*100:.1f}% | 事件不足，无法估计 |'); continue
    cs = []
    for sd in SEEDS20:
        o = np.full(len(i), np.nan)
        for tr, te in KFold(5, shuffle=True, random_state=sd).split(i):
            s = StandardScaler()
            o[te] = CoxPHSurvivalAnalysis(alpha=0.1).fit(s.fit_transform(Xcl[i][tr]), y[i][tr]).predict(s.transform(Xcl[i][te]))
        cs.append(concordance_index_censored(ev[i], tm[i], o)[0])
    P(f'| {k} | {len(i)} | {ev[i].sum()} | {a.DFS.values[i].mean()*100:.1f}% | {np.mean(cs):.4f} ± {np.std(cs,ddof=1):.4f} |')

P('\n**8.2 留一中心交叉验证（LOCO，训练3中心→预测留出中心）**\n')
P('| 留出中心 | 训练事件 | 测试事件 | 跨中心 C |')
P('|---|---|---|---|')
for k in CEN:
    tr, te = ctr != k, ctr == k
    if ev[tr].sum() < 10 or ev[te].sum() < 2: continue
    s = StandardScaler(); A = s.fit_transform(Xcl[tr]); B = s.transform(Xcl[te])
    pr = CoxPHSurvivalAnalysis(alpha=0.1).fit(A, y[tr]).predict(B)
    P(f'| {k} | {ev[tr].sum()} | {ev[te].sum()} | {concordance_index_censored(ev[te], tm[te], pr)[0]:.4f} |')

P('\n**8.3 纯中心效应 + 合并虚高**\n')
# 中心内均值（事件加权，20 种子 42/0–18）——与 F5 图同口径
wc_num, wc_den = 0.0, 0
for k in CEN:
    i = np.where(ctr == k)[0]
    if ev[i].sum() < 5: continue
    cs_w = []
    for sd in SEEDS20:
        o = np.full(len(i), np.nan)
        for tr, te in KFold(5, shuffle=True, random_state=sd).split(i):
            s = StandardScaler()
            o[te] = CoxPHSurvivalAnalysis(alpha=0.1).fit(s.fit_transform(Xcl[i][tr]), y[i][tr]).predict(s.transform(Xcl[i][te]))
        cs_w.append(concordance_index_censored(ev[i], tm[i], o)[0])
    wc_num += float(np.mean(cs_w)) * int(ev[i].sum()); wc_den += int(ev[i].sum())
within_w = wc_num / wc_den
pooled = []
for sd in SEEDS20:
    o = np.full(len(a), np.nan)
    for tr, te in KFold(5, shuffle=True, random_state=sd).split(Xcl):
        s = StandardScaler()
        o[te] = CoxPHSurvivalAnalysis(alpha=0.1).fit(s.fit_transform(Xcl[tr]), y[tr]).predict(s.transform(Xcl[te]))
    pooled.append(concordance_index_censored(ev, tm, o)[0])
risk = np.zeros(len(a))
for tr, te in KFold(5, shuffle=True, random_state=SEED).split(a):
    rate = a.iloc[tr].groupby('Center')['DFS'].mean()
    risk[te] = a.iloc[te]['Center'].map(rate).fillna(rate.mean()).values
pc = concordance_index_censored(ev, tm, risk)[0]
P(f'- 合并评估（临床11，20种子 42/0–18）= **{np.mean(pooled):.4f} ± {np.std(pooled,ddof=1):.4f}**')
P(f'- 中心内平均（事件加权，同口径）= **{within_w:.4f}**')
P(f'- **虚高 = +{np.mean(pooled) - within_w:.4f}**')
P(f'- 纯中心效应（仅中心事件率）= {pc:.4f}')
P(f'\n> 解读：合并评估比中心内评估高约 {np.mean(pooled) - within_w:.3f}，说明有相当一部分"效能"来自中心间对比而非病人级判别。')

# ---------------- 9. EPV ----------------
P('\n## 9. EPV 汇总（事件数 / 变量数；EPV≥10 为经验充足）\n')
P('| 模型 | 变量数 | EPV | 评价 |')
P('|---|---|---|---|')
for _, rr in mt.iterrows():
    e = rr.EPV
    P(f"| {rr.Model} | {rr.n_feat} | {e:.2f} | {'充足' if e>=10 else ('不足' if e>=1 else '严重不足(<1)')} |")

rep = os.path.join(OUT, 'FINAL_4center_results.md')
with open(rep, 'w', encoding='utf-8') as fh:
    fh.write('\n'.join(L))
print(f'\n[{time.time()-T0:.0f}s] -> {rep}')
