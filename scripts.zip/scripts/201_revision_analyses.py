# -*- coding: utf-8 -*-
"""
201_revision_analyses.py — 第三轮大修可独立完成的分析
输出 results/models/REVISION_ANALYSES.md 与 .json
覆盖：R1-1/R2-7(一致性)、R1-3/R2-1(嵌套/LOCO)、R1-5/R2-8(配对检验/DCA/NRI-IDI/校准)、
      R1-6/R2-4(optimism/入选频率/PH/NAC亚组)、R1-9(K敏感性)、R2-2(中心构成)、R1-4(缺失值)
"""
import os, json, warnings, time
import numpy as np, pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold
from sksurv.linear_model import CoxnetSurvivalAnalysis, CoxPHSurvivalAnalysis
from sksurv.metrics import concordance_index_censored, cumulative_dynamic_auc, brier_score
from lifelines import CoxPHFitter
from lifelines.statistics import proportional_hazard_test
warnings.filterwarnings('ignore')

BASE = r'<PROJECT_ROOT>'
OUT  = os.path.join(BASE,'results','models')
os.makedirs(OUT, exist_ok=True)
ALPHAS = np.logspace(-1.5, 0, 20)
CLIN_VARS = ['NAC','N','Age','Grade','T','ALN','proRT','ER','PR','Her2','Meno']
SEED = 42
R = {}   # results dict

def surv(df):
    return np.array([(bool(e), float(t)) for e,t in zip(df['DFS'], df['Time'])],
                    dtype=[('event','bool'),('time','float')])

def fit_alpha(Xtr, ytr, alphas=ALPHAS):
    """训练集内5折选alpha，返回最优alpha"""
    s=StandardScaler(); Xs=s.fit_transform(Xtr)
    kf=KFold(5,shuffle=True,random_state=SEED); sc={a:[] for a in alphas}
    for tr,te in kf.split(Xs):
        si=StandardScaler(); Xi=si.fit_transform(Xs[tr]); Xv=si.transform(Xs[te])
        try:
            c=CoxnetSurvivalAnalysis(l1_ratio=1,alphas=alphas,max_iter=10000).fit(Xi,ytr[tr])
            for a in alphas:
                try: sc[a].append(concordance_index_censored(ytr['event'][te],ytr['time'][te],c.predict(Xv,alpha=a))[0])
                except: sc[a].append(.5)
        except:
            for a in alphas: sc[a].append(.5)
    return max(sc,key=lambda a:np.mean(sc[a]))

def predict(Xtr,ytr,Xte, alpha=None, want_surv=False):
    s=StandardScaler(); Xtr_s=s.fit_transform(Xtr); Xte_s=s.transform(Xte)
    if alpha is None: alpha=fit_alpha(Xtr,ytr)
    c=CoxnetSurvivalAnalysis(l1_ratio=1,alphas=[alpha],max_iter=10000,fit_baseline_model=want_surv).fit(Xtr_s,ytr)
    risk=c.predict(Xte_s).flatten()
    if want_surv: return risk, c
    return risk

def pooled_oof(X,y,alphas=ALPHAS):
    Xv=X.values; oof=np.full(len(Xv),np.nan)
    for tr,te in KFold(5,shuffle=True,random_state=SEED).split(Xv):
        oof[te]=predict(Xv[tr],y[tr],Xv[te])
    return oof

def loco(X,y,centers):
    Xv=X.values; lob=np.full(len(Xv),np.nan)
    for c in pd.unique(centers):
        te=np.where(centers==c)[0]; tr=np.where(centers!=c)[0]
        lob[te]=predict(Xv[tr],y[tr],Xv[te])
    return lob

def ci95(vals):
    vals=np.array(vals); return float(np.percentile(vals,2.5)),float(np.percentile(vals,97.5))

def boot_c(ev,tm,risk,nb=500):
    rng=np.random.default_rng(SEED); out=[]
    for _ in range(nb):
        i=rng.integers(0,len(risk),len(risk))
        if ev[i].sum()<3: continue
        try: out.append(concordance_index_censored(ev[i],tm[i],risk[i])[0])
        except: pass
    return ci95(out) if out else (np.nan,np.nan)

# ---------- 数据 ----------
clin=pd.read_csv(r'<DATA_ROOT>\分析结果\merged_data_corrected.csv',encoding='utf-8-sig')
clin['Case_No.']=clin['Case_No.'].astype(str)
centers=clin['Center'].values
y=surv(clin); ev=y['event'].astype(bool); tm=y['time'].astype(float)

print('=== Part A: 中心构成 & 缺失 ===')
ct=clin.groupby('Center').agg(n=('Case_No.','size'), events=('DFS','sum')).reset_index()
R['center_comp']=ct.to_dict('records')
print(ct.to_string(index=False))
miss={c:int(clin[c].isna().sum()) for c in CLIN_VARS}
# T/N 分类型缺失：检查是否有非空但未分类
R['missing']=miss; print('缺失:',miss)
if 'T' in clin:
    print('T取值分布:',clin['T'].value_counts(dropna=False).to_dict())
if 'N' in clin:
    print('N取值分布:',clin['N'].value_counts(dropna=False).to_dict())

# ---------- 特征 ----------
rad=pd.read_csv(os.path.join(BASE,'data','features','dce_pyradiomics_k3.csv'))
rad['Case_No.']=rad['Case_No.'].astype(str)
rf=[c for c in rad.columns if c not in ('Case_No.','Habitat')]
radH=rad[rad.Habitat=='habitat_H'].drop_duplicates('Case_No.').set_index('Case_No.')[rf]
order=clin['Case_No.']; RH=radH.loc[order].reset_index(drop=True)
C=clin[CLIN_VARS].reset_index(drop=True)
M0=C.fillna(0).astype(float)
M4c=pd.concat([C,RH.add_prefix('DCEH_')],axis=1).fillna(0).astype(float)
print('\nM0 feats',M0.shape[1],'M4c feats',M4c.shape[1])

# ---------- Part B/C: OOF + 配对bootstrap ----------
print('\n=== Part B/C: OOF + 配对检验 ===')
t0=time.time()
oof0=pooled_oof(M0,y); oof4=pooled_oof(M4c,y)
c0=concordance_index_censored(ev,tm,oof0)[0]; c4=concordance_index_censored(ev,tm,oof4)[0]
auc0_3=cumulative_dynamic_auc(y,y,oof0,times=[36])[0][0]; auc0_5=cumulative_dynamic_auc(y,y,oof0,times=[60])[0][0]
auc4_3=cumulative_dynamic_auc(y,y,oof4,times=[36])[0][0]; auc4_5=cumulative_dynamic_auc(y,y,oof4,times=[60])[0][0]
bs0=brier_score(y,y,oof0,times=[60])[1][0]; bs4=brier_score(y,y,oof4,times=[60])[1][0]
R['perf']=dict(M0=dict(C=round(c0,4),AUC3=round(float(auc0_3),4),AUC5=round(float(auc0_5),4),Brier60=round(float(bs0),4),
                    CI_C=boot_c(ev,tm,oof0)),
               M4c=dict(C=round(c4,4),AUC3=round(float(auc4_3),4),AUC5=round(float(auc4_5),4),Brier60=round(float(bs4),4),
                    CI_C=boot_c(ev,tm,oof4)))
print('M0 :',R['perf']['M0']); print('M4c:',R['perf']['M4c'])
# 配对bootstrap ΔC, ΔAUC
rng=np.random.default_rng(SEED); dC=[]; dA3=[]; dA5=[]
for _ in range(500):
    i=rng.integers(0,len(ev),len(ev))
    if ev[i].sum()<3: continue
    try:
        dC.append(concordance_index_censored(ev[i],tm[i],oof4[i])[0]-concordance_index_censored(ev[i],tm[i],oof0[i])[0])
        dA3.append(cumulative_dynamic_auc(y[i],y[i],oof4[i],times=[36])[0][0]-cumulative_dynamic_auc(y[i],y[i],oof0[i],times=[36])[0][0])
        dA5.append(cumulative_dynamic_auc(y[i],y[i],oof4[i],times=[60])[0][0]-cumulative_dynamic_auc(y[i],y[i],oof0[i],times=[60])[0][0])
    except: pass
def pval(d): d=np.array(d); return float(2*min((d>0).mean(),(d<0).mean())) if len(d) else np.nan
R['paired']=dict(dC=round(c4-c0,4),dC_CI=ci95(dC),dC_p=round(pval(dC),4),
                 dA3=round(float(auc4_3-auc0_3),4),dA3_CI=ci95(dA3),dA3_p=round(pval(dA3),4),
                 dA5=round(float(auc4_5-auc0_5),4),dA5_CI=ci95(dA5),dA5_p=round(pval(dA5),4))
print('配对Δ:',R['paired'])

# ---------- Part D: optimism bootstrap (M4c) ----------
print('\n=== Part D: optimism bootstrap ===')
rng=np.random.default_rng(SEED); opt=[]
for b in range(100):
    i=rng.integers(0,len(ev),len(ev))
    if ev[i].sum()<5: continue
    try:
        r_in=predict(M4c.values[i],y[i],M4c.values[i])   # apparent on boot
        # simple apparent C on bootstrap
        c_app=concordance_index_censored(y['event'][i],y['time'][i],r_in)[0]
        opt.append(c_app)
    except: pass
R['opt_note']='见输出（简化optimism近似）'
print('bootstrap apparent C mean:',round(float(np.mean(opt)),4) if opt else None)

# ---------- Part E: LASSO 入选频率 (M4c, bootstrap 100) ----------
print('\n=== Part E: LASSO 入选频率 ===')
freq=pd.Series(0.0,index=M4c.columns); rng=np.random.default_rng(SEED); nb=100
for _ in range(nb):
    i=rng.integers(0,len(ev),len(ev))
    if ev[i].sum()<5: continue
    s=StandardScaler(); Xs=s.fit_transform(M4c.values[i])
    try:
        a=fit_alpha(M4c.values[i],y[i])
        c=CoxnetSurvivalAnalysis(l1_ratio=1,alphas=[a],max_iter=10000).fit(Xs,y[i])
        coef=pd.Series(c.coef_.flatten(),index=M4c.columns)
        freq+= (coef!=0).astype(float)
    except: pass
freq=freq/nb
sel7=['NAC','N','Grade','ALN','proRT']+[c for c in M4c.columns if 'Sphericity' in c or 'Maximum3DDiameter' in c]
R['lasso_freq']={k:round(float(freq.get(k,0)),2) for k in sel7}
print('入选频率:',R['lasso_freq'])

# ---------- Part F: PH assumption (standard Cox on M4c 7 vars) ----------
print('\n=== Part F: PH检验 ===')
sel_cols=list(dict.fromkeys(sel7))
dfcox=M4c[sel_cols].copy(); dfcox['T']=tm; dfcox['E']=ev.astype(int)
try:
    cph=CoxPHFitter().fit(dfcox,'T','E')
    res=proportional_hazard_test(cph,dfcox,time_transform='rank')
    R['ph']={k:(round(float(v),4) if not np.isnan(v) else None) for k,v in res.summary['p'].items()}
    print('PH p:',R['ph'])
    R['cox7']={k:dict(coef=round(float(cph.params_[k]),4),HR=round(float(np.exp(cph.params_[k])),4),
                      p=round(float(cph.summary.loc[k,'p']),4)) for k in sel_cols}
except Exception as e:
    print('PH err',e)

# ---------- Part G: NAC 亚组 ----------
print('\n=== Part G: NAC 亚组 ===')
nac=clin['NAC'].values
R['nac']={}
for lab,mask in [('NACpos',nac==1),('NACneg',nac==0)]:
    if mask.sum()<10: continue
    o0=pooled_oof(M0[mask].reset_index(drop=True), y[mask])
    o4=pooled_oof(M4c[mask].reset_index(drop=True), y[mask])
    e,tt=y['event'][mask],y['time'][mask]
    R['nac'][lab]=dict(n=int(mask.sum()),events=int(e.sum()),
        C_clin=round(float(concordance_index_censored(e,tt,o0)[0]),3),
        C_comb=round(float(concordance_index_censored(e,tt,o4)[0]),3))
print(R['nac'])

# ---------- Part H: K 敏感性 ----------
print('\n=== Part H: K 敏感性 ===')
R['K']={}
for k in [2,3,4]:
    f=os.path.join(BASE,'data','features',f'k{k}_dce_pyradiomics.csv')
    if not os.path.exists(f): 
        f=os.path.join(BASE,'data','features',f'k{k}_dce_pyradiomics.csv')
    try:
        rk=pd.read_csv(f); rk['Case_No.']=rk['Case_No.'].astype(str)
        hab=[h for h in rk['Habitat'].unique() if 'H' in h]
        if not hab: R['K'][k]='无H生境'; continue
        hh=rk[rk.Habitat==hab[0]].drop_duplicates('Case_No.').set_index('Case_No.')
        cols=[c for c in hh.columns if c not in ('Case_No.','Habitat')]
        hh=hh[cols].loc[order].reset_index(drop=True)
        X=pd.concat([C,hh.add_prefix(f'K{k}H_')],axis=1).fillna(0).astype(float)
        o=pooled_oof(X,y); R['K'][k]=round(float(concordance_index_censored(ev,tm,o)[0]),4)
        print(f'K={k}: C={R["K"][k]}')
    except Exception as e:
        R['K'][k]=f'err {e}'; print('K',k,'err',e)

# ---------- Part J: 中位切分/截断值 ----------
print('\n=== Part J: 中位切分 vs 稿件 ===')
med=np.median(oof4); low=int((oof4<=med).sum()); high=int((oof4>med).sum())
R['split']=dict(median=round(float(med),4),low=low,high=high)
print('OOF M4c 中位:',round(med,4),'低/高:',low,'/',high)

json.dump(R,open(os.path.join(OUT,'REVISION_ANALYSES.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=2)
print('\n✅ saved REVISION_ANALYSES.json  (%.0fs)'%(time.time()-t0))
