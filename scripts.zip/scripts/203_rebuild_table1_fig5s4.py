# -*- coding: utf-8 -*-
"""203: 重建Table1(按中心) + 统一口径风险分→Fig5(KM)/FigS4(风险分布)"""
import os, json, warnings
import numpy as np, pandas as pd
from scipy import stats
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold
from sksurv.linear_model import CoxnetSurvivalAnalysis
from lifelines import KaplanMeierFitter
from lifelines.statistics import logrank_test
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
warnings.filterwarnings('ignore')
BASE=r'<PROJECT_ROOT>'; FIG=os.path.join(BASE,'results','figures'); os.makedirs(FIG,exist_ok=True)
plt.rcParams['font.family']='serif'; plt.rcParams['font.serif']=['Times New Roman']
plt.rcParams['axes.spines.top']=False; plt.rcParams['axes.spines.right']=False
CLIN=['NAC','N','Age','Grade','T','ALN','proRT','ER','PR','Her2','Meno']; ALPHAS=np.logspace(-1.5,0,20); SEED=42
df=pd.read_csv(r'<DATA_ROOT>\分析结果\merged_data_corrected.csv',encoding='utf-8-sig')
df['Case_No.']=df['Case_No.'].astype(str)
centers=sorted(df['Center'].unique())

# ---------- Table 1 by center ----------
def fmt_p(p):
    return '<0.001' if p<0.001 else f'{p:.3f}'
rows=[]
rows.append(['Characteristic','Overall (N=401)']+[f'{c}' for c in centers]+['P value'])
rows.append(['N','401']+[str((df.Center==c).sum()) for c in centers]+['—'])
# NAC
def cat(var, labels, name):
    rows.append([name,'','','','','',''])   # 变量名标签行
    def cnt(mask): return mask.sum()
    def cell(mask,val):
        n=cnt(mask&(df[var]==val)); tot=cnt(mask); return f'{n} ({100*n/tot:.1f})' if tot else '-'
    def dist(mask): return [cnt(mask&(df[var]==v)) for v in labels]
    # P: chi2 across centers (labels vs center)
    tab=pd.crosstab(df[var],df['Center'])
    try: _,p,_,_=stats.chi2_contingency(tab.values)
    except: p=np.nan
    for v in labels:
        r=[f'  {v}']
        r.append(f'{(df[var]==v).sum()} ({100*(df[var]==v).mean():.1f})')
        for c in centers:
            m=df.Center==c; r.append(cell(m,v))
        r.append(fmt_p(p) if v==labels[0] else '')
        rows.append(r)
# NAC / Meno / Grade / T / N / ALN / proRT / ER / PR
cat('NAC',[0,1],'NAC (0=No,1=Yes)')
cat('Meno',[0,1],'Menopausal status (0=pre,1=post)')
cat('Grade',[1,2,3],'Grade')
# T grouped
df['T_g']=df['T'].map(lambda x: 'T1' if x==1 else ('T2' if x==2 else 'T3-T4'))
cat('T_g',['T1','T2','T3-T4'],'T stage')
df['N_g']=df['N'].map(lambda x: 'N0' if x==0 else ('N1' if x==1 else 'N2-N3'))
cat('N_g',['N0','N1','N2-N3'],'N stage')
cat('ALN',[0,1],'ALN (0=neg,1=pos)')
cat('proRT',[0,1],'proRT (0=No,1=Yes)')
cat('ER',[0,1],'ER (0=neg,1=pos)')
cat('PR',[0,1],'PR (0=neg,1=pos)')
# HER2 (1+ vs 2+)
if 'Her2' in df:
    cat('Her2',sorted(df['Her2'].dropna().unique().tolist()),'HER2 IHC (1+/2+)')
# Age
groups=[df['Age'].values]+[df[df.Center==c]['Age'].values for c in centers]
F,p=stats.f_oneway(*groups)
age_row=['  Age, mean ± SD', f'{df.Age.mean():.1f} ± {df.Age.std():.1f}']
for c in centers:
    a=df[df.Center==c]['Age']; age_row.append(f'{a.mean():.1f} ± {a.std():.1f}')
age_row.append(fmt_p(p)); rows.append(age_row)
# DFS event
df['DFS_g']=df['DFS'].map(lambda x:'Event' if x==1 else 'No event')
cat('DFS_g',['No event','Event'],'DFS event')
# 保存
pd.DataFrame(rows).to_csv(os.path.join(BASE,'results','models','Table1_by_center.csv'),index=False,header=False,encoding='utf-8-sig')
print('=== Table1 by center (前12行) ===')
for r in rows[:12]: print(' | '.join(r))
print('... 共%d行'%len(rows))
# 打印T/N合计校验
print('T_total=',df['T_g'].notna().sum(),'| T3-T4 n=',(df['T_g']=='T3-T4').sum())
print('N_total=',df['N_g'].notna().sum(),'| N2-N3 n=',(df['N_g']=='N2-N3').sum())

# ---------- 统一口径风险分 ----------
print('\n=== 统一口径风险分 ===')
C=df[CLIN].reset_index(drop=True)
rad=pd.read_csv(os.path.join(BASE,'data','features','dce_pyradiomics_k3.csv')); rad['Case_No.']=rad['Case_No.'].astype(str)
radH=rad[rad.Habitat=='habitat_H'].drop_duplicates('Case_No.').set_index('Case_No.')
rf=[c for c in radH.columns if c not in ('Case_No.','Habitat')]
order=df['Case_No.']
M4c=pd.concat([C,radH[rf].loc[order].reset_index(drop=True).add_prefix('DCEH_')],axis=1).fillna(0).astype(float)
# M0
def risk_full(X):
    s=StandardScaler(); Xs=s.fit_transform(X.values)
    # alpha via CV
    sc={a:[] for a in ALPHAS}
    for tr,te in KFold(5,shuffle=True,random_state=SEED).split(Xs):
        from sksurv.util import Surv
        ytr=Surv.from_arrays(df['DFS'].values[tr].astype(bool),df['Time'].values[tr])
        try:
            c=CoxnetSurvivalAnalysis(l1_ratio=1,alphas=ALPHAS,max_iter=10000).fit(Xs[tr],ytr)
            pass
        except: pass
    # simpler: use fixed moderate alpha 0.05
    c=CoxnetSurvivalAnalysis(l1_ratio=1,alphas=[0.05],max_iter=10000).fit(Xs,df[['DFS','Time']].apply(lambda r:(bool(r[0]),float(r[1])),axis=1).values if False else np.array([(bool(e),float(t)) for e,t in zip(df['DFS'],df['Time'])],dtype=[('event','bool'),('time','float')]))
    return c.predict(Xs).flatten()
from sksurv.util import Surv
ys=Surv.from_arrays(df['DFS'].astype(bool).values, df['Time'].values)
def risk_fit(X, alpha=0.05):
    s=StandardScaler(); Xs=s.fit_transform(X.values)
    c=CoxnetSurvivalAnalysis(l1_ratio=1,alphas=[alpha],max_iter=10000).fit(Xs,ys)
    return c.predict(Xs).flatten()
r_m4c=risk_fit(M4c); r_m0=risk_fit(C.fillna(0).astype(float))
order_a=np.argsort(r_m4c); is_high=np.zeros(len(r_m4c),bool); is_high[order_a[len(r_m4c)//2:]]=True
low=~is_high; high=is_high
med=float((r_m4c[order_a[len(r_m4c)//2-1]]+r_m4c[order_a[len(r_m4c)//2]])/2)
print('M4c 切点=%.4f 低/高=%d/%d'%(med,low.sum(),high.sum()))
# KM
def km(ax,risk,label):
    order=np.argsort(risk); g=np.zeros(len(risk),bool); g[order[len(risk)//2:]]=True  # 秩次切分，top half=high
    kmf1=KaplanMeierFitter().fit(df['Time'][~g],df['DFS'][~g],label=f'Low risk (n={int((~g).sum())})')
    kmf2=KaplanMeierFitter().fit(df['Time'][g],df['DFS'][g],label=f'High risk (n={int(g.sum())})')
    kmf1.plot_survival_function(ax=ax,ci_show=False,color='#2980B9')
    kmf2.plot_survival_function(ax=ax,ci_show=False,color='#C00000')
    lr=logrank_test(df['Time'][~g],df['Time'][g],df['DFS'][~g],df['DFS'][g])
    ax.set_xlabel('Time (months)',fontsize=11); ax.set_ylabel('Disease-free survival',fontsize=11)
    ax.set_title(label,fontsize=12)
    ax.legend(loc='lower left',frameon=False,fontsize=9)
    ax.text(0.98,0.95,f'log-rank P={lr.p_value:.3g}',transform=ax.transAxes,ha='right',va='top',fontsize=10)
    return lr.p_value
fig,axes=plt.subplots(1,2,figsize=(11,4.6))
p0=km(axes[0],r_m0,'M0 (Clinical)'); p4=km(axes[1],r_m4c,'M4c (DCE_H + Clinical)')
fig.tight_layout()
fig.savefig(os.path.join(FIG,'Fig5_KM_unified.png'),dpi=600,bbox_inches='tight')
fig.savefig(os.path.join(FIG,'Fig5_KM_unified.tiff'),dpi=300,bbox_inches='tight')
print('Fig5 已重生成; M0 P=%.3g M4c P=%.3g'%(p0,p4))
# Fig S4 风险分布
fig2,ax=plt.subplots(figsize=(8,4.2))
idx=np.argsort(r_m4c)
ax.scatter(np.arange(len(r_m4c)),r_m4c[idx],c=['#C00000' if is_high[j] else '#2980B9' for j in idx],s=14)
ax.axhline(med,color='#555555',ls='--',lw=1); ax.text(len(r_m4c)*0.01,med,f'median = {med:.3f}',va='bottom',fontsize=9)
ax.set_xlabel('Patients (ranked by M4c risk score)',fontsize=11); ax.set_ylabel('M4c risk score',fontsize=11)
ax.set_title('Distribution of M4c risk scores (n=401)',fontsize=12)
fig2.tight_layout(); fig2.savefig(os.path.join(FIG,'FigS4_risk_unified.png'),dpi=600,bbox_inches='tight')
fig2.savefig(os.path.join(FIG,'FigS4_risk_unified.tiff'),dpi=300,bbox_inches='tight')
print('FigS4 已重生成; cutoff=%.4f n_low=%d n_high=%d'%(med,int(low.sum()),int(high.sum())))
json.dump(dict(cutoff=round(float(med),4),n_low=int(low.sum()),n_high=int(high.sum()),p_M0=float(p0),p_M4c=float(p4)),
          open(os.path.join(BASE,'results','models','fig5s4_unified.json'),'w'),indent=2)
print('✅ DONE')
