#!/usr/bin/env python3
"""Fig. S3: LASSO tuning parameter α selection via 5-fold CV"""
import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold
from sksurv.linear_model import CoxnetSurvivalAnalysis
from sksurv.metrics import concordance_index_censored

plt.rcParams.update({'font.family':'Times New Roman','font.size':12,
                     'axes.facecolor':'white','figure.facecolor':'white'})

OUT="<PROJECT_ROOT>/results/figures";DPI=600

# Use M4c model (best model): DCE H + Clinical
clin=pd.read_csv('<DATA_ROOT>/分析结果/merged_data_corrected.csv')
dce=pd.read_csv('<PROJECT_ROOT>/data/features/dce_pyradiomics_k3.csv')
feats=[c for c in dce.columns if c not in ['Case_No.','Habitat']]
dce_h=dce[dce['Habitat']=='habitat_H'][['Case_No.']+feats].drop_duplicates('Case_No.').set_index('Case_No.')

clin_vars=['NAC','N','Age','Grade','T','ALN','proRT','ER','PR','Her2','Meno']
clin_df=clin[clin_vars+['Case_No.']].set_index('Case_No.')
X=pd.concat([clin_df,dce_h],axis=1).select_dtypes(include=[np.number]).dropna()
y=np.array(list(zip(clin['DFS'].astype(bool),clin['Time'])),dtype=[('event','bool'),('time','float')])

# Align
common_idx=X.index.intersection(clin['Case_No.'].values)
X=X.loc[common_idx]
y=y[[list(clin['Case_No.']).index(cn) for cn in common_idx]]

Xs=StandardScaler().fit_transform(X)
alphas=np.logspace(-2,0,30)  # 0.01 to 1.0

# 5-fold CV C-index for each alpha
kf=KFold(5,shuffle=True,random_state=42)
cv_means=[];cv_stds=[]
for a in alphas:
    cs=[]
    for train_idx,val_idx in kf.split(Xs):
        cph=CoxnetSurvivalAnalysis(l1_ratio=1,alphas=[a],max_iter=10000)
        cph.fit(Xs[train_idx],y[train_idx])
        risk=cph.predict(Xs[val_idx]).flatten()
        try:
            c=concordance_index_censored(y[val_idx]['event'],y[val_idx]['time'],risk)[0]
            cs.append(c)
        except:cs.append(0)
    cv_means.append(np.mean(cs));cv_stds.append(np.std(cs))

best_idx=np.argmax(cv_means)
best_alpha=alphas[best_idx]
best_c=cv_means[best_idx]

print(f'Optimal α={best_alpha:.4f}, C-index={best_c:.4f}')

# Also get number of non-zero coefficients at each alpha
n_coefs=[]
for a in alphas:
    cph=CoxnetSurvivalAnalysis(l1_ratio=1,alphas=[a],max_iter=10000)
    cph.fit(Xs,y)
    n_coefs.append(np.sum(np.abs(cph.coef_.flatten())>1e-10))

print(f'At optimal α: {n_coefs[best_idx]} non-zero coefficients')

# Plot
fig,ax1=plt.subplots(figsize=(10,7))

# CV C-index curve
ax1.errorbar(np.log10(alphas),cv_means,yerr=cv_stds,fmt='o-',color='#2166AC',
             capsize=3,linewidth=2,markersize=6,markerfacecolor='white',markeredgewidth=1.5,
             label='Mean CV C-index ± SD')
ax1.axvline(x=np.log10(best_alpha),color='#E41A1C',linestyle='--',linewidth=1.5,alpha=0.8)
ax1.axhline(y=best_c,color='#E41A1C',linestyle=':',linewidth=1,alpha=0.5)

# Annotate optimal point
ax1.plot(np.log10(best_alpha),best_c,'D',color='#E41A1C',markersize=10,zorder=5)
ax1.annotate(f'Optimal α={best_alpha:.3f}\nCV C-index={best_c:.3f}\n{int(n_coefs[best_idx])} features',
             xy=(np.log10(best_alpha),best_c),
             xytext=(-0.4,0.72),
             fontsize=12,color='#E41A1C',fontweight='bold',
             arrowprops=dict(arrowstyle='->',color='#E41A1C',lw=1.5),
             ha='left',va='top',bbox=dict(boxstyle='round,pad=0.3',fc='white',ec='#E41A1C',alpha=0.9))

ax1.set_xlabel('log(α)',fontsize=15)
ax1.set_ylabel('Mean CV C-index (M4c model)',fontsize=15,color='#2166AC')
ax1.tick_params(axis='y',labelsize=13,labelcolor='#2166AC')
ax1.tick_params(axis='x',labelsize=13)
ax1.spines['top'].set_visible(False);ax1.spines['right'].set_visible(False)
ax1.set_ylim(0.55,0.75)

# Second y-axis: number of features
ax2=ax1.twinx()
ax2.plot(np.log10(alphas),n_coefs,'s-',color='#4DAF4A',linewidth=1.5,markersize=4,alpha=0.7,label='N features')
ax2.set_ylabel('Number of selected features',fontsize=15,color='#4DAF4A')
ax2.tick_params(labelsize=13,labelcolor='#4DAF4A')
ax2.spines['top'].set_visible(False)
ax2.set_ylim(0,X.shape[1]+5)

# Legend combined
lines1,labels1=ax1.get_legend_handles_labels()
lines2,labels2=ax2.get_legend_handles_labels()
ax1.legend(lines1+lines2,labels1+labels2,loc='upper right',fontsize=12,
           frameon=True,edgecolor='#CCCCCC',facecolor='white')

plt.tight_layout()
for ext in ['png','tiff','jpg']:
    plt.savefig(f'{OUT}/Fig_S3_LASSO_tuning.{ext}',dpi=DPI,bbox_inches='tight',facecolor='white')
    print(f'✅ Fig_S3_LASSO_tuning.{ext}')
plt.close()
