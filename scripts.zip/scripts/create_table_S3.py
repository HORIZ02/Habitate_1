"""Create Table S3 with known LASSO-selected features"""
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml

doc = Document()
style = doc.styles['Normal']; style.font.name = 'Times New Roman'; style.font.size = Pt(10.5)

p = doc.add_paragraph()
r = p.add_run('Supplementary Table S3. LASSO-selected features for each model.')
r.bold = True; r.font.size = Pt(10.5); r.font.name = 'Times New Roman'

p2 = doc.add_paragraph()
r2 = p2.add_run('Features selected by LASSO-Cox regression with L1 regularization and 5-fold cross-validation. The regularization parameter α was selected to maximize the mean cross-validated C-index. (+) indicates positive coefficient (associated with worse prognosis); (−) indicates negative coefficient (protective).')
r2.font.size = Pt(9); r2.font.name = 'Times New Roman'; r2.italic = True

# Model data: (name, description, n_total, n_sel, features_str)
model_data = [
    ('DWI_WT', 'DWI Whole tumor', '321', '8', 'MinorAxisLength (−); Maximum2DDiameterRow (+); GLCM_ClusterProminence (+); GLCM_SumSquares (+); GLRLM_GrayLevelNonUniformity (+); GLSZM_SizeZoneNonUniformity (+); GLDM_DependenceNonUniformity (+); NGTDM_Strength (+)'),
    ('DWI_L', 'DWI Habitat_L', '107', '3', 'MinorAxisLength (−); GLCM_ClusterProminence (+); GLSZM_SizeZoneNonUniformity (+)'),
    ('DWI_M', 'DWI Habitat_M', '107', '2', 'MinorAxisLength (−); GLSZM_SizeZoneNonUniformity (+)'),
    ('DWI_H', 'DWI Habitat_H', '107', '1', 'GLSZM_SizeZoneNonUniformity (+)'),
    ('DCE_WT', 'DCE Whole tumor', '321', '1', 'Shape_Maximum3DDiameter (+)'),
    ('DCE_L', 'DCE Habitat_L', '107', '2', 'Shape_Maximum3DDiameter (+); GLCM_Idmn (−)'),
    ('DCE_M', 'DCE Habitat_M', '107', '1', 'Shape_Maximum3DDiameter (+)'),
    ('DCE_H', 'DCE Habitat_H', '107', '1', 'Shape_Sphericity (−)'),
    ('M0_all', 'Clinical (11 variables)', '11', '3', 'NAC (+); N stage (+); ALN (+)'),
    ('M0_sel', 'Clinical (6 prespecified)', '6', '3', 'NAC (+); N stage (+); ALN (+)'),
    ('M1', 'DWI WT + Clinical', '118', '3', 'NAC (+); N stage (+); ALN (+)'),
    ('M2a', 'DWI L + Clinical', '118', '3', 'NAC (+); N stage (+); ALN (+)'),
    ('M2b', 'DWI M + Clinical', '118', '3', 'NAC (+); N stage (+); ALN (+)'),
    ('M2c', 'DWI H + Clinical', '118', '2', 'NAC (+); N stage (+)'),
    ('M3', 'DCE WT + Clinical', '118', '3', 'NAC (+); N stage (+); ALN (+)'),
    ('M4a', 'DCE L + Clinical', '118', '3', 'NAC (+); N stage (+); ALN (+)'),
    ('M4b', 'DCE M + Clinical', '118', '3', 'NAC (+); N stage (+); ALN (+)'),
    ('M4c', 'DCE H + Clinical', '118', '7', 'NAC (+); N stage (+); Grade (+); proRT (+); ALN (+); Shape_Sphericity (−); Shape_Maximum3DDiameter (+)'),
    ('M5', 'DWI H + DCE H + Clinical', '225', '6', 'NAC (+); N stage (+); ALN (+); Grade (+); Shape_Sphericity (−); Shape_Maximum3DDiameter (+)'),
    ('M6', 'All 6 habitats + Clinical', '867', '6', 'NAC (+); N stage (+); ALN (+); Grade (+); Shape_Sphericity (−); Shape_Maximum3DDiameter (+)'),
    ('M7', 'DWI H + DCE L + Clinical', '225', '2', 'NAC (+); N stage (+)'),
]

table = doc.add_table(rows=1+len(model_data), cols=5)
table.alignment = WD_TABLE_ALIGNMENT.CENTER

def set_cell(cell, text, bold=False, size=Pt(8)):
    cell.text = ''
    p = cell.paragraphs[0]
    run = p.add_run(text)
    run.font.name = 'Times New Roman'; run.font.size = size; run.bold = bold

# Header
for c, t in zip(table.rows[0].cells, ['Model', 'Description', 'N features', 'Selected', 'Selected features (coefficient direction)']):
    set_cell(c, t, bold=True, size=Pt(9))

for i, (name, desc, n_tot, n_sel, feats) in enumerate(model_data):
    row = table.rows[1+i]
    set_cell(row.cells[0], name, bold=True, size=Pt(8.5))
    set_cell(row.cells[1], desc, size=Pt(8))
    set_cell(row.cells[2], n_tot, size=Pt(8.5))
    set_cell(row.cells[3], n_sel, size=Pt(8.5))
    set_cell(row.cells[4], feats, size=Pt(7.5))

# Three-line format
def apply_three(tbl):
    for row in tbl.rows:
        for cell in row.cells:
            tc=cell._tc;tcPr=tc.get_or_add_tcPr()
            for b in tcPr.findall(qn('w:tcBorders')): tcPr.remove(b)
    for c in tbl.rows[0].cells:
        tc=c._tc;tcPr=tc.get_or_add_tcPr()
        tcPr.append(parse_xml(f'<w:tcBorders {nsdecls("w")}><w:top w:val="single" w:sz="12" w:space="0" w:color="000000"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="000000"/></w:tcBorders>'))
    for i in range(1,len(tbl.rows)):
        for c in tbl.rows[i].cells:
            tc=c._tc;tcPr=tc.get_or_add_tcPr()
            tcPr.append(parse_xml(f'<w:tcBorders {nsdecls("w")}><w:bottom w:val="single" w:sz="2" w:space="0" w:color="000000"/></w:tcBorders>'))
    for c in tbl.rows[-1].cells:
        tc=c._tc;tcPr=tc.get_or_add_tcPr()
        tcPr.append(parse_xml(f'<w:tcBorders {nsdecls("w")}><w:bottom w:val="single" w:sz="12" w:space="0" w:color="000000"/></w:tcBorders>'))

apply_three(table)

for row in table.rows:
    row.cells[0].width = Cm(1.8)
    row.cells[1].width = Cm(3.5)
    row.cells[2].width = Cm(1.5)
    row.cells[3].width = Cm(1.2)
    row.cells[4].width = Cm(10)

p3 = doc.add_paragraph()
r3 = p3.add_run('Abbreviations: GLCM, Gray Level Co-occurrence Matrix; GLRLM, Gray Level Run Length Matrix; GLSZM, Gray Level Size Zone Matrix; GLDM, Gray Level Dependence Matrix; NGTDM, Neighboring Gray Tone Difference Matrix; WT, whole tumor; L, low-signal habitat; M, medium-signal habitat; H, high-signal habitat. Clinical variables: NAC (neoadjuvant chemotherapy), N (lymph node status), ALN (axillary lymph node dissection), Grade (histological grade), proRT (postoperative radiotherapy). Imaging feature prefix: Shape_ (morphological), GLCM_ (texture), GLRLM_ (run-length), GLSZM_ (size-zone), GLDM_ (dependence), NGTDM_ (neighborhood gray-tone).')
r3.font.size = Pt(7.5); r3.font.name = 'Times New Roman'; r3.italic = True

doc.save('<PROJECT_ROOT>/文章撰写/Supp_TableS3_LASSO_Features.docx')
print('✅ Supp_TableS3_LASSO_Features.docx')
