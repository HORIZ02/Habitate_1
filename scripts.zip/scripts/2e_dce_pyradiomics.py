#!/usr/bin/env python3
"""DCE PyRadiomics 3D特征提取"""
import numpy as np, nibabel as nib, os, glob, pandas as pd, warnings
import SimpleITK as sitk
from radiomics import featureextractor, setVerbosity
warnings.filterwarnings('ignore')
setVerbosity(40)

MRI_ROOT = '<PROJECT_ROOT>/使用数据/MRI数据'
MASK_ROOT = '<PROJECT_ROOT>/data/dce_habitat_masks'
mapping = pd.read_csv('<PROJECT_ROOT>/data/file_mapping.csv')
OUT = '<PROJECT_ROOT>/data/features/dce_pyradiomics.csv'

params = {'normalize': True, 'normalizeScale': 100, 'binWidth': 25, 'label': 1, 'force2D': False, 'minimumROISize': 10}
ext = featureextractor.RadiomicsFeatureExtractor(**params)
ext.enableAllFeatures()
print(f'PyRadiomics ready: {list(ext.enabledFeatures.keys())}', flush=True)

def load_sitk(path, dtype=np.float64):
    nii = nib.load(path)
    si = sitk.GetImageFromArray(np.asanyarray(nii.dataobj).astype(dtype))
    z = nii.header.get_zooms()[:3]
    si.SetSpacing([float(z[2]), float(z[1]), float(z[0])])
    return si

def find_dce_mask(row):
    """查找DCE mask，兼容masks和labels目录"""
    dce_path = row['DCE_path']
    if not dce_path or dce_path == 'nan': return None
    center = dce_path.split('/')[0]
    stem = os.path.basename(dce_path).replace('.nii.gz','').upper().replace('P3','')
    
    for subdir in ['masks', 'labels']:
        md = f'{MRI_ROOT}/{center}/DCE/{subdir}'
        if os.path.isdir(md):
            for f in os.listdir(md):
                fs = f.upper().replace('LABEL','').replace('P3','').replace('.NII.GZ','')
                if fs == stem:
                    return load_sitk(os.path.join(md, f), np.int32)
    return None

all_records = []
case_list = sorted([d for d in os.listdir(MASK_ROOT) if os.path.isdir(os.path.join(MASK_ROOT, d))])

for idx, case_no in enumerate(case_list):
    row = mapping[mapping['Case_No.']==case_no]
    if len(row)==0: continue
    row = row.iloc[0]
    
    try:
        img = load_sitk(f'{MRI_ROOT}/{row["DCE_path"]}')
    except:
        print(f'  [{idx+1}] {case_no}: load fail', flush=True)
        continue
    
    # Habitats
    for hf in sorted(glob.glob(os.path.join(MASK_ROOT, case_no, 'habitat_*.nii.gz'))):
        if 'habitat_all' in hf: continue
        hname = os.path.basename(hf).replace('.nii.gz','')
        try:
            mask = load_sitk(hf, np.int32)
            arr_m = sitk.GetArrayFromImage(mask)
            if np.sum(arr_m > 0) < 10: continue
            result = ext.execute(img, mask)
            rec = {'Case_No.':case_no,'Habitat':hname}
            for k,v in result.items():
                if 'diagnostics' not in k:
                    try: rec[k] = float(v)
                    except: pass
            all_records.append(rec)
        except:
            pass
    
    if (idx+1) % 10 == 0 or idx == 0:
        print(f'[{idx+1}/{len(case_list)}] {case_no}: {len(all_records)} recs', flush=True)

if all_records:
    df = pd.DataFrame(all_records)
    df.to_csv(OUT, index=False, encoding='utf-8-sig')
    n_feats = len([c for c in df.columns if c not in ['Case_No.','Habitat']])
    print(f'\n完成! {len(df)}条, {n_feats}特征, {df["Case_No."].nunique()}例')
    print(f'各类: {df["Habitat"].value_counts().to_string()}')
