# -*- coding: utf-8 -*-
"""202: 修正K敏感性 + OOF生存概率→ Brier/DCA/NRI-IDI/校准 + 正规optimism"""
import os, json, warnings
import numpy as np, pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold
from sksurv.linear_model import CoxnetSurvivalAnalysis
from sksurv.metrics import concordance_index_censored, cumulative_dynamic_auc, brier_score
warnings.filterwarnings('ignore')
BASE=r'<PROJECT_ROOT>'; OUT=os.path.join(BASE,'results','models')
ALPHAS=np.logspace(-1.5,0,20); CLIN=['NAC','N','Age','Grade','T','ALN','proRT','ER','PR','Her2','Meno']; SEED=42
R={}
def surv(df): return np.array([(bool(e),float(t)) for e,t in zip(df['DFS'],df['Time'])],dtype=[('event','bool'),('time','float')])
def fit_alpha(Xtr,ytr):
    s=StandardScaler(); Xs=s.fit_transform(Xtr); sc={a:[] for a in ALPHAS}
    for tr,te in KFold(5,shuffle=True,random_state=SEED).split(Xs):
        si=StandardScaler(); Xi=si.fit_transform(Xs[tr]); Xv=si.transform(Xs[te])
        try:
            c=CoxnetSurvivalAnalysis(l1_ratio=1,alphas=ALPHAS,max_iter=10000).fit(Xi,ytr[tr])
            for a in ALPHAS:
                try: sc[a].append(concordance_index_censored(ytr['event'][te],ytr['time'][te],c.predict(Xv,alpha=a))[0])
                except: sc[a].append(.5)
        except:
            for a in ALPHAS: sc[a].append(.5)
    return max(sc,key=lambda a:np.mean(sc[a]))
def oof_surv(X,y,times):
    Xv=X.values; n=len(Xv); S=np.full((n,len(times)),np.nan)
    for tr,te in KFold(5,shuffle=True,random_state=SEED).split(Xv):
        s=StandardScaler(); Xtr=s.fit_transform(Xv[tr]); Xte=s.transform(Xv[te])
        a=fit_alpha(Xv[tr],y[tr])
        c=CoxnetSurvivalAnalysis(l1_ratio=1,alphas=[a],max_iter=10000,fit_baseline_model=True).fit(Xtr,y[tr])
        sf=c.predict_survival_function(Xte)
        # sf 为 StepFunction 数组；在每个 times 处求值
        Sfold=np.array([[float(fn(t)) for t in times] for fn in sf])
        S[te]=Sfold
    return S
clin=pd.read_csv(r'<DATA_ROOT>\分析结果\merged_data_corrected.csv',encoding='utf-8-sig')
clin['Case_No.']=clin['Case_No.'].astype(str); order=clin['Case_No.']
y=surv(clin); ev=y['event'].astype(bool); tm=y['time'].astype(float)
C=clin[CLIN].reset_index(drop=True); M0=C.fillna(0).astype(float)
rad=pd.read_csv(os.path.join(BASE,'data','features','dce_pyradiomics_k3.csv')); rad['Case_No.']=rad['Case_No.'].astype(str)
radH=rad[rad.Habitat=='habitat_H'].drop_duplicates('Case_No.').set_index('Case_No.')
rf=[c for c in radH.columns if c not in ('Case_No.','Habitat')]
M4c=pd.concat([C,radH[rf].loc[order].reset_index(drop=True).add_prefix('DCEH_')],axis=1).fillna(0).astype(float)

# ---- K 敏感性：取每例最高信号生境 ----
print('=== K 敏感性(K=2,3,4,最高信号生境) ===')
R['K']={}
for k in [2,3,4]:
    f=os.path.join(BASE,'data','features',f'k{k}_dce_pyradiomics.csv')
    dk=pd.read_csv(f); dk['Case_No.']=dk['Case_No.'].astype(str)
    feat=[c for c in dk.columns if c.startswith('original_')]
    # 每例选 mean_signal 最大的生境
    dk=dk.sort_values(['Case_No.','mean_signal'])
    top=dk.groupby('Case_No.').tail(1).set_index('Case_No.')[feat]
    top=top.loc[order].reset_index(drop=True)
    X=pd.concat([C,top.add_prefix(f'K{k}H_')],axis=1).fillna(0).astype(float)
    oof=np.full(len(X),np.nan)
    for tr,te in KFold(5,shuffle=True,random_state=SEED).split(X.values):
        s=StandardScaler(); Xtr=s.fit_transform(X.values[tr]); Xte=s.transform(X.values[te])
        a=fit_alpha(X.values[tr],y[tr])
        c=CoxnetSurvivalAnalysis(l1_ratio=1,alphas=[a],max_iter=10000).fit(Xtr,y[tr]); oof[te]=c.predict(Xte)
    R['K'][k]=round(float(concordance_index_censored(ev,tm,oof)[0]),4)
    print(f'K={k}: C={R["K"][k]}')

# ---- OOF 生存概率 → Brier/DCA/NRI-IDI/校准 ----
print('\n=== OOF生存 60月: Brier/DCA/NRI-IDI/校准 ===')
times=[36,60]
S0=oof_surv(M0,y,times); S4=oof_surv(M4c,y,times)
b0=brier_score(y,y,S0[:,[1]],[60])[1][0]; b4=brier_score(y,y,S4[:,[1]],[60])[1][0]
R['brier60']=dict(M0=round(float(b0),4),M4c=round(float(b4),4))
print('Brier60: M0=%.4f M4c=%.4f'%(b0,b4))
# 60月预测事件概率
p0=1-S0[:,1]; p4=1-S4[:,1]
# NRI (continuous) at 60m
def nri(p_new,p_old,ev):
    up=p_new>p_old; down=p_new<p_old
    evn=ev.astype(bool)
    nri_e=(up[evn].mean()-down[evn].mean()) if evn.sum() else 0
    nri_ne=(down[~evn].mean()-up[~evn].mean()) if (~evn).sum() else 0
    return float(nri_e+nri_ne),float(nri_e),float(nri_ne)
R['NRI_60']=nri(p4,p0,ev); print('NRI(60m) total,event,non=',[round(x,3) for x in R['NRI_60']])
# IDI
def idi(p_new,p_old,ev):
    evn=ev.astype(bool)
    return float((p_new[evn].mean()-p_old[evn].mean())-(p_new[~evn].mean()-p_old[~evn].mean())),\
           float(p_new[evn].mean()-p_old[evn].mean()),float(p_new[~evn].mean()-p_old[~evn].mean())
R['IDI_60']=idi(p4,p0,ev); print('IDI(60m) total,event,non=',[round(x,4) for x in R['IDI_60']])
# 校准(60m): logistic of event on logit(pred) → slope, intercept
from sklearn.linear_model import LogisticRegression
eps=1e-6; lp=np.log(np.clip(p4,eps,1-eps)/(1-np.clip(p4,eps,1-eps))).reshape(-1,1)
# 仅用未见删失近似(简化)：用事件状态
try:
    lr=LogisticRegression(C=1e6,max_iter=1000).fit(lp,ev.astype(int))
    R['calib60']=dict(slope=round(float(lr.coef_[0][0]),3),intercept=round(float(lr.intercept_[0]),3))
    print('校准(60m) slope/intercept:',R['calib60'])
except Exception as e: print('calib err',e)
# DCA at 36m (net benefit), 用KM处理删失(简化:用IPCW近似)
def km_event_prob(t): 
    from lifelines import KaplanMeierFitter
    kmf=KaplanMeierFitter().fit(tm,ev); return 1-float(kmf.predict(t))
def dca(p,ev,tm,horizon,ths):
    # 简化: 用horizon内是否发生事件 + 删失前已知
    ybin=np.where((ev)&(tm<=horizon),1,np.where(tm>=horizon,0,-1))
    valid=ybin>=0
    out={}
    prev=(ybin[valid]==1).mean()
    for th in ths:
        treat=p>=th; treat=treat&valid
        if treat.sum()==0: out[th]=0.0; continue
        tp=((ybin==1)&treat).sum()/valid.sum()
        fp=((ybin==0)&treat).sum()/valid.sum()
        nb=tp-fp*th/(1-th)
        out[round(th,2)]=round(float(nb),3)
    return out,round(float(prev),3)
d0,prev=dca(p0,ev,tm,36,[0.1,0.2,0.3,0.4,0.5]); d4,_=dca(p4,ev,tm,36,[0.1,0.2,0.3,0.4,0.5])
R['DCA36']=dict(prevalence=prev,M0=d0,M4c=d4); print('DCA36 prevalence=%s'%prev); print('  M4c:',d4)

# ---- 正规 optimism (Harrell) M4c ----
print('\n=== optimism bootstrap(M4c) ===')
rng=np.random.default_rng(SEED); opts=[]
for b in range(100):
    i=rng.integers(0,len(ev),len(ev))
    if ev[i].sum()<10: continue
    try:
        a=fit_alpha(M4c.values[i],y[i])
        s=StandardScaler(); Xb=s.fit_transform(M4c.values[i])
        c=CoxnetSurvivalAnalysis(l1_ratio=1,alphas=[a],max_iter=10000).fit(Xb,y[i])
        app=concordance_index_censored(y['event'][i],y['time'][i],c.predict(Xb))[0]  # on boot sample
        # test on original (excluding? use original all)
        Xo=s.transform(M4c.values); test=concordance_index_censored(ev,tm,c.predict(Xo))[0]
        opts.append(app-test)
    except: pass
R['optimism']=round(float(np.mean(opts)),4) if opts else None
print('optimism mean:',R['optimism'])

json.dump(R,open(os.path.join(OUT,'REVISION_ANALYSES2.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=2)
print('\n✅ saved REVISION_ANALYSES2.json')
