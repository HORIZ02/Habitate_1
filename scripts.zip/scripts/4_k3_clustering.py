#!/usr/bin/env python3
"""
固定K=3聚类 + 按信号强度重标号
DWI和DCE分别跑，支持断点续跑
输出：habitat_L.nii.gz, habitat_M.nii.gz, habitat_H.nii.gz
"""
import numpy as np, nibabel as nib, os, glob, pandas as pd, warnings
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
warnings.filterwarnings('ignore')

RANDOM_STATE = 42
MRI_ROOT = "<PROJECT_ROOT>/使用数据/MRI数据"
OUTPUT_DIR = "<PROJECT_ROOT>/data"

# ====== 参数 ======
import argparse
parser = argparse.ArgumentParser()
parser.add_argument('--mode', choices=['dwi','dce'], required=True)
args = parser.parse_args()
MODE = args.mode.upper()

if MODE == 'DWI':
    MASK_ROOT = os.path.join(OUTPUT_DIR, "dwi_habitat_masks_k3")
    CSV_OUT = os.path.join(OUTPUT_DIR, "dwi_cluster_info_k3.csv")
    mapping = pd.read_csv(os.path.join(OUTPUT_DIR, "file_mapping.csv"))
else:
    MASK_ROOT = os.path.join(OUTPUT_DIR, "dce_habitat_masks_k3")
    CSV_OUT = os.path.join(OUTPUT_DIR, "dce_cluster_info_k3.csv")
    mapping = pd.read_csv(os.path.join(OUTPUT_DIR, "dce_file_mapping.csv"))

os.makedirs(MASK_ROOT, exist_ok=True)

# ====== 函数 ======
def load_nifti(path):
    full = path if os.path.isabs(path) else os.path.join(MRI_ROOT, path)
    if not os.path.exists(full):
        return None, None
    try:
        nii = nib.load(full)
        arr = np.asanyarray(nii.dataobj).astype(np.float64)
        return arr, nii
    except:
        return None, None

def extract_voxel_features(img_arr, mask_arr, mode='DWI'):
    """提取voxel-wise特征"""
    mask_bin = mask_arr > 0
    indices = np.array(np.where(mask_bin)).T  # (z, y, x)
    if len(indices) < 10:
        return None, None
    
    feats = []
    for z, y, x in indices:
        v = img_arr[z, y, x]
        if mode == 'DWI':
            # DWI: signal + local entropy + local variance
            zs, ys, xs = max(0,z-1), max(0,y-1), max(0,x-1)
            ze, ye, xe = min(img_arr.shape[0],z+2), min(img_arr.shape[1],y+2), min(img_arr.shape[2],x+2)
            patch = img_arr[zs:ze, ys:ye, xs:xe]
            feats.append([v, np.mean(patch), np.std(patch),
                          -np.sum((patch/255)*(np.log(patch/255+1e-10))) if patch.size > 0 else 0])
        else:
            # DCE: signal + local mean + local std
            zs, ys, xs = max(0,z-1), max(0,y-1), max(0,x-1)
            ze, ye, xe = min(img_arr.shape[0],z+2), min(img_arr.shape[1],y+2), min(img_arr.shape[2],x+2)
            patch = img_arr[zs:ze, ys:ye, xs:xe]
            feats.append([v, np.mean(patch), np.std(patch)])
    
    return np.array(feats, dtype=np.float64), indices

def save_habitats(labels, indices, img_info, case_no, mean_signals):
    """
    按信号强度重标号: L(最低), M(中), H(最高)
    """
    # 按平均信号排序
    order = np.argsort(mean_signals)  # 0=最低, 2=最高
    label_map = {old: new for old, new in zip(order, ['L','M','H'])}
    
    case_dir = os.path.join(MASK_ROOT, case_no)
    os.makedirs(case_dir, exist_ok=True)
    os.makedirs(os.path.join(case_dir, 'masks'), exist_ok=True)
    
    shape_3d = img_info['shape'][:3] if len(img_info['shape']) >= 3 else img_info['shape']
    full_mask = np.zeros(shape_3d, dtype=np.int32)
    for i, (z, y, x) in enumerate(indices):
        full_mask[z, y, x] = labels[i] + 1
    
    # habitat_all（原始标签）
    all_nii = nib.Nifti1Image(full_mask, img_info['affine'], img_info['header'])
    nib.save(all_nii, os.path.join(case_dir, "habitat_all.nii.gz"))
    
    for k in range(3):
        single = (full_mask == (k + 1)).astype(np.int32)
        name = label_map[k]
        nii = nib.Nifti1Image(single, img_info['affine'], img_info['header'])
        nib.save(nii, os.path.join(case_dir, f"habitat_{name}.nii.gz"))
    
    return label_map

# ====== 主流程 ======
results = []
completed = set()
for d in os.listdir(MASK_ROOT):
    cd = os.path.join(MASK_ROOT, d)
    if os.path.isdir(cd) and os.path.exists(os.path.join(cd, "habitat_all.nii.gz")):
        completed.add(d)

if completed:
    print(f"已有 {len(completed)} 例跳过")

for idx, row in mapping.iterrows():
    case_no = row['Case_No.']
    name = row['Name']
    
    if case_no in completed:
        print(f"[{idx+1}/{len(mapping)}] {case_no} ⏭")
        continue
    
    print(f"\n[{idx+1}/{len(mapping)}] {case_no} {name}")
    
    # 加载图像
    if MODE == 'DWI':
        img_path = row['DWI_path']
    else:
        img_path = row['DCE_path']
    
    img_arr, img_nii = load_nifti(img_path)
    if img_arr is None:
        print(f"  ⚠ 文件缺失: {img_path}")
        continue
    
    # 找mask
    center = img_path.split('/')[0]
    if MODE == 'DWI':
        mask_search = f"{center}/DWI/masks"
        fname = os.path.basename(img_path)
    else:
        mask_search = f"{center}/DCE/masks"
        fname = os.path.basename(img_path)
    
    mask_file = None
    full_mp = os.path.join(MRI_ROOT, mask_search)
    if os.path.isdir(full_mp):
        for f in os.listdir(full_mp):
            if f.endswith('.nii.gz'):
                f_s = f.replace('.nii.gz','').upper().replace('LABEL','').replace('DWI','').replace('DCE','')
                i_s = fname.replace('.nii.gz','').upper().replace('DWI','').replace('DCE','')
                if f_s == i_s or f_s.replace('_','') == i_s or f_s == i_s.replace('_',''):
                    mask_file = f
                    break
    
    if mask_file is None:
        print(f"  ⚠ Mask未找到")
        continue
    
    mask_arr, _ = load_nifti(f"{mask_search}/{mask_file}")
    if mask_arr is None:
        print(f"  ⚠ Mask加载失败")
        continue
    
    print(f"  Mask: {mask_search}/{mask_file}")
    
    # 提取voxel特征
    features, indices = extract_voxel_features(img_arr, mask_arr, MODE)
    if features is None or len(features) < 10:
        print(f"  ⚠ 体素太少: {0 if features is None else len(features)}")
        continue
    
    print(f"  Voxels: {len(features)}, 特征维: {features.shape[1]}")
    
    # 标准化 + PCA
    features = np.nan_to_num(features, nan=0.0, posinf=0.0, neginf=0.0)
    fs = StandardScaler().fit_transform(features)
    fp = PCA(n_components=0.95, random_state=RANDOM_STATE).fit_transform(fs)
    print(f"  PCA: {features.shape[1]}→{fp.shape[1]}D")
    
    # K-means, K=3固定
    labels = KMeans(n_clusters=3, random_state=RANDOM_STATE, n_init=10).fit_predict(fp)
    counts = np.bincount(labels, minlength=3)
    print(f"  Habitats: {counts}")
    
    # 计算各cluster的信号均值 → 重标号
    mean_signals = []
    for k in range(3):
        idx_k = np.where(labels == k)[0]
        mean_signal = np.mean(features[idx_k, 0])  # 第0列是原始信号
        mean_signals.append(mean_signal)
    
    img_info = {'shape': img_arr.shape, 'affine': img_nii.affine, 'header': img_nii.header}
    label_map = save_habitats(labels, indices, img_info, case_no, mean_signals)
    
    print(f"  重标号: 信号最低={label_map[0]}, 中={label_map[1]}, 最高={label_map[2]}")
    print(f"  均值信号: {[f'{s:.1f}' for s in mean_signals]}")
    
    results.append({
        'Case_No.': case_no, 'Name': name,
        'K': 3,
        'Voxels': len(features),
        'Habitat_L_voxels': counts[np.argsort(mean_signals)[0]],
        'Habitat_M_voxels': counts[np.argsort(mean_signals)[1]],
        'Habitat_H_voxels': counts[np.argsort(mean_signals)[2]],
        'Habitat_L_signal': mean_signals[np.argsort(mean_signals)[0]],
        'Habitat_M_signal': mean_signals[np.argsort(mean_signals)[1]],
        'Habitat_H_signal': mean_signals[np.argsort(mean_signals)[2]],
    })
    
    pd.DataFrame(results).to_csv(CSV_OUT, index=False, encoding='utf-8-sig')

if results:
    df_r = pd.DataFrame(results)
    df_r.to_csv(CSV_OUT, index=False, encoding='utf-8-sig')
    print(f"\n✅ 完成! 共{len(df_r)}例")
    print(f"结果: {CSV_OUT}")
    print(f"Masks: {MASK_ROOT}")
else:
    print("已完成所有病例")
