#!/usr/bin/env python3
"""优化KM生存曲线：无网格、图例左下无框、P值纯文本、风险表、600DPI"""
import pandas as pd, numpy as np, os, warnings
warnings.filterwarnings('ignore')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from lifelines import KaplanMeierFitter
from lifelines.statistics import multivariate_logrank_test
from sklearn.preprocessing import StandardScaler
from sksurv.linear_model import CoxnetSurvivalAnalysis
plt.rcParams.update({
    'font.family':'Times New Roman',
    'font.size':12,
    'axes.facecolor':'white',
    'figure.facecolor':'white',
    'axes.grid':False,  # 无网格
})

OUT="<PROJECT_ROOT>/results/figures"
DPI=600

# ===== 数据准备 =====
clin=pd.read_csv('<DATA_ROOT>/分析结果/merged_data_corrected.csv')
dwi=pd.read_csv('<PROJECT_ROOT>/data/features/dwi_pyradiomics_k3.csv')
dce=pd.read_csv('<PROJECT_ROOT>/data/features/dce_pyradiomics_k3.csv')
feats=[c for c in dwi.columns if c not in ['Case_No.','Habitat']]
def get_hab(df,hab):return df[df['Habitat']==hab][['Case_No.']+feats].drop_duplicates('Case_No.').set_index('Case_No.')

# Compute risk scores for M0, M2b, M4c
models={
    'M0 (Clinical)':clin[['NAC','N','Age','Grade','T','ALN','proRT','ER','PR','Her2','Meno']],
    'M2b (DWI M+Clinical)':pd.concat([clin[['NAC','N','Age','Grade','T','ALN','proRT','ER','PR','Her2','Meno']],
                                       get_hab(dwi,'habitat_M').loc[clin['Case_No.']].reset_index(drop=True)],axis=1),
    'M4c (DCE H+Clinical)':pd.concat([clin[['NAC','N','Age','Grade','T','ALN','proRT','ER','PR','Her2','Meno']],
                                       get_hab(dce,'habitat_H').loc[clin['Case_No.']].reset_index(drop=True)],axis=1),
}

y_arr=np.array([(bool(e),t) for e,t in zip(clin['DFS'],clin['Time'])],dtype=[('event','bool'),('time','float')])
colors=['#4472C4','#ED7D31','#70AD47']
labels=['M0 (Clinical)','M2b (DWI M+Clinical)','M4c (DCE H+Clinical)']

risk_scores={}
for mn,X in models.items():
    s=StandardScaler();Xs=s.fit_transform(X)
    cph=CoxnetSurvivalAnalysis(l1_ratio=1,alphas=[0.1],max_iter=10000).fit(Xs,y_arr)
    risk_scores[mn]=cph.predict(Xs).flatten()

# ===== 绘制KM曲线（3模型，曲线上+风险表下） =====
fig,axes=plt.subplots(6,1,figsize=(10,14),
                       gridspec_kw={'height_ratios':[3,1,3,1,3,1],'hspace':0.30})

for mi,(mn,label) in enumerate(zip(['M0 (Clinical)','M2b (DWI M+Clinical)','M4c (DCE H+Clinical)'],
                                     ['M0 (Clinical)','M2b (DWI M+Clinical)','M4c (DCE H+Clinical)'])):
    ax=axes[mi*2]  # 曲线子图
    ax_t=axes[mi*2+1]  # 风险表子图
    rs=risk_scores[mn]
    med=np.median(rs)
    groups=['Low Risk' if r<=med else 'High Risk' for r in rs]
    
    # 计算KM
    kmf_low=KaplanMeierFitter()
    kmf_high=KaplanMeierFitter()
    
    low_mask=np.array(groups)=='Low Risk'
    high_mask=np.array(groups)=='High Risk'
    
    times_low=clin['Time'][low_mask].values
    events_low=clin['DFS'][low_mask].values
    times_high=clin['Time'][high_mask].values
    events_high=clin['DFS'][high_mask].values
    
    kmf_low.fit(times_low,event_observed=events_low,label='Low Risk')
    kmf_high.fit(times_high,event_observed=events_high,label='High Risk')
    
    # 画曲线
    ax.step(kmf_low.timeline,kmf_low.survival_function_.values,where='post',
            color='#2166AC',linewidth=1.8,label='Low Risk')
    # CI band
    ci_low=kmf_low.confidence_interval_.values[:,0]
    ci_high=kmf_low.confidence_interval_survival_function_.values[:,1] if hasattr(kmf_low,'confidence_interval_survival_function_') else kmf_low.confidence_interval_.values[:,1]
    ax.fill_between(kmf_low.timeline,ci_low,ci_high,alpha=0.10,color='#2166AC')
    
    ax.step(kmf_high.timeline,kmf_high.survival_function_.values,where='post',
            color='#E41A1C',linewidth=1.8,label='High Risk')
    ci_low_h=kmf_high.confidence_interval_.values[:,0]
    ci_high_h=kmf_high.confidence_interval_survival_function_.values[:,1] if hasattr(kmf_high,'confidence_interval_survival_function_') else kmf_high.confidence_interval_.values[:,1]
    ax.fill_between(kmf_high.timeline,ci_low_h,ci_high_h,alpha=0.10,color='#E41A1C')
    
    # censor markers
    censor_t=times_low[events_low<0.5]  # actually we want censor events (DFS=0)
    # Simpler: don't add censor markers (they're rarely shown in medical papers)
    
    # X轴
    ax.set_xlim(0,clin['Time'].max()+6)
    ax.set_xlabel('Time (months)' if mi==2 else '',fontsize=13)
    ticks=np.arange(0,clin['Time'].max()+12,12)
    ax.set_xticks(ticks)
    ax.set_xticklabels([f'{int(t)}m' for t in ticks],fontsize=11)
    
    # Y轴
    ax.set_ylim(0,1.02)
    ax.set_ylabel('Disease-Free Survival',fontsize=13)
    ax.tick_params(labelsize=11)
    
    # 无网格、隐藏上右框线
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    
    # 标题
    ax.set_title(label,fontsize=14,fontweight='bold')
    
    # 图例（左下、无框）
    legend=ax.legend(loc='lower left',frameon=False,fontsize=11)
    
    # P值（纯文本，无框，在图例右侧）
    from lifelines.statistics import logrank_test
    lr=logrank_test(clin['Time'][low_mask],clin['Time'][high_mask],
                   event_observed_A=clin['DFS'][low_mask],
                   event_observed_B=clin['DFS'][high_mask])
    pv=lr.p_value
    p_text=f'P = {pv:.4e}' if pv<0.0001 else f'P = {pv:.4f}'
    # 在图例右侧放置P值
    ax.text(0.45,0.18,p_text,transform=ax.transAxes,fontsize=11,
            va='bottom',ha='left',fontweight='normal')
    # ===== 风险表（下方子图） =====
    ax_t.axis('off')
    
    # 构建风险表数据
    time_points=np.arange(0,clin['Time'].max()+12,12)
    n_low=[]
    n_high=[]
    for tp in time_points:
        n_low.append(np.sum((clin['Time']>=tp)&low_mask))
        n_high.append(np.sum((clin['Time']>=tp)&high_mask))
    
    col_labels=['']+[f'{int(t)}m' for t in time_points]
    cell_text=[
        ['Low Risk']+[str(n) for n in n_low],
        ['High Risk']+[str(n) for n in n_high],
    ]
    
    table=ax_t.table(cellText=cell_text,colLabels=col_labels,
                     cellLoc='center',loc='center',
                     bbox=[0,0.2,1,0.6])
    table.auto_set_font_size(False)
    table.set_fontsize(9)
    
    # 表头
    for j in range(len(col_labels)):
        cell=table[0,j]
        cell.set_text_props(weight='bold',fontsize=9,color='black')
        cell.set_facecolor('#F2F2F2')
        cell.set_edgecolor('#CCCCCC')
    # 数据行
    for i in range(1,3):
        for j in range(len(col_labels)):
            cell=table[i,j]
            cell.set_facecolor('white')
            cell.set_edgecolor('#CCCCCC')
            cell.set_text_props(fontsize=9,color='black')
            if j==0:
                cell.set_text_props(fontsize=9,color={'Low Risk':'#2166AC','High Risk':'#E41A1C'}[cell_text[i-1][0]],ha='left')
    
    # "Number at risk" 标题
    ax_t.text(0.02,0.93,'Number at risk',transform=ax_t.transAxes,
             fontsize=10,va='center',fontweight='bold')

plt.tight_layout()
plt.savefig(os.path.join(OUT,'Fig_KM_curves_opt.png'),dpi=DPI,bbox_inches='tight',facecolor='white')
plt.savefig(os.path.join(OUT,'Fig_KM_curves_opt.tiff'),dpi=DPI,bbox_inches='tight',facecolor='white')
plt.savefig(os.path.join(OUT,'Fig_KM_curves_opt.jpg'),dpi=DPI,bbox_inches='tight',facecolor='white')
print('✅ KM curves optimized')
