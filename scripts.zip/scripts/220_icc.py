# -*- coding: utf-8 -*-
"""
220_icc.py — 两位放射科医师勾画的 ICC（DCE P3：habitat_H + 全肿瘤）
复现论文 DCE 聚类：信号强度 K-means K=3，habitat_H=最高平均信号簇
使用 PyRadiomics 提取 Sphericity / Maximum3DDiameter / MeshVolume
"""
import os, glob, warnings
import numpy as np, pandas as pd, nibabel as nib
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import SimpleITK as sitk
from radiomics import featureextractor, setVerbosity
warnings.filterwarnings('ignore'); setVerbosity(40)

BASE=r'<PROJECT_ROOT>\ICC'
R1=os.path.join(BASE,'radiologist1'); R2=os.path.join(BASE,'radiologist2')
K=3; SEED=42
ext=featureextractor.RadiomicsFeatureExtractor(force2D=False, minimumROISize=10)
ext.disableAllFeatures(); ext.enableFeatureClassByName('shape')

def hab_H_mask(img_path, mask_path):
    ni=nib.load(img_path); arr=np.asanyarray(ni.dataobj,dtype=np.float32)
    nm=nib.load(mask_path); m=np.asanyarray(nm.dataobj)
    if m.shape!=arr.shape:
        # 尝试转置对齐(极少情况)
        pass
    roi=m>0
    if roi.sum()<50: return None,None,None
    vals=arr[roi].reshape(-1,1)
    z=StandardScaler().fit_transform(vals)
    lab=KMeans(n_clusters=K,random_state=SEED,n_init=10).fit_predict(z)
    means=[vals[lab==k].mean() for k in range(K)]
    hk=int(np.argmax(means))
    hmask=np.zeros_like(m,dtype=np.uint8)
    idx=np.where(roi)
    hmask[idx[0][lab==hk],idx[1][lab==hk],idx[2][lab==hk]]=1
    sp=ni.header.get_zooms()[:3]
    return hmask, arr, sp

def shape_feats(mask, arr, sp):
    if mask is None or mask.sum()<10: return None
    im=sitk.GetImageFromArray(arr.astype(np.float32)); im.SetSpacing(tuple(float(x) for x in sp))
    mk=sitk.GetImageFromArray(mask.astype(np.uint8)); mk.SetSpacing(tuple(float(x) for x in sp))
    try:
        r=ext.execute(im, mk)
        return dict(Sphericity=float(r['original_shape_Sphericity']),
                    Max3DDiameter=float(r['original_shape_Maximum3DDiameter']),
                    MeshVolume=float(r['original_shape_MeshVolume']))
    except Exception as e:
        return None

def whole_mask(mask_path):
    m=np.asanyarray(nib.load(mask_path).dataobj)
    return (m>0).astype(np.uint8)

def icc21(y1,y2):
    y=np.column_stack([y1,y2]); n,k=y.shape
    gm=y.mean(); rm=y.mean(1); cm=y.mean(0)
    SSR=k*((rm-gm)**2).sum(); SSC=n*((cm-gm)**2).sum()
    SST=((y-gm)**2).sum(); SSE=SST-SSR-SSC
    MSR=SSR/(n-1); MSC=SSC/(k-1); MSE=SSE/((n-1)*(k-1))
    icc=(MSR-MSE)/(MSR+(k-1)*MSE+(k/n)*(MSC-MSE))
    # bootstrap CI (2000)
    rng=np.random.default_rng(42); bs=[]
    for _ in range(2000):
        i=rng.integers(0,n,n); yy=y[i]
        g=yy.mean(); r=yy.mean(1); c=yy.mean(0)
        A=k*((r-g)**2).sum(); B=n*((c-g)**2).sum(); T=((yy-g)**2).sum(); E=T-A-B
        r1=A/(n-1); c1=B/(k-1); e1=E/((n-1)*(k-1))
        den=r1+(k-1)*e1+(k/n)*(c1-e1)
        if den!=0: bs.append((r1-e1)/den)
    lo,hi=np.percentile(bs,2.5),np.percentile(bs,97.5)
    return icc,float(lo),float(hi)

names=sorted([os.path.basename(p).replace('P3.nii.gz','') for p in glob.glob(os.path.join(R1,'masks','*P3.nii.gz'))])
print('患者数:',len(names))
rows=[]
for nm in names:
    ip1=os.path.join(R1,'images',nm+'P3.nii.gz'); mp1=os.path.join(R1,'masks',nm+'P3.nii.gz')
    ip2=os.path.join(R2,'images',nm+'P3.nii.gz'); mp2=os.path.join(R2,'masks',nm+'P3.nii.gz')
    if not all(os.path.exists(x) for x in [ip1,mp1,ip2,mp2]): 
        print('缺文件',nm); continue
    h1,arr1,sp1=hab_H_mask(ip1,mp1); h2,arr2,sp2=hab_H_mask(ip2,mp2)
    f_h1=shape_feats(h1,arr1,sp1); f_h2=shape_feats(h2,arr2,sp2)
    w1=whole_mask(mp1); w2=whole_mask(mp2)
    f_w1=shape_feats(w1,arr1,sp1); f_w2=shape_feats(w2,arr2,sp2)
    if None in (f_h1,f_h2,f_w1,f_w2):
        print('提取失败',nm); continue
    row=dict(Patient=nm)
    for key in ['Sphericity','Max3DDiameter','MeshVolume']:
        row[f'H_{key}_r1']=f_h1[key]; row[f'H_{key}_r2']=f_h2[key]
        row[f'W_{key}_r1']=f_w1[key]; row[f'W_{key}_r2']=f_w2[key]
    dw=2*np.logical_and(w1>0,w2>0).sum()/max(1,(w1>0).sum()+(w2>0).sum())
    dh=2*np.logical_and(h1>0,h2>0).sum()/max(1,(h1>0).sum()+(h2>0).sum()) if (h1 is not None and h2 is not None) else np.nan
    row['Dice_W']=dw; row['Dice_H']=dh
    rows.append(row)
    print('✔',nm, f'Dice_W={dw:.3f} Dice_H={dh:.3f}')

df=pd.DataFrame(rows)
out=r'<PROJECT_ROOT>\results\models\icc_features.csv'
df.to_csv(out,index=False,encoding='utf-8-sig')
print('\n有效例数:',len(df))
print('Mean Dice — whole-tumor: %.3f | DCE_H: %.3f'%(df['Dice_W'].mean(), df['Dice_H'].mean()))

print('\n===== ICC(2,1) 结果 =====')
res=[]
for feat in ['Sphericity','Max3DDiameter','MeshVolume']:
    for scope,lab in [('W','Whole-tumor'),('H','DCE_H')]:
        y1=df[f'{scope}_{feat}_r1'].values; y2=df[f'{scope}_{feat}_r2'].values
        icc,l,u=icc21(y1,y2)
        res.append(dict(Feature=feat,Scope=lab,ICC=round(icc,3),CI_low=round(l,3),CI_high=round(u,3),
                        n=len(y1)))
        print(f'{lab:12s} {feat:15s} ICC={icc:.3f} (95%CI {l:.3f}–{u:.3f})')
pd.DataFrame(res).to_csv(r'<PROJECT_ROOT>\results\models\ICC_results.csv',index=False,encoding='utf-8-sig')
print('\n✅ saved ICC_results.csv & icc_features.csv')
