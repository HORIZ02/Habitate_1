# -*- coding: utf-8 -*-
"""
22_univariate_spatial_cox_k3.py  —  第②步：空间结构特征单变量生存筛选（K=3）

对 84 个空间特征（DWI 42 + DCE 42）逐个做单变量 Cox：
  - HR 按 1-SD 标度（z-score），便于跨特征比较
  - Wald P、BH-FDR 校正（84 次检验）
  - 单特征 C-index、中位切分 log-rank P
  - NaN 处理：逐特征可用例分析（listwise），并报告实际 n
    （DWI fractal_dim 缺失约 70%，其 n 会显著偏小，需在解读时注意）

输入：data/features/habitat_spatial_features_k3.csv
      <DATA_ROOT>/分析结果/merged_data_corrected.csv  (Case_No., Time, DFS)
输出：results/models/univariate_spatial_cox_k3.csv
      results/models/univariate_spatial_summary_k3.md
"""
import os, warnings
import numpy as np
import pandas as pd
from lifelines import CoxPHFitter
from lifelines.statistics import logrank_test

warnings.filterwarnings('ignore')

BASE = r'<PROJECT_ROOT>'
FEAT_CSV = os.path.join(BASE, 'data', 'features', 'habitat_spatial_features_k3.csv')
CLIN_CSV = r'<DATA_ROOT>\分析结果\merged_data_corrected.csv'
OUT_DIR = os.path.join(BASE, 'results', 'models')
OUT_CSV = os.path.join(OUT_DIR, 'univariate_spatial_cox_k3.csv')
OUT_MD = os.path.join(OUT_DIR, 'univariate_spatial_summary_k3.md')

os.makedirs(OUT_DIR, exist_ok=True)


def bh_fdr(p):
    p = np.asarray(p, float)
    n = len(p)
    order = np.argsort(p)
    ranked = p[order]
    q = ranked * n / (np.arange(n) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    out = np.empty(n)
    out[order] = np.clip(q, 0, 1)
    return out


def main():
    df = pd.read_csv(FEAT_CSV)
    clin = pd.read_csv(CLIN_CSV, encoding='utf-8-sig')
    clin = clin[['Case_No.', 'Time', 'DFS']].copy()
    clin['Case_No.'] = clin['Case_No.'].astype(str)

    # 长表 → 宽表（Case_No. × 84 特征）
    # 注意：特征名已自带模态前缀（dwi_/dce_），unstack 会再叠加一层 → 必须按模态分别取列拼接
    f_dwi = [c for c in df.columns if c.startswith('dwi_')]
    f_dce = [c for c in df.columns if c.startswith('dce_')]
    a = df[df.modality == 'DWI'].set_index('Case_No.')[f_dwi]
    b = df[df.modality == 'DCE'].set_index('Case_No.')[f_dce]
    wide = pd.concat([a, b], axis=1).reset_index()
    wide['Case_No.'] = wide['Case_No.'].astype(str)

    dat = wide.merge(clin, on='Case_No.', how='inner')
    feats = [c for c in wide.columns if c != 'Case_No.']

    print(f'合并: {len(dat)} 例 (mask {len(wide)} / 临床 {len(clin)})')
    print(f'事件: {int(dat.DFS.sum())}/{len(dat)} ({dat.DFS.mean()*100:.1f}%)')
    print(f'随访: 中位 {dat.Time.median():.0f} 月, IQR [{dat.Time.quantile(.25):.0f},{dat.Time.quantile(.75):.0f}]')
    print(f'特征: {len(feats)}')

    rows = []
    for f in feats:
        sub = dat[[f, 'Time', 'DFS']].dropna()
        n, n_ev = len(sub), int(sub.DFS.sum())
        if n < 30 or n_ev < 10:
            rows.append(dict(feature=f, n=n, n_events=n_ev, note='样本/事件不足'))
            continue
        x = sub[f].astype(float)
        mu, sd = x.mean(), x.std(ddof=1)
        if sd == 0 or not np.isfinite(sd):
            rows.append(dict(feature=f, n=n, n_events=n_ev, note='零方差'))
            continue
        tmp = pd.DataFrame({'x': (x - mu) / sd, 'T': sub.Time, 'E': sub.DFS})
        try:
            cph = CoxPHFitter()
            cph.fit(tmp, duration_col='T', event_col='E')
            s = cph.summary.loc['x']
            hr, lo, hi, p = s['exp(coef)'], s['exp(coef) lower 95%'], s['exp(coef) upper 95%'], s['p']
            cidx = float(cph.concordance_index_)
        except Exception as e:
            rows.append(dict(feature=f, n=n, n_events=n_ev, note=f'Cox失败:{type(e).__name__}'))
            continue
        # 中位切分 log-rank
        med = x.median()
        g = x > med
        try:
            lr = logrank_test(sub.Time[g], sub.Time[~g], sub.DFS[g], sub.DFS[~g])
            lrp = float(lr.p_value)
        except Exception:
            lrp = np.nan
        rows.append(dict(feature=f, n=n, n_events=n_ev,
                         HR_perSD=round(hr, 4), CI_low=round(lo, 4), CI_high=round(hi, 4),
                         P_wald=p, Cindex=round(cidx, 4), P_logrank=lrp,
                         mean=round(mu, 4), sd=round(sd, 4), note=''))

    res = pd.DataFrame(rows)
    ok = res['P_wald'].notna()
    res.loc[ok, 'FDR'] = bh_fdr(res.loc[ok, 'P_wald'].values)
    res = res.sort_values('P_wald', na_position='last').reset_index(drop=True)
    res.to_csv(OUT_CSV, index=False)
    print(f'\n-> {OUT_CSV}  ({len(res)} 行)')

    # ---------- 摘要 ----------
    L = []
    L.append('# 空间结构特征单变量 Cox 筛选（K=3, DWI+DCE）\n')
    L.append(f'> 队列 {len(dat)} 例 / 事件 {int(dat.DFS.sum())} ({dat.DFS.mean()*100:.1f}%) / '
             f'中位随访 {dat.Time.median():.0f} 月')
    L.append(f'> 特征 {len(feats)} 个（DWI 42 + DCE 42），HR 按 1-SD，FDR = BH 校正\n')

    for tag, name in [('dwi', 'DWI'), ('dce', 'DCE'), ('', '全部')]:
        sub = res[res.feature.str.startswith(tag)] if tag else res
        p05 = sub[sub.P_wald < 0.05]
        f05 = sub[sub.FDR < 0.05]
        L.append(f'## {name}：P<0.05 有 {len(p05)}/{len(sub)}，FDR<0.05 有 {len(f05)}\n')

    L.append('## 单变量 P<0.05 的特征（按 P 升序）\n')
    L.append('| 特征 | n | 事件 | HR(1SD) | 95%CI | P | FDR | C-index | log-rank P |')
    L.append('|---|---|---|---|---|---|---|---|---|')
    for _, r in res[res.P_wald < 0.05].iterrows():
        L.append(f"| {r.feature} | {int(r.n)} | {int(r.n_events)} | {r.HR_perSD:.3f} | "
                 f"{r.CI_low:.3f}–{r.CI_high:.3f} | {r.P_wald:.4f} | {r.FDR:.4f} | "
                 f"{r.Cindex:.3f} | {r.P_logrank:.4f} |")
    L.append('')

    L.append('## FDR<0.05 的特征（稳健）\n')
    f05 = res[res.FDR < 0.05]
    if len(f05) == 0:
        L.append('**无** —— 无特征通过多重检验校正，说明目前无单一空间特征具备稳健的独立预后信号。\n')
    else:
        L.append('| 特征 | n | HR(1SD) | 95%CI | P | FDR | C-index |')
        L.append('|---|---|---|---|---|---|---|')
        for _, r in f05.iterrows():
            L.append(f"| {r.feature} | {int(r.n)} | {r.HR_perSD:.3f} | {r.CI_low:.3f}–{r.CI_high:.3f} "
                     f"| {r.P_wald:.4f} | {r.FDR:.4f} | {r.Cindex:.3f} |")
        L.append('')

    L.append('## 退化特征（样本量偏小，解读需谨慎）\n')
    deg = res[res.n < 350]
    if len(deg):
        L.append('| 特征 | 可用 n | 缺失率 | P |')
        L.append('|---|---|---|---|')
        for _, r in deg.iterrows():
            L.append(f"| {r.feature} | {int(r.n)} | {(1-r.n/len(dat))*100:.0f}% | "
                     f"{r.P_wald if pd.notna(r.P_wald) else 'NA'} |")
    else:
        L.append('无（所有特征可用 n ≥ 350）')
    L.append('')

    with open(OUT_MD, 'w', encoding='utf-8') as fh:
        fh.write('\n'.join(L))
    print(f'-> {OUT_MD}')

    # 控制台速览
    print('\n=== P<0.05 特征 ===')
    v = res[res.P_wald < 0.05][['feature', 'n', 'HR_perSD', 'CI_low', 'CI_high', 'P_wald', 'FDR', 'Cindex']]
    print(v.to_string(index=False) if len(v) else '无')
    print(f'\nFDR<0.05: {len(res[res.FDR<0.05])} 个')


if __name__ == '__main__':
    main()
