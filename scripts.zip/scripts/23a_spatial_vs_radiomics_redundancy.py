# -*- coding: utf-8 -*-
"""
23a_spatial_vs_radiomics_redundancy.py  —  第3a步：新空间特征 vs 现有纹理特征的冗余分析

目的：判定 84 个新空间结构特征中，哪些是"真正的新信息"，哪些与现有 PyRadiomics
      107 特征重复（否则建模时"加了特征却没提升"无法解释，审稿人必问增量价值）。

方法：
  - Spearman 秩相关（对单调非线性稳健，逐对完整观测）
  - 对每个空间特征：与全部 radiomics 特征的最大 |ρ| 及对应配对名
  - 判定阈值：|ρ|>=0.9 高度冗余 / 0.8-0.9 中度冗余 / <0.8 视为新增信息
  - 重点核查：新 sphericity vs PyRadiomics original_shape_Sphericity
              新 n_voxels   vs MeshVolume / VoxelVolume
              新 surface    vs SurfaceArea

输入：data/features/habitat_spatial_features_k3.csv
      data/features/{dwi,dce}_pyradiomics_k3.csv
输出：results/models/spatial_vs_radiomics_corr_matrix_k3.csv   (84 × N 完整矩阵)
      results/models/spatial_redundancy_summary_k3.csv         (每特征汇总)
      results/models/spatial_redundancy_summary_k3.md          (可读报告)
"""
import os, warnings
import numpy as np
import pandas as pd

warnings.filterwarnings('ignore')

BASE = r'<PROJECT_ROOT>'
OUT = os.path.join(BASE, 'results', 'models')
os.makedirs(OUT, exist_ok=True)

HI, MID = 0.90, 0.80


def main():
    # ---------- 1) 新空间特征 → 宽表 401×84 ----------
    sp = pd.read_csv(os.path.join(BASE, 'data', 'features', 'habitat_spatial_features_k3.csv'))
    f_dwi = [c for c in sp.columns if c.startswith('dwi_')]
    f_dce = [c for c in sp.columns if c.startswith('dce_')]
    spw = pd.concat([
        sp[sp.modality == 'DWI'].set_index('Case_No.')[f_dwi],
        sp[sp.modality == 'DCE'].set_index('Case_No.')[f_dce],
    ], axis=1)
    spw.index = spw.index.astype(str)
    spw = spw.loc[:, spw.notna().sum() > 0]
    sp_feats = list(spw.columns)

    # ---------- 2) PyRadiomics → 宽表 401×856 ----------
    rad = {}
    for mod in ['dwi', 'dce']:
        r = pd.read_csv(os.path.join(BASE, 'data', 'features', f'{mod}_pyradiomics_k3.csv'))
        r['Case_No.'] = r['Case_No.'].astype(str)
        rf = [c for c in r.columns if c not in ('Case_No.', 'Habitat')]
        for hab in ['Whole_tumor', 'habitat_L', 'habitat_M', 'habitat_H']:
            sub = r[r.Habitat == hab].drop_duplicates('Case_No.').set_index('Case_No.')[rf]
            tag = 'WT' if hab == 'Whole_tumor' else hab.replace('habitat_', '')
            for c in rf:
                rad[f'{mod}_{tag}_{c}'] = sub[c]
    rdw = pd.DataFrame(rad)
    rdw.index = rdw.index.astype(str)
    rad_feats = list(rdw.columns)

    print(f'空间特征: {len(sp_feats)}  |  radiomics 特征: {len(rad_feats)} (= 2模态 × 4区域 × 107)')
    common = spw.index.intersection(rdw.index)
    print(f'共同病例: {len(common)}')
    A = spw.loc[common]
    B = rdw.loc[common]

    # ---------- 3) Spearman 相关矩阵 ----------
    M = A.corrwith  # noqa
    corr = pd.DataFrame(index=sp_feats, columns=rad_feats, dtype=float)
    Bz = B
    for f in sp_feats:
        x = A[f]
        corr.loc[f] = Bz.corrwith(x, method='spearman')
    corr.to_csv(os.path.join(OUT, 'spatial_vs_radiomics_corr_matrix_k3.csv'))
    print(f'-> corr matrix {corr.shape}')

    # ---------- 4) 每特征汇总 ----------
    rows = []
    for f in sp_feats:
        v = corr.loc[f].dropna()
        if len(v) == 0:
            rows.append(dict(feature=f, max_abs_r=np.nan, partner='', n_hi=0, n_mid=0, verdict='无法计算'))
            continue
        av = v.abs().sort_values(ascending=False)
        partner = av.index[0]
        n_hi = int((av >= HI).sum())
        n_mid = int(((av >= MID) & (av < HI)).sum())
        verdict = ('高度冗余' if av.iloc[0] >= HI else
                   '中度冗余' if av.iloc[0] >= MID else '新增信息')
        rows.append(dict(feature=f, max_abs_r=round(float(av.iloc[0]), 3), partner=partner,
                         n_hi=n_hi, n_mid=n_mid, verdict=verdict))
    sm = pd.DataFrame(rows)
    sm.to_csv(os.path.join(OUT, 'spatial_redundancy_summary_k3.csv'), index=False)

    # ---------- 5) 重点核查：同模态同区域的直接对应 ----------
    pairs = []
    for mod in ['dwi', 'dce']:
        for L in ['L', 'M', 'H']:
            for new, old in [('sphericity', 'original_shape_Sphericity'),
                             ('surface', 'original_shape_SurfaceArea'),
                             ('n_voxels', 'original_shape_MeshVolume'),
                             ('n_voxels', 'original_shape_VoxelVolume')]:
                a, b = f'{mod}_{L}_{new}', f'{mod}_{L}_{old}'
                if a in corr.index and b in corr.columns:
                    r = corr.loc[a, b]
                    pairs.append(dict(new=a, old=b, spearman=round(float(r), 3) if pd.notna(r) else np.nan))
    pr = pd.DataFrame(pairs)

    # ---------- 6) 报告 ----------
    L = []
    L.append('# 新空间特征 vs 现有 PyRadiomics 纹理特征 —— 冗余分析（3a）\n')
    L.append(f'> 空间特征 {len(sp_feats)} 个 × radiomics {len(rad_feats)} 个 '
             f'(2模态 × 4区域[WT/L/M/H] × 107) | Spearman | 共同病例 {len(common)}\n')
    L.append(f'> 判定：|ρ|≥{HI} 高度冗余 ｜ {MID}–{HI} 中度冗余 ｜ <{MID} 新增信息\n')

    vc = sm.verdict.value_counts()
    L.append('## 总体判定\n')
    L.append('| 判定 | 数量 |')
    L.append('|---|---|')
    for k in ['高度冗余', '中度冗余', '新增信息', '无法计算']:
        if k in vc:
            L.append(f'| {k} | {vc[k]} |')
    L.append('')

    L.append('## 重点核查①：球度 —— 新算法 vs PyRadiomics original_shape_Sphericity\n')
    L.append('| 新特征 | 对应旧特征 | Spearman ρ |')
    L.append('|---|---|---|')
    for _, r in pr[pr.new.str.contains('sphericity')].iterrows():
        L.append(f"| {r.new} | {r.old} | {r.spearman} |")
    L.append('')

    L.append('## 重点核查②：体积 / 表面积 / 体素数\n')
    L.append('| 新特征 | 对应旧特征 | Spearman ρ |')
    L.append('|---|---|---|')
    for _, r in pr[~pr.new.str.contains('sphericity')].iterrows():
        L.append(f"| {r.new} | {r.old} | {r.spearman} |")
    L.append('')

    L.append('## 判定为「新增信息」的空间特征（max|ρ|<0.80）\n')
    nov = sm[sm.verdict == '新增信息'].sort_values('max_abs_r')
    if len(nov):
        L.append(f'共 **{len(nov)}** 个：\n')
        L.append('| 特征 | max\\|ρ\\| | 最相关对象 |')
        L.append('|---|---|---|')
        for _, r in nov.iterrows():
            L.append(f"| {r.feature} | {r.max_abs_r} | {r.partner} |")
    else:
        L.append('无')
    L.append('')

    L.append('## 判定为「高度冗余」的空间特征（max|ρ|≥0.90）\n')
    hi = sm[sm.verdict == '高度冗余'].sort_values('max_abs_r', ascending=False)
    if len(hi):
        L.append('| 特征 | max\\|ρ\\| | 最相关对象 |')
        L.append('|---|---|---|')
        for _, r in hi.iterrows():
            L.append(f"| {r.feature} | {r.max_abs_r} | {r.partner} |")
    else:
        L.append('无')
    L.append('')

    L.append('## 4 个 FDR<0.05 稳健特征的红冗情况\n')
    L.append('| 特征 | max\\|ρ\\| | 最相关对象 | 判定 |')
    L.append('|---|---|---|---|')
    for f in ['dwi_H_n_voxels', 'dwi_M_n_components', 'dce_M_sphericity', 'dce_H_sphericity']:
        r = sm[sm.feature == f]
        if len(r):
            r = r.iloc[0]
            L.append(f"| {f} | {r.max_abs_r} | {r.partner} | {r.verdict} |")
    L.append('')

    with open(os.path.join(OUT, 'spatial_redundancy_summary_k3.md'), 'w', encoding='utf-8') as fh:
        fh.write('\n'.join(L))

    # ---------- 控制台速览 ----------
    print('\n=== 总体判定 ===')
    print(vc.to_string())
    print('\n=== 重点核查：球度 ===')
    print(pr[pr.new.str.contains('sphericity')].to_string(index=False))
    print('\n=== 重点核查：体积/表面积 ===')
    print(pr[~pr.new.str.contains('sphericity')].to_string(index=False))
    print('\n=== 4个稳健特征 ===')
    print(sm[sm.feature.isin(['dwi_H_n_voxels', 'dwi_M_n_components',
                              'dce_M_sphericity', 'dce_H_sphericity'])].to_string(index=False))
    print('\n=== 新增信息 top15（max|ρ| 最小）===')
    print(sm[sm.verdict == '新增信息'].nsmallest(15, 'max_abs_r')[['feature', 'max_abs_r', 'partner']].to_string(index=False))


if __name__ == '__main__':
    main()
