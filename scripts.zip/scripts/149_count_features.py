# -*- coding: utf-8 -*-
"""149 — 逐层核实"空间生境影像组学一共多少特征 / 建模用了多少"（全部来自数据文件）"""
import os
import numpy as np, pandas as pd

BASE = r'<PROJECT_ROOT>'
OUT = os.path.join(BASE, 'results', 'models')
MAX_MISSING = 0.20

print('=' * 78)
print('【1】规范定义的总数（计数规则 11K + 3·C(K,2)，每模态）')
print('=' * 78)
for K in range(2, 7):
    per = 11 * K + 3 * (K * (K - 1) // 2)
    print(f'  K={K}:  单生境 {11*K:3d} + 交互 {3*(K*(K-1)//2):3d} = {per:3d} 个/模态'
          f' → ×2 模态 = {per*2:3d} 个')
print('  ★ 本项目主用 K=3 → 42 个/模态，**84 个**（双模态）')

print('\n' + '=' * 78)
print('【2】实际提取并写入文件的特征数')
print('=' * 78)
sp = pd.read_csv(os.path.join(BASE, 'data', 'features', 'habitat_spatial_features_k3.csv'))
sp['Case_No.'] = sp['Case_No.'].astype(str)
cols = [c for c in sp.columns if c.startswith(('dwi_', 'dce_'))]
dce = [c for c in cols if c.startswith('dce_')]
dwi = [c for c in cols if c.startswith('dwi_')]
print(f'  文件 habitat_spatial_features_k3.csv：{sp.shape[0]} 行 × {sp.shape[1]} 列')
print(f'  特征列 DCE {len(dce)} 个 ｜ DWI {len(dwi)} 个 ｜ 合计 {len(cols)} 个')

print('\n' + '=' * 78)
print('【3】缺失率 >20% 过滤后（建模可用）')
print('=' * 78)
# ★ 长表：每行只填自己模态的列 → 缺失率必须按模态块分别算
miss_dce = sp.loc[sp.modality == 'DCE', dce].isna().mean()
miss_dwi = sp.loc[sp.modality == 'DWI', dwi].isna().mean()
miss = pd.concat([miss_dce, miss_dwi])
print('  缺失率最高的 6 个：')
print(miss.sort_values(ascending=False).head(6).round(4).to_string())
drop = sorted(miss[miss > MAX_MISSING].index)
keep = sorted(miss[miss <= MAX_MISSING].index)
print(f'  剔除 {len(drop)} 个：{drop}')
print(f'  ★ 保留 {len(keep)} 个 ｜ DCE 来源 {sum(1 for c in keep if c.startswith("dce_"))}'
      f' ｜ DWI 来源 {sum(1 for c in keep if c.startswith("dwi_"))}')

print('\n' + '=' * 78)
print('【4】冗余分级（对照 856 个常规特征，Spearman）')
print('=' * 78)
red = pd.read_csv(os.path.join(OUT, 'spatial_redundancy_summary_k3.csv'), encoding='utf-8-sig')
red['v'] = np.where(red.max_abs_r >= .90, '高冗余', np.where(red.max_abs_r >= .80, '中间', '新颖'))
print('  全部 84 个：', dict(red.v.value_counts()))
r2 = red[red.feature.isin(keep)]
print(f'  过滤后 {len(r2)} 个：', dict(r2.v.value_counts()))
red['modality_'] = red['feature'].str[:3]
for m in ['dce', 'dwi']:
    rm = red[red['modality_'] == m]
    print(f'  {m.upper()} 共 {len(rm)} 个：{dict(rm.v.value_counts())}')
print('  ★ 新颖 DCE 空间特征 =', int(((red['modality_'] == 'dce') & (red.v == '新颖')).sum()))
print('  ★ 新颖池（双模态，>20%过滤后）=', int((r2.v == '新颖').sum()))

print('\n' + '=' * 78)
print('【5】各建模方案实际用了多少特征')
print('=' * 78)
print('  —— 主分析（401 例 / 4 中心）——')
main = [
    ('M0 临床11',                     11,  0,  0),
    ('M4c 原论文（参照）',             11, 107,  0),
    ('M4c+P1（+新颖空间池 53）',       11, 107, 53),
    ('M4c+P2（+全部空间池 81）',       11, 107, 81),
    ('M4c+DCEspat（+新颖DCE 27）',     11, 107, 27),
    ('临床+P2（11+81）',               11,  0,  81),
    ('临床+DCEspat（11+27）',          11,  0,  27),
    ('P2_only（仅空间 81）',            0,  0,  81),
    ('简约 临床3+折内top1',             3,  0, '折内筛 1（池 188）'),
]
print(f'  {"模型":30s} {"临床":>5s} {"常规":>5s} {"空间":>6s} {"合计":>6s}')
for name, c, r, s in main:
    tot = (c + r + s) if isinstance(s, int) else f'{c+r}+1'
    print(f'  {name:30s} {c:5d} {r:5d} {str(s):>6s} {str(tot):>6s}')
print('\n  —— 本轮外部验证（训练 C1+C3 → 测试 C2，全 DCE 不含 DWI）——')
ext = [
    ('M0 临床11',                11,   0,  0),
    ('M4c 原论文 (118)',          11, 107,  0),
    ('DCE 空间特征 (42)',          0,   0, 42),
    ('简约 临床3+折内top1',         3,   0, '折内筛 1（池 149）'),
    ('M4c+DCE空间 (160)',         11, 107, 42),
    ('临床11+DCE空间 (53)',        11,   0, 42),
]
print(f'  {"模型":26s} {"临床":>5s} {"常规DCE_H":>9s} {"空间DCE":>7s} {"输入合计":>8s}')
for name, c, r, s in ext:
    tot = (c + r + s) if isinstance(s, int) else f'{c+r}+1'
    print(f'  {name:26s} {c:5d} {r:9d} {str(s):>7s} {str(tot):>8s}')
