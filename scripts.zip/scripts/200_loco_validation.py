# -*- coding: utf-8 -*-
"""
LOCO 验证：对 Manuscript_revised_v2.docx 的关键模型(M0 / M4c)做留一中心法
输出：pooled 5折CV、pooled nested-OOF、LOCO逐中心、LOCO总体(拼接OOF)、Sphericity跨中心
"""
import os, warnings, time
import numpy as np, pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold
from sksurv.linear_model import CoxnetSurvivalAnalysis
from sksurv.metrics import concordance_index_censored, cumulative_dynamic_auc
warnings.filterwarnings('ignore')

BASE = r'<PROJECT_ROOT>'
ALPHAS = np.logspace(-1.5, 0, 20)
CLIN_VARS = ['NAC','N','Age','Grade','T','ALN','proRT','ER','PR','Her2','Meno']
SEED = 42

def make_surv(df):
    return np.array([(bool(e), float(t)) for e, t in zip(df['DFS'], df['Time'])],
                    dtype=[('event','bool'),('time','float')])

def fit_predict(Xtr, ytr, Xte):
    """训练集内 5 折选 alpha → 全训练集重拟 → 预测测试集"""
    s = StandardScaler(); Xtr_s = s.fit_transform(Xtr); Xte_s = s.transform(Xte)
    inner = KFold(5, shuffle=True, random_state=SEED)
    sc = {a: [] for a in ALPHAS}
    for itr, ite in inner.split(Xtr_s):
        si = StandardScaler(); Xi = si.fit_transform(Xtr_s[itr]); Xv = si.transform(Xtr_s[ite])
        try:
            c = CoxnetSurvivalAnalysis(l1_ratio=1, alphas=ALPHAS, max_iter=10000).fit(Xi, ytr[itr])
            for a in ALPHAS:
                try:
                    p = c.predict(Xv, alpha=a)
                    sc[a].append(concordance_index_censored(ytr['event'][ite], ytr['time'][ite], p)[0])
                except Exception:
                    sc[a].append(0.5)
        except Exception:
            for a in ALPHAS: sc[a].append(0.5)
    ba = max(sc, key=lambda a: float(np.mean(sc[a])))
    c = CoxnetSurvivalAnalysis(l1_ratio=1, alphas=[ba], max_iter=10000).fit(Xtr_s, ytr)
    return c.predict(Xte_s).flatten(), ba

def pooled_oof(X, y):
    Xs = X.values; oof = np.full(len(Xs), np.nan)
    for tr, te in KFold(5, shuffle=True, random_state=SEED).split(Xs):
        oof[te] = fit_predict(Xs[tr], y[tr], Xs[te])[0]
    return oof

def loco(X, y, centers):
    Xv = X.values; lob = np.full(len(Xv), np.nan); rows = []
    for c in sorted(pd.unique(centers)):
        te = np.where(centers == c)[0]; tr = np.where(centers != c)[0]
        p, ba = fit_predict(Xv[tr], y[tr], Xv[te])
        lob[te] = p
        ci = concordance_index_censored(y['event'][te], y['time'][te], p)[0]
        rows.append((c, len(te), int(y['event'][te].sum()), round(ci,4), round(ba,4)))
    return lob, rows

def auc_at(y, risk, t):
    try: return float(cumulative_dynamic_auc(y, y, risk, times=[t])[0][0])
    except Exception: return float('nan')

# ---- 数据 ----
clin = pd.read_csv(r'<DATA_ROOT>\分析结果\merged_data_corrected.csv', encoding='utf-8-sig')
clin['Case_No.'] = clin['Case_No.'].astype(str)
centers = clin['Center'].values
y = make_surv(clin); ev, tm = y['event'].astype(bool), y['time'].astype(float)

rad = pd.read_csv(os.path.join(BASE,'data','features','dce_pyradiomics_k3.csv'))
rad['Case_No.'] = rad['Case_No.'].astype(str)
rf = [c for c in rad.columns if c not in ('Case_No.','Habitat')]
radH = rad[rad.Habitat=='habitat_H'].drop_duplicates('Case_No.').set_index('Case_No.')[rf]

order = clin['Case_No.']
R = radH.loc[order].reset_index(drop=True)
C = clin[CLIN_VARS].reset_index(drop=True)

M0  = C.fillna(0).astype(float)
M4c = pd.concat([C, R.add_prefix('DCEH_')], axis=1).fillna(0).astype(float)
print(f'M0 feats={M0.shape[1]}  M4c feats={M4c.shape[1]}  events={int(ev.sum())}/{len(ev)}')

results = {}
for name, X in [('M0_clinical', M0), ('M4c_DCEH+clin', M4c)]:
    t0=time.time()
    oof = pooled_oof(X, y)
    c_pool = concordance_index_censored(ev, tm, oof)[0]
    a3_pool = auc_at(y, oof, 36); a5_pool = auc_at(y, oof, 60)
    lob, rows = loco(X, y, centers)
    c_loco = concordance_index_censored(ev, tm, lob)[0]
    a3_loco = auc_at(y, lob, 36); a5_loco = auc_at(y, lob, 60)
    print(f'\n===== {name} ({time.time()-t0:.0f}s) =====')
    print(f'  pooled 5折 OOF : C={c_pool:.4f}  AUC3={a3_pool:.4f}  AUC5={a5_pool:.4f}')
    print(f'  LOCO 拼接 OOF  : C={c_loco:.4f}  AUC3={a3_loco:.4f}  AUC5={a5_loco:.4f}')
    print('  LOCO 逐中心 (center, n, events, C-index, alpha):')
    evw = [(r[3], r[2]) for r in rows]  # (ci, events)
    wsum = sum(ci*e for ci,e in evw)/sum(e for _,e in evw)
    for r in rows: print(f'    {r[0]}: n={r[1]} evt={r[2]} C={r[3]} alpha={r[4]}')
    print(f'  LOCO 简单平均 C={np.mean([r[3] for r in rows]):.4f} | 事件加权 C={wsum:.4f}')
    results[name] = dict(pool=(c_pool,a3_pool,a5_pool), loco=(c_loco,a3_loco,a5_loco),
                         rows=rows, evw=wsum)

# ---- Sphericity 跨中心稳定性 ----
print('\n===== Sphericity (DCE_H) 跨中心单变量 Cox =====')
sph = [c for c in R.columns if 'Sphericity' in c]
if sph:
    sc = sph[0]
    from lifelines import CoxPHFitter
    for c in sorted(pd.unique(centers)):
        m = centers==c
        df = pd.DataFrame({'x': R[sc].values[m], 'T': tm[m], 'E': ev[m].astype(int)})
        try:
            cph = CoxPHFitter().fit(df, 'T', 'E')
            hr = np.exp(cph.params_['x']); p = cph.summary.loc['x','p']
            print(f'  {c}: n={m.sum()} evt={int(ev[m].sum())} HR(SD增大)={hr:.3f} P={p:.3f}')
        except Exception as e:
            print(f'  {c}: 拟合失败 {e}')
    # 全样本
    df = pd.DataFrame({'x': R[sc].values, 'T': tm, 'E': ev.astype(int)})
    cph = CoxPHFitter().fit(df,'T','E')
    hr_all = np.exp(cph.params_['x']); p_all = cph.summary.loc['x','p']
    print(f'  All-401: HR={hr_all:.3f} P={p_all:.4f}')
print('\nDONE')
